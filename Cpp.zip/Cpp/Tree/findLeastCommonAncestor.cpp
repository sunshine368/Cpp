/*
Given a binary tree (not necessarily BST), find the least common ancestor of two given nodes.
Pseudo-code:
Find-Least-Common-Ancestor( Node *pt, first, second )
1  if ( pt==0 )
2      return 0;
3  if ( pt->value==first || pt->value==second )
4      return pt;
5  Node *left = Find-Least-Common-Ancestor( pt->leftChild, first, second )
6  Node *right = Find-Least-Common-Ancestor( pt->rightChild, first, second )
7  if ( left!=0 && right!=0 )
8      return pt;
9  else if ( left!=0 )
10     return left;
11 else if ( right!=0 )
12     return right;
13 else
14     return 0;
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *leftChild;
    Node *rightChild;
};

void InsertNode( Node *pt, int data )
{
    pt->value = data;
    pt->leftChild = 0;
    pt->rightChild = 0;
}

// Given an array of integers, build a complete binary tree (not necessarily BST).
Node *BuildBinaryTree( int A[], int n )
{
    Node *tree = (Node*)malloc( sizeof(Node)*n );
    for ( int i=0; i<n; i++ )
    {
        if ( i==0 )
            InsertNode( &tree[0], A[0] );
        else
        {
            if ( i==2*((i-1)/2)+1 )
            {
                tree[(i-1)/2].leftChild = &tree[i];
                InsertNode( tree[(i-1)/2].leftChild, A[i] );
            }
            else if ( i==2*((i-1)/2)+2 )
            {
                tree[(i-1)/2].rightChild = &tree[i];
                InsertNode( tree[(i-1)/2].rightChild, A[i] );
            }
        }
    }
    return &tree[0];
}

void InOrderTraverse( Node *pt )
{
    if ( pt!=0 )
    {
        InOrderTraverse( pt->leftChild );
        cout << pt->value << " ";
        InOrderTraverse( pt->rightChild );
    }
}

void PreOrderTraverse( Node *pt )
{
    if ( pt!=0 )
    {
        cout << pt->value << " ";
        PreOrderTraverse( pt->leftChild );
        PreOrderTraverse( pt->rightChild );
    }
}

void PostOrderTraverse( Node *pt )
{
    if ( pt!=0 )
    {
        PostOrderTraverse( pt->leftChild );
        PostOrderTraverse( pt->rightChild );
        cout << pt->value << " ";
    }
}

// Find the first common ancestor of two nodes in a binary tree (not necessarily BST).
Node *findLeastComAncestorHelper( Node *pt, int first, int second )
{
    if ( pt==0 )
        return 0;
    if ( pt->value==first || pt->value==second )
        return pt;
    Node *left = findLeastComAncestorHelper( pt->leftChild, first, second );
    Node *right = findLeastComAncestorHelper( pt->rightChild, first, second );
    if ( left!=0 && right!=0 )
        return pt;
    else if ( left!=0 )
        return left;
    else if ( right!=0 )
        return right;
    else
        return 0;
}

void findLeastComAncestor( Node *root, int first, int second )
{
    Node *result = findLeastComAncestorHelper( root, first, second );
    cout << "The least common ancestor: " << result->value << endl;
}

int main()
{
    int n;
    cout << "Please enter n:\n";
    cin >> n;
    
    srand(time(NULL));
    int *A = (int*)malloc( sizeof(int)*n );
    for ( int i=0; i<n; i++ )
        A[i] = rand()%100;
    
    cout << "The array:\n";
    for ( int i=0; i<n; i++ )
        cout << A[i] << " ";
    cout << endl;
    
    Node *root = BuildBinaryTree( A, n );
    
    cout << "In-order-traverse of the tree:\n";
    InOrderTraverse( root );
    cout << endl;
    
    cout << "Pre-order-traverse of the tree:\n";
    PreOrderTraverse( root );
    cout << endl;
    
    cout << "Post-order-traverse of the tree:\n";
    PostOrderTraverse( root );
    cout << endl;
    
    int first, second;
    cout << "Please enter the first integer:\n";
    cin >> first;
    cout << "Please enter the second integer:\n";
    cin >> second;
    findLeastComAncestor( root, first, second );
    
    return 0;
}