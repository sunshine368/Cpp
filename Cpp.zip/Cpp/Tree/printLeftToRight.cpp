// print the nodes of a binary tree (not necessarily BST) from left to right

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *leftChild;
    Node *rightChild;
};

void InsertNode( Node **pt, int data )
{
    if ( (*pt)==0 )
    {
        (*pt) = (Node*)malloc( sizeof(Node) );
        (*pt)->value = data;
        (*pt)->leftChild = 0;
        (*pt)->rightChild = 0;
    }
    else
    {
        if ( data >= (*pt)->value )
        {
            InsertNode( &((*pt)->rightChild), data );
        }
        else
        {
            InsertNode( &((*pt)->leftChild), data );
        }
    }
}

Node* BuildBST( int A[], int n )
{
    Node *root = 0;
    for ( int i=0; i<n; i++ )
    {
        InsertNode( &root, A[i] );
    }
    return root;
}

void printLeftToRightHelper( Node *pt )
{
    if ( pt!=0 )
    {
        printLeftToRightHelper( pt->leftChild );
        cout << pt->value << " ";
        printLeftToRightHelper( pt->rightChild );
    }
}

void printLeftToRight( Node *root )
{
    printLeftToRightHelper( root );
    cout << endl;
}



int main()
{
    int n;
    cout << "Please enter n:\n";
    cin >> n;
    
    srand(time(NULL));
    int *A = (int*)malloc( sizeof(int)*n );
    for ( int i=0; i<n; i++ )
        A[i] = rand()%100;
    
    for ( int i=0; i<n; i++ )
        cout << A[i] << " ";
    cout << endl;
    
    Node *root = BuildBST( A, n );
    
    printLeftToRight( root );
    
    return 0;
}