#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	int size;
	Node *leftChild;
	Node *rightChild;
};

Node *BuildBSTwithRanks()
{
	Node *root = 0;
	return root;
}

// iterative find
Node *findIter( Node *root, int data )
{
	while ( root!=0 ) 
	{
		if ( data > root->value )
			root = root->rightChild;
		else if ( data < root->value )
			root = root->leftChild;
		else
			return root;
	}
	return root;
}

// recursive find
Node *findRecur( Node *root, int data )
{
	if ( root==0 || root->value==data )
		return root;
	if ( data > root->value )
		return findRecur( root->rightChild, data );
	else 
		return findRecur( root->leftChild, data );
}

// iterative insert
bool InsertNodeIter( Node **root, int data )
{
	if ( findIter( *root, data ) )
		return false;
	Node *new_node = new Node;
	if ( !new_node )
		return false;
	new_node->value = data;
	new_node->leftChild = 0;
	new_node->rightChild = 0;
	new_node->size = 1;
	if ( *root==0 )
	{		
		*root = new_node;
	}
	else
	{
		Node *node = *root;
		Node *parent = *root;
		while ( node!=0 )
		{
			if ( data > node->value )
			{
				++(node->size);
				parent = node;
				node = node->rightChild;
			}
			else if ( data < node->value )
			{
				++(node->size);
				parent = node;
				node = node->leftChild;
			}
		}
		if ( data > parent->value )		
			parent->rightChild = new_node;
		else 
			parent->leftChild = new_node;
	}
	return true;
}

// recursive insert
bool InsertNodeRecur( Node **root, int data )
{
	if ( *root==0 )
	{
		Node *new_node = new Node;
		if ( !new_node )
			return false;
		new_node->value = data;
		new_node->leftChild = 0;
		new_node->rightChild = 0;
		new_node->size = 1;
		*root = new_node;
		return true;
	}

	bool found;
	if ( data > (*root)->value )
		found = InsertNodeRecur( &(*root)->rightChild, data );	 
	else if ( data < (*root)->value )
		found = InsertNodeRecur( &(*root)->leftChild, data );	 
	else
		found = false;
	
	if ( found )
		++((*root)->size);

	return found;
}

// recursive insert 2
void InsertNodeRecur2Aux( Node **root, int data )
{
	if ( *root==0 )
	{
		Node *new_node = new Node;
		if ( !new_node )
			return;
		new_node->value = data;
		new_node->leftChild = 0;
		new_node->rightChild = 0;
		new_node->size = 1;
		*root = new_node;
		return;
	}
	if ( data > (*root)->value )
		InsertNodeRecur2Aux( &(*root)->rightChild, data );
	else if ( data < (*root)->value )
		InsertNodeRecur2Aux( &(*root)->leftChild, data );

	++((*root)->size);
}

void InsertNodeRecur2( Node **root, int data )
{
	if ( !findRecur( *root, data ) )
		InsertNodeRecur2Aux( root, data );
}

// iterative removeMin
void removeMinIter( Node **root )
{
	if ( *root==0 )
		return;
	if ( (*root)->leftChild==0 )
	{
		Node *temp = *root;
		*root = (*root)->rightChild;
		delete temp;
	}
	else
	{
		Node *node = *root;
		Node *parent = *root;
		while ( node->leftChild!=0 )
		{
			parent = node;
			node = node->leftChild;
			--(parent->size);
		}
		parent->leftChild = node->rightChild;
		Node *temp = node;
		delete temp;
	}
}

// recursive removeMin
void removeMinRecur( Node **root )
{
	if ( *root==0 )
		return;
	else if ( (*root)->leftChild!=0 )
		removeMinRecur( &(*root)->leftChild );
	else
	{
		Node *temp = *root;
		*root = (*root)->rightChild;
		delete temp;
		return;
	}
	--((*root)->size);
}

// iterative findMin
Node *findMinIter( Node *root )
{
	if ( root==0 || root->leftChild==0 )
		return root;
	while ( root->leftChild!=0 )
	{
		root = root->leftChild;
	}
	return root;
}

// recursive findMin
Node *findMinRecur( Node *root )
{
	if ( root==0 || root->leftChild==0 )
		return root;
	return findMinRecur( root->leftChild );
}

// iterative remove
void removeIter( Node **root, int data )
{
	if ( *root==0 || findIter( *root, data )==0 )
		return;
	if ( (*root)->value==data )
	{
		if ( (*root)->leftChild!=0 && (*root)->rightChild!=0 )
		{
			Node *temp = findMinIter( (*root)->rightChild );
			(*root)->value = temp->value;
			--((*root)->size);
			removeMinIter( &(*root)->rightChild );
		}
		else
		{
			Node *temp = *root;
			*root = ( (*root)->leftChild!=0 ) ? (*root)->leftChild : (*root)->rightChild;
			delete temp;
		}
	}
	else
	{
		Node *node = *root;
		Node *parent = *root;
		while ( true )
		{
			if ( data > node->value )
			{
				parent = node;
				node = node->rightChild;
				--(parent->size);
			}
			else if ( data < node->value )
			{
				parent = node;
				node = node->leftChild;
				--(parent->size);
			}
			else
				break;
		}
		if ( node->leftChild!=0 && node->rightChild!=0 )
		{
			Node *temp = findMinIter( node->rightChild );
			node->value = temp->value;
			--(node->size);
			removeMinIter( &(node->rightChild) );
		}
		else
		{
			Node *temp = node;
			if ( node==parent->leftChild )
			{
				parent->leftChild = ( node->leftChild!=0 ) ? node->leftChild : node->rightChild;
			}
			else
			{
				parent->rightChild = ( node->leftChild!=0 ) ? node->leftChild : node->rightChild;
			}
			delete temp;
		}
	}
}

// recursive remove
void removeRecurAux( Node **root, int data )
{
	if ( *root==0 )
		return;
	if ( data > (*root)->value )
		removeRecurAux( &(*root)->rightChild, data );
	else if ( data < (*root)->value )
		removeRecurAux( &(*root)->leftChild, data );
	else
	{
		if ( (*root)->leftChild!=0 && (*root)->rightChild!=0 )
		{
			Node *temp = findMinRecur( (*root)->rightChild );
			(*root)->value = temp->value;
			--((*root)->size);
			removeMinRecur( &(*root)->rightChild );
		}
		else
		{
			Node *temp = *root;
			*root = ( (*root)->leftChild!=0 ) ? (*root)->leftChild : (*root)->rightChild;
			delete temp;
		}
		return;
	}
	--((*root)->size);
}

void removeRecur( Node **root, int data )
{
	if ( findRecur( *root, data ) )
		removeRecurAux( root, data );
}

// find the Kth smallest element recursively
Node *findKthRecur( Node *root, int k )
{
	if ( root==0 )
		return 0;
	int leftSize = (root->leftChild!=0) ? (root->leftChild)->size : 0;
	if ( k <= leftSize )
		return findKthRecur( root->leftChild, k );
	else if ( k > leftSize + 1 )
		return findKthRecur( root->rightChild, k-leftSize-1 );
	else
		return root;
}

// find the Kth smallest element iteratively
Node *findKthIter( Node *root, int k )
{
	while ( root!=0 )
	{
		int leftSize = (root->leftChild!=0) ? (root->leftChild)->size : 0;
		if ( k <= leftSize )
			root = root->leftChild;
		else if ( k > leftSize + 1 )
		{
			root = root->rightChild;
			k = k - leftSize - 1;
		}
		else
			break;
	}
	return root;
}

// recursive inorder traversal 
void printInOrderRecur( Node *root )
{
	if ( root!=0 )
	{
		printInOrderRecur( root->leftChild );
		cout << root->value << ", " << root->size << endl;
		printInOrderRecur( root->rightChild );
	}
}

int main()
{
	// illustration of iterative insert
	cout << "***Illustration of iterative insert***\n";
	int n;
	cout << "Enter n:\n";
	cin >> n;

	Node *t1 = BuildBSTwithRanks();

	cout << endl;
	srand(time(NULL));
	for ( int i=0; i<n; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		InsertNodeIter( &t1, data );
	}

	cout << "\nIn-order traversal of t1:\n";
	printInOrderRecur( t1 );

	// illustration of iterative find
	cout << "\n\nIllustration of iterative find***\n";
	cout << "Enter the value for searching:\n";
	int data;
	cin >> data;

	Node *found = findIter( t1, data );
	if ( found!=0 )
		cout << data << " found in t1.\n";
	else
		cout << data << " not found in t1.\n";

	// illustration of recursive insert 1
	cout << "\n\n***Illustration of recursive insert 1***\n";
	int n2;
	cout << "Enter n2:\n";
	cin >> n2;

	Node *t2 = BuildBSTwithRanks();

	cout << endl;
	srand(time(NULL));
	for ( int i=0; i<n2; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		InsertNodeRecur( &t2, data );
	}

	cout << "\nIn-order traversal of t2:\n";
	printInOrderRecur( t2 );

	// illustration of recursive find
	cout << "\n\nIllustration of recursive find***\n";
	cout << "Enter the value for searching:\n";
	int data2;
	cin >> data2;

	Node *found2 = findRecur( t2, data2 );
	if ( found2!=0 )
		cout << data2 << " found in t2.\n";
	else
		cout << data2 << " not found in t2.\n";

	// illustration of recursive insert 2
	cout << "\n\n***Illustration of recursive insert 2***\n";
	int n3;
	cout << "Enter n3:\n";
	cin >> n3;

	Node *t3 = BuildBSTwithRanks();

	cout << endl;
	srand(time(NULL));
	for ( int i=0; i<n3; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		InsertNodeRecur2( &t3, data );
	}

	cout << "\nIn-order traversal of t3:\n";
	printInOrderRecur( t3 );

	// illustration of iterative removeMin
	cout << "\n\n***Illustration of iterative removeMin***\n";
	removeMinIter( &t3 );
	cout << "After removing the minimum element of t3:\n";
	printInOrderRecur( t3 );

	// illustration of recursive removeMin
	cout << "\n\n***Illustration of recursive removeMin***\n";
	removeMinRecur( &t3 );
	cout << "After removing the minimum element of t3:\n";
	printInOrderRecur( t3 );

	// illustration of iterative remove
	cout << "\n\n***Illustration of iterative remove***\n";
	int data3;
	cout << "Enter the value to be removed:\n";
	cin >> data3;
	removeIter( &t3, data3 );
	cout << "After removing " << data3 << ", inorder traversal of t3:\n";
	printInOrderRecur( t3 );

	// illustration of recursive remove
	cout << "\n\n***Illustration of recursive remove***\n";
	int data4;
	cout << "Enter the value to be removed:\n";
	cin >> data4;
	removeRecur( &t3, data4 );
	cout << "After removing " << data4 << ", inorder traversal of t3:\n";
	printInOrderRecur( t3 );

	// find the Kth smallest element recursively
	cout << "\n\n***Illustration of recursive find Kth smallest***\n";
	int k1;
	cout << "Enter k1:\n";
	cin >> k1;

	Node *result1 = findKthRecur( t3, k1 );
	cout << "The " << k1 << "th smallest value in t3: " << result1->value << endl;

	// find the Kth smallest element iteratively
	cout << "\n\n***Illustration of iterative find Kth smallest***\n";
	int k2;
	cout << "Enter k2:\n";
	cin >> k2;

	Node *result2 = findKthIter( t3, k2 );
	cout << "The " << k2 << "th smallest value in t3: " << result2->value << endl;

	system("pause");
	return 0;
}