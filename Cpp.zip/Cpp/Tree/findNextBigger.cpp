/*
Given a binary search tree (no duplicates) and a number, find the 
next number bigger than the given number in the BST.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *leftChild;
	Node *rightChild;
};

void findNextBiggerHelper( Node *pt, int key, int *result_ptr )
{
	if ( pt!=0 )
	{
		if ( key>=pt->value )
		{
			findNextBiggerHelper( pt->rightChild, key, result_ptr );
		}
		else
		{
			*result_ptr = pt->value;
			findNextBiggerHelper( pt->leftChild, key, result_ptr );
		}
	}
}

void InsertNode( Node **pt, int data )
{
	if ( (*pt)==0 )
	{
		(*pt) = (Node*)malloc( sizeof(Node) );
		(*pt)->value = data;
		(*pt)->leftChild = 0;
		(*pt)->rightChild = 0;
	}
	else
	{
		if ( data < (*pt)->value )
		{
			InsertNode( &((*pt)->leftChild), data );
		}
		else if ( data > (*pt)->value )
		{
			InsertNode( &((*pt)->rightChild), data );
		}
		else
			return;
	}
}

// recursive method
int findNextBigger( int A[], int n, int key )
{
	Node *root = 0;
	for ( int i=0; i<n; i++ )
	{
		InsertNode( &root, A[i] );
	}
	int result = key;
	int *result_ptr = &result;
	findNextBiggerHelper( root, key, result_ptr );
	return result;
}

// non-recursive method
int findNextBigger2( int A[], int n, int key )
{
	Node *root = 0;
	for ( int i=0; i<n; i++ )
	{
		InsertNode( &root, A[i] );
	}

	int result = key;
	Node *pt = root;
	while ( pt!=0 )
	{
		if ( key >= pt->value )
		{
			pt = pt->rightChild;
		}
		else
		{
			result = pt->value;
			pt = pt->leftChild;
		}
	}
	return result;
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));
	int *A = (int*)malloc( sizeof(int)*n );
	cout << "The arrays:\n";
	for ( int i=0; i<n; i++ )
	{
		A[i] = rand()%100;
		cout << A[i] << " ";
	}
	cout << endl;

	int key;
	cout << "Please enter the key:\n";
	cin >> key;

	// recursive method
	int result = findNextBigger( A, n, key );
	if ( result==key )
		cout << key << " is the biggest number in the tree.\n";
	else
		cout << "The next number bigger than " << key << " is " << result << endl;

	// non-recursive method
	int result2 = findNextBigger2( A, n, key );
	if ( result2==key )
		cout << key << " is the biggest number in the tree.\n";
	else
		cout << "The next number bigger than " << key << " is " << result2 << endl;

	system("pause");
	return 0;
}