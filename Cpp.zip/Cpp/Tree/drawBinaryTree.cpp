/*
Exercise 18.12 in Data Structures and Problem Solving Using C++ by Mark Weiss:
A binary tree can be generated automatically for desktop publishing by a program.
You can write this program by assigning an x-y coordinate to each tree node, 
drawing a circle around each coordinate, and connecting each nonroot node to
its parent. Assume that you have a binary tree stored in memory and that each 
node has two extra data members for storing the coordinates. Assume that (0,0)
is the top-left corner. Do the following.
a. The x-coordinate can be computed by assigning the inorder traversal number.
Write a routine to do so for each node in the tree.
b. The y-coordinate can be computed by using the negative of the depth of the 
node. Write a routine to do so for each node in the tree
c. In terms of some imaginary unit, what will be the dimensions of the picture?
Also determine how can you adjust the units so that the tree is always roughly 
two-thirds as high as it is wide.
*/
#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *leftChild;
	Node *rightChild;
	int x;
	int y;
};

struct Tree
{
	Node *root;
	int size;
};

Tree* BuildBinaryTree()
{
	Tree *tree = new Tree;
	tree->size = 0;
	tree->root = 0;
	return tree;
}

Node *InsertNodeAux( Node *node, int cur, int target )
{
	if ( cur==target/2 )
		return node;
	else if ( cur>target/2 )
		return 0;

	Node *left = InsertNodeAux( node->leftChild, 2*cur, target );
	Node *right = InsertNodeAux( node->rightChild, 2*cur+1, target );
	if ( left!=0 )
		return left;
	else if ( right!=0 )
		return right;
	else
		return 0;
}

bool InsertNode( Tree *tree, int data )
{
	Node *new_node = new Node;
	if ( !new_node )
		return 0;
	new_node->value = data;
	new_node->x = 0;
	new_node->y = 0;
	new_node->leftChild = 0;
	new_node->rightChild = 0;
	++(tree->size);
	int size = tree->size;
	if ( size==1 )
	{
		tree->root = new_node;
	}
	else
	{
		Node *parent = InsertNodeAux( tree->root, 1, size ); // note the "1" here
		if ( size==(size/2)*2 )
			parent->leftChild = new_node;
		else if ( size==(size/2)*2+1 )
			parent->rightChild = new_node;
	}
	return true;
}

// calculate the x-coordinate of the nodes
void calculateXAux( Node *node, int scale, int *index )
{
	if ( node!=0 )
	{
		calculateXAux( node->leftChild, scale, index );
		node->x = (*index)*scale;
		++(*index);
		calculateXAux( node->rightChild, scale, index );
	}
}

void calculateX( Tree *tree, int scale )
{
	if ( tree==0 || tree->root==0 )
		return;
	int index = 0;
	calculateXAux( tree->root, scale, &index );
}

// calculate the y-coordinate of the nodes
void calculateYAux( Node *node, int scale, int index )
{
	if ( node!=0 )
	{
		node->y = -(index*scale);
		calculateYAux( node->leftChild, scale, index+1 );
		calculateYAux( node->rightChild, scale, index+1 );
	}
}

void calculateY( Tree *tree, int scale )
{
	if ( tree==0 || tree->root==0 )
		return;
	calculateYAux( tree->root, scale, 0 );
}

// print x-y coordinates and value of the nodes in-order
void printXYAux( Node *node )
{
	if ( node!=0 )
	{
		printXYAux( node->leftChild );
		cout << "(" << node->x << ", " << node->y << "): " << node->value << endl;
		printXYAux( node->rightChild );
	}
}

void printXY( Tree *tree )
{
	if ( tree==0 || tree->root==0 )
		return;
	printXYAux( tree->root );
}

// print value of the nodes in-order
void printInOrder( Node *node )
{
	if ( node!=0 )
	{
		printInOrder( node->leftChild );
		cout << node->value << endl;
		printInOrder( node->rightChild );
	}
}

int main()
{
	int n;
	cout << "Enter n:\n";
	cin >> n;

	Tree *t1 = BuildBinaryTree();

	cout << "\nThe data:\n";
	srand(time(NULL));
	for ( int i=0; i<n; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		InsertNode( t1, data );
	}

	cout << "\nThe tree:\n";
	printInOrder( t1->root );

	int scale;
	cout << "\nEnter scale:\n";
	cin >> scale;
	calculateX( t1, scale );
	calculateY( t1, scale );

	cout << "\nThe x-y coordiate and the value of the nodes:\n";
	printXY( t1 );

	system("pause");
	return 0;
}