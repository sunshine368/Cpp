#include <iostream>
#include <ctime>
#include <stack>
using namespace std;

struct Node
{
	int value;
	Node *leftChild;
	Node *rightChild;
};

Node *BuildBST()
{
	Node *root = 0;
	return root;
}

// iterative insertion
bool InsertNodeIter( Node **root, int data )
{
	Node *new_node = new Node;
	if ( !new_node )
		return false;
	new_node->value = data;
	new_node->leftChild = 0;
	new_node->rightChild = 0;
	if ( *root==0 )
	{
		*root = new_node;
		return true;
	}
	else
	{
		Node *cur = *root;
		Node *parent = *root;
		while ( cur!=0 )
		{
			parent = cur;
			if ( data > cur->value )
				cur = cur->rightChild;
			else if ( data < cur->value )
				cur = cur->leftChild;
			else
				return false;
		}
		if ( data > parent->value )
			parent->rightChild = new_node;
		else if ( data < parent->value )
			parent->leftChild = new_node;
		return true;
	}
}

// recursive insertion
bool InsertNodeRecur( Node **node, int data )
{
	if ( *node==0 )
	{
		Node *new_node = new Node;
		new_node->value = data;
		new_node->leftChild = 0;
		new_node->rightChild = 0;
		*node = new_node;
		return true;
	}
	else
	{
		if ( data > (*node)->value )
			return InsertNodeRecur( &(*node)->rightChild, data );
		else if ( data < (*node)->value )
			return InsertNodeRecur( &(*node)->leftChild, data );
		else
			return false;
	}
}

// recursive print inorder
void printInOrderRecur( Node *node )
{
	if ( node!=0 )
	{
		printInOrderRecur( node->leftChild );
		cout << node->value << endl;
		printInOrderRecur( node->rightChild );
	}
}

// recursive print preorder
void printPreOrderRecur( Node *node )
{
	if ( node!=0 )
	{		
		cout << node->value << endl;
		printInOrderRecur( node->leftChild );
		printInOrderRecur( node->rightChild );
	}
}

// recursive print postorder
void printPostOrderRecur( Node *node )
{
	if ( node!=0 )
	{				
		printInOrderRecur( node->leftChild );
		printInOrderRecur( node->rightChild );
		cout << node->value << endl;
	}
}

// iterative find
Node *findIter( Node *root, int data )
{
	while ( root!=0 )
	{
		if ( data > root->value )
			root = root->rightChild;
		else if ( data < root->value )
			root = root->leftChild;
		else
			return root;
	}
	return 0;
}

// recursive find
Node *findRecur( Node *root, int data )
{
	if ( root==0 )
		return 0;

	if ( data > root->value )
		return findRecur( root->rightChild, data );
	else if ( data < root->value )
		return findRecur( root->leftChild, data );
	else
		return root;
}

// iterative findMin
Node *findMinIter( Node *root )
{
	if ( root!=0 )
	{
		while ( root->leftChild!=0 )
			root = root->leftChild;
	}
	return root;
}

// recursive findMin
Node *findMinRecur( Node *root )
{
	if ( root==0 || root->leftChild==0 )
		return root;
	return findMinRecur( root->leftChild );
}

// iterative findMax
Node *findMaxIter( Node *root )
{
	if ( root!=0 )
	{
		while ( root->rightChild!=0 )
			root = root->rightChild;
	}
	return root;
}

// recursive findMax
Node *findMaxRecur( Node *root )
{
	if ( root==0 || root->rightChild==0 )
		return root;
	return findMaxRecur( root->rightChild );
}

// iterative removeMin
void removeMinIter( Node **root )
{
	if ( (*root)!=0 )
	{
		if ( (*root)->leftChild==0 )
		{
			Node *temp = *root;
			*root = (*root)->rightChild;
			delete temp;
			return;
		}
		Node *node = *root;
		Node *parent = *root;
		while ( node->leftChild!=0 )
		{
			parent = node;
			node = node->leftChild;
		}
		Node *temp = node;
		parent->leftChild = node->rightChild;
		delete temp;
	}
}

// recursive removeMin
void removeMinRecur( Node **root )
{
	if ( *root==0 )
		return;
	if ( (*root)->leftChild==0 )
	{
		Node *temp = *root;
		*root = (*root)->rightChild;
		delete temp;
	}
	else
		removeMinRecur( &(*root)->leftChild );
}

// recursive remove
void removeRecur( Node **root, int data )
{
	if ( *root==0 )
		return;
	if ( data > (*root)->value )
		removeRecur( &(*root)->rightChild, data );
	else if ( data < (*root)->value )
		removeRecur( &(*root)->leftChild, data );
	else if ( (*root)->leftChild!=0 && (*root)->rightChild!=0 )
	{
		Node *temp = findMinRecur( (*root)->rightChild );
		(*root)->value = temp->value;
		removeMinRecur( &(*root)->rightChild );
	}
	else
	{
		Node *temp = *root;
		*root = ( (*root)->leftChild==0 ) ? (*root)->rightChild : (*root)->leftChild;
		delete temp;
	}
}

// iterative remove
void removeIter( Node **root, int data )
{
	if ( *root==0 )
		return;
	if ( (*root)->value==data )
	{
		if ( (*root)->rightChild!=0 && (*root)->leftChild!=0 )
		{
			Node *result = findMinIter( (*root)->rightChild );
			(*root)->value = result->value;
			removeMinIter( &((*root)->rightChild) );
		}
		else
		{
			Node *temp = *root;
			*root = ( (*root)->rightChild!=0 ) ? (*root)->rightChild : (*root)->leftChild;
			delete temp;
		}
	}
	else
	{
		Node *node = *root;
		Node *parent = *root;
		while ( node!=0 )
		{
			if ( data > node->value )
			{
				parent = node;
				node = node->rightChild;
			}
			else if ( data < node->value )
			{
				parent = node;
				node = node->leftChild;
			}
			else
			{
				if ( node->leftChild!=0 && node->rightChild!=0 )
				{
					Node *result = findMinIter( node->rightChild );
					node->value = result->value;
					removeMinIter( &(node->rightChild) );
				}
				else 
				{
					if ( node==parent->leftChild )
					{
						Node *temp = node;
						parent->leftChild = (node->leftChild!=0) ? node->leftChild : node->rightChild;
						delete temp;
					}
					else
					{
						Node *temp = node;
						parent->rightChild = (node->leftChild!=0) ? node->leftChild : node->rightChild;
						delete temp;
					}
				}
				return;
			}
		}
	}
}

int main()
{
	// illustration of iterative insertion
	cout << "***Illustration of iterative insertion***\n";
	int n;
	cout << "Enter n:\n";
	cin >> n;

	Node *t1 = BuildBST();

	cout << endl;
	srand(time(NULL));
	for ( int i=0; i<n; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		InsertNodeIter( &t1, data );
	}

	cout << "\nIn-order traversal of t1:\n";
	printInOrderRecur( t1 );

	// illustration of recursive insertion
	cout << "\n\n***Illustration of recursive insertion***\n";
	int n2;
	cout << "Enter n2:\n";
	cin >> n2;

	Node *t2 = BuildBST();

	cout << endl;
	srand(time(NULL));
	for ( int i=0; i<n2; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		InsertNodeRecur( &t2, data );
	}

	cout << "\nIn-order traversal of t2:\n";
	printInOrderRecur( t2 );

	// illustration of iterative find
	cout << "\n\n***Illustration of iterative find***\n";
	int data;
	cout << "Enter the value for searching:\n";
	cin >> data;
	Node *result = findIter( t2, data );
	if ( result!=0 )
		cout << data << " found in t2.\n";
	else
		cout << data << " not found in t2.\n";

	// illustration of recursive find
	cout << "\n\n***Illustration of recursive find***\n";
	int data2;
	cout << "Enter the value for searching:\n";
	cin >> data2;
	Node *result2 = findRecur( t2, data2 );
	if ( result2!=0 )
		cout << data2 << " found in t2.\n";
	else
		cout << data2 << " not found in t2.\n";

	// illustration of iterative findMin
	cout << "\n\n***Illustration of iterative findMin***\n";
	Node *result3 = findMinIter( t2 );
	cout << "The minimum value in t2: " << result3->value << endl;

	// illustration of recursive findMin
	cout << "\n\n***Illustration of recursive findMin***\n";
	Node *result4 = findMinRecur( t2 );
	cout << "The minimum value in t2: " << result4->value << endl;

	// illustration of iterative findMax
	cout << "\n\n***Illustration of iterative findMax***\n";
	Node *result5 = findMaxIter( t2 );
	cout << "The maximum value in t2: " << result5->value << endl;

	// illustration of recursive findMax
	cout << "\n\n***Illustration of recursive findMax***\n";
	Node *result6 = findMaxRecur( t2 );
	cout << "The maximum value in t2: " << result6->value << endl;

	// illustration of iterative removeMin
	cout << "\n\n***Illustration of iterative removeMin***\n";
	removeMinIter( &t2 );
	cout << "After deleting the mininum of t2, the in-order traversal of t2:\n";
	printInOrderRecur( t2 );

	// illustration of recursive removeMin
	cout << "\n\n***Illustration of recursive removeMin***\n";
	removeMinRecur( &t2 );
	cout << "After deleting the mininum of t2, the in-order traversal of t2:\n";
	printInOrderRecur( t2 );

	// illustration of recursive remove
	cout << "\n\n***Illustration of recursive remove***\n";
	cout << "Enter the value to be deleted:\n";
	int data3;
	cin >> data3;
	removeRecur( &t2, data3 );
	cout << "After deleting " << data3 << ", the in-order traversal of t2:\n";
	printInOrderRecur( t2 );

	// illustration of iterative remove
	cout << "\n\n***Illustration of iterative remove***\n";
	cout << "Enter the value to be deleted:\n";
	int data4;
	cin >> data4;
	removeIter( &t2, data4 );
	cout << "After deleting " << data4 << ", the in-order traversal of t2:\n";
	printInOrderRecur( t2 );

	system("pause");
	return 0;
}