#include <iostream>
#include <ctime>
using namespace std;

struct RBNode
{
	int value;
	int color; // 0 of red; 1 for black
	RBNode *leftChild;
	RBNode *rightChild;
};

// nullNode: always black, both the rightChild and the leftChild point to itself
RBNode *null( int data )
{
	static RBNode *nullNode = new RBNode;
	nullNode->value = data;
	nullNode->leftChild = nullNode;
	nullNode->rightChild = nullNode;
	nullNode->color = 1;
	return nullNode;
}

// head: always red, contains the smallest integer, its rightChild points to the real root
RBNode *BuildRBT()
{
	RBNode *head = new RBNode;
	if ( !head )
		return 0;
	head->value = INT_MIN;
	head->rightChild = null( INT_MIN );
	head->leftChild = null( INT_MIN );
	head->color = 0;
	return head;
}

void printInOrderRecur( RBNode *node )
{
	if ( node!=null(0) )
	{
		printInOrderRecur( node->leftChild );
		cout << node->value << ", " << node->color << endl;
		printInOrderRecur( node->rightChild );
	}
}

/*
Rotate with left child.
Before rotation:
            grand                grand
			  *                    *
			*                        *
		parent          or           parent
		  *                            *
		*   *                        *   *
	child     C                   child    C
	  *	                            *
	*   *                         *   *
  A       B                     A       B
After rotation:
            grand                grand
			  *                    *
			*                        *
         child          or           child
		  *                             *
		*   *                         *   *    
	  A     parent                  A    parent
	          *                             *
			*   *                         *   *
		  B		  C                     B       C
*/

// Given a node, rotate it with its left child, let it be the new parent node, and return the new parent node
void rotateWithLeftChild( RBNode *&parent )
{
	if ( parent->leftChild==null(0) )
		return;
	RBNode *child = parent->leftChild;
	parent->leftChild = child->rightChild;
	child->rightChild = parent;
	parent = child;
}

//void rotateWithLeftChild( RBNode *parent, RBNode *child, RBNode *grand )
//{
//	parent->leftChild = child->rightChild;
//	child->rightChild = parent;
//	if ( parent==grand->leftChild )
//		grand->leftChild = child;
//	else if ( parent==grand->rightChild )
//		grand->rightChild = child;
//}

/*
Rotate with right child.
Before rotation:
       grand                                 grand
         *                                     *
           *                                 *
           parent             or          parent
             *                              *
           *   *                          *   *
         C      child                   C      child
                  *                              *
                *   *                          *   *
              A       B                      A       B
After rotation:
       grand                                 grand
         *                                     * 
           *                                 *
           child              or          child
              *                             *
            *   *                         *   *
        parent    B                    parent   B
          *                              *
        *   *                          *   *
      C       A                      C       A
*/

// Given a node, rotate it with its right child, let it be the new parent, and return the new parent.
void rotateWithRightChild( RBNode *&parent )
{
	if ( parent->rightChild==null(0) )
		return;
	RBNode *child = parent->rightChild;
	parent->rightChild = child->leftChild;
	child->leftChild = parent;
	parent = child;
}

//void rotateWithRightChild( RBNode *parent, RBNode *child, RBNode *grand )
//{
//	parent->rightChild = child->leftChild;
//	child->leftChild = parent;
//	if ( parent==grand->leftChild )
//		grand->leftChild = child;
//	else if ( parent==grand->rightChild )
//		grand->rightChild = child;
//}

//void Reorient( RBNode* current, RBNode* parent, RBNode* grand, RBNode* great )
//{
//	// make X red and its two children black
//	current->color = 0;
//	current->leftChild->color = 1;
//	current->rightChild->color = 1;
//
//	// if X's parent is red
//	if ( parent->color==0 )
//	{
//		grand->color = 0;
//		if ( current==parent->leftChild )
//		{
//			// case 1: left outside violation
//			if ( parent==grand->leftChild ) 
//			{
//				parent->color = 1;
//				rotateWithLeftChild( grand, parent, great );
//				//grand = great;			
//			}
//			// case 4: right inside violation
//			else if ( parent==grand->rightChild ) 
//			{
//				current->color = 1; 
//				rotateWithLeftChild( parent, current, grand );
//				rotateWithRightChild( grand, current, great );
//				//grand = great; parent = great;
//			}			
//		}
//		else if ( current==parent->rightChild )
//		{
//			// case 2: right outside violation
//			if ( parent==grand->rightChild ) 
//			{
//				parent->color = 1;
//				rotateWithRightChild( grand, parent, great );
//				//grand = great;
//			}
//			// case 3: left inside violation
//			else if ( parent==grand->leftChild ) 
//			{
//				current->color = 1;
//				rotateWithRightChild( parent, current, grand );
//				rotateWithLeftChild( grand, current, great );	
//				//grand = great; parent = great;
//			}
//		}
//	}
//}


// Given a node and the value of one of its grand children, rotate the grand child with its parent based on their values.
RBNode *rotate( RBNode *grand, int data )
{
	if ( data < grand->value )
	{
		data < grand->leftChild->value ? 
			rotateWithLeftChild( grand->leftChild ) : // LL
			rotateWithRightChild( grand->leftChild ); // LR
		return grand->leftChild;
	}
	else
	{
		data < grand->rightChild->value ?
			rotateWithLeftChild( grand->rightChild ) : // RL
			rotateWithRightChild( grand->rightChild ); // RR
		return grand->rightChild;
	}
}

// 
void reorient( RBNode *current, RBNode *parent, RBNode *grand, RBNode *great, int data )
{
	current->color = 0;
	current->leftChild->color = 1;
	current->rightChild->color = 1;
	if ( parent->color==0 )
	{
		grand->color = 0;
		if ( data<parent->value != data<grand->value )
			parent = rotate( grand, data );
		grand = rotate( great, parent->value );

	}
}

bool InsertIter( RBNode *head, int data )
{
	RBNode *current = head;	RBNode *parent = head; RBNode *grand = head; RBNode *great = head;
	null( data );

	while ( current->value!=data )
	{
		great = grand; grand = parent; parent = current;
		current = ( data < current->value ) ? current->leftChild : current->rightChild;
		if ( current->leftChild->color==0 && current->rightChild->color==0 )
		{
			Reorient( current, parent, grand, great );
			head->rightChild->color = 1;
			//printInOrderRecur( head ); // for debugging
		}
	}

	if ( current!=null(data) ) // if the value is already in the tree
		return false;

	// insert a new node with the given value
	current = new RBNode;
	current->value = data;
	current->leftChild = null( INT_MIN );
	current->rightChild = null( INT_MIN );
	current->color = 0;
	if ( data < parent->value )
		parent->leftChild = current;
	else
		parent->rightChild = current;

	// make sure that the newly added node does not violate the color rule
	Reorient( current, parent, grand, great );
	head->rightChild->color = 1;

	return true;
}

RBNode *findMinIter( RBNode *node )
{
	if ( node==null(0) || node->leftChild==null(0) )
		return node;
	while ( node->leftChild != null(0) )
	{
		node = node->leftChild;
	}
	return node;
}

bool removeMinIter( RBNode *head )
{
	// if root is null
	if ( head->rightChild==null(0) )
		return false;

	// if root->leftChild is null
	if ( head->rightChild->leftChild==null(0) )
	{
		RBNode *temp = head->rightChild;
		temp->rightChild->color = 1;
		head->rightChild = temp->rightChild;
		delete temp;
		return true;
	}

	// if root->leftChild is not null
	RBNode *current = head->rightChild; 
	RBNode *parent = head; 
	RBNode *grand = head;
	if ( current->leftChild->color==0 ) // if root->leftChild is red
	{
		grand = head;
		parent = head->rightChild;
		current = head->rightChild->leftChild;
	}
	else // if root->leftChild is black
	{
		if ( current->rightChild->color==1 ) // if root->leftChild is black and root->rightChild is black
			current->color = 0;
		else // if root->leftChild is black and root->rightChild is red
		{
			current->color = 0; current->rightChild->color = 1;
			rotateWithRightChild( current, current->rightChild, head );	
			grand = head;
			parent = head->rightChild;
		}
	}
	//printInOrderRecur( head ); // for test

	while ( current->leftChild!=null(0) )
	{
		grand = parent; parent = current; current = current->leftChild;
		if ( current->leftChild->color==1 && current->rightChild->color==1 ) // if X has two black children
		{
			if ( parent->rightChild->leftChild->color==1 && parent->rightChild->rightChild->color==1 ) // if T has two black children
			{
				parent->color = 1; current->color = 0; parent->rightChild->color = 0;
				//cout << "1\n"; // for test
			}
			else if ( parent->rightChild->rightChild->color==0 ) // if T's right child is red
			{
				current->color = 0; parent->color = 1; parent->rightChild->color = 0; parent->rightChild->rightChild->color = 1;
				rotateWithRightChild( parent, parent->rightChild, grand );
				if ( grand==head )
					grand = grand->rightChild;
				else
					grand = grand->leftChild;
				//cout << "2\n"; // for test
			}
			else if ( parent->rightChild->leftChild->color==0 ) // if T's right child is black and left child is red
			{
				current->color = 0;
				parent->color = 1;
				rotateWithLeftChild( parent->rightChild, parent->rightChild->leftChild, parent );
				rotateWithRightChild( parent, parent->rightChild, grand );
				if ( grand==head )
					grand = grand->rightChild;
				else
					grand = grand->leftChild;
				//cout << "3\n"; // for test
			}
		}
		else if ( current->leftChild->color==0 ) // if X's left child is red
		{
			grand = parent;
			parent = current;
			current = current->leftChild;
			//cout << "4\n"; // for test
		}
		else if ( current->rightChild->color==0 ) // if X's left child is black and X's right child is red
		{
			current->color = 0;
			current->rightChild->color = 1;
			rotateWithRightChild( current, current->rightChild, parent );
			grand = parent;
			parent = parent->leftChild;
			//cout << "5\n"; // for test
		}
		//printInOrderRecur( head ); // for test
	}
	
	if ( current->color==1 )
	{
		cout << "Error." << endl;
		return false;
	}

	RBNode *temp = current;
	parent->leftChild = current->rightChild;
	delete temp;
	head->rightChild->color = 1;
	return true;
}

RBNode *findIter( RBNode *head, int data )
{
	if ( head->rightChild==null(0) )
		return null(0);

	null( data );
	head = head->rightChild;
	while ( head->value!=data )
	{
		if ( data < head->value )
			head = head->leftChild;
		else if ( data > head->value )
			head = head->rightChild;
	}
	return head;
}

// assume data!=X->value
void ReorientLeftChild( RBNode *&X, RBNode *&P, RBNode *&G, int data, RBNode *head )
{
	if ( X->color==0 )
		return;
	RBNode *T = P->rightChild; // T is X's sibling
	// Case 1: X has two black children
	if ( X->leftChild->color==1 && X->rightChild->color==1 )
	{
		// Case 1-1: T has two black children
		if ( T->rightChild->color==1 && T->leftChild->color==1 )
		{
			X->color = 0; P->color = 1; T->color = 0;
			//cout << "L1-1\n"; // for test
		}
		// Case 1-2: T's right child is red.
		else if ( T->rightChild->color==0 )
		{
			X->color = 0; P->color = 1; T->color = 0; T->rightChild->color = 1;
			bool temp = ( P==G->rightChild );
			rotateWithRightChild( P, T, G );
			if ( temp ) G = G->rightChild; else G = G->leftChild;
			//cout << "L1-2\n"; // for test
		}
		// Case 1-3: T's right child is black; T's left child is red.
		else
		{
			X->color = 0; P->color = 1;
			bool temp = ( P==G->rightChild );
			rotateWithLeftChild( T, T->leftChild, P );
			rotateWithRightChild( P, P->rightChild, G );
			if ( temp ) G = G->rightChild; else G = G->leftChild;
			//cout << "L1-3\n"; // for test
		}
	}
	// Case 2: X's left child is red; X's right child is black.
	else if ( X->leftChild->color==0 && X->rightChild->color==1 )
	{
		// Case 2-1: data >= X.value
		if ( data >= X->value )
		{
			X->leftChild->color = 1; X->color = 0;
			rotateWithLeftChild( X, X->leftChild, P );
			G = P; P = P->leftChild;
			//cout << "L2-1\n"; // for test
		}
		// Case 2-2: data < X.value
		else 
		{
			G = P; P = X; X = X->leftChild;
			//cout << "L2-2\n"; // for test
		}
	}
	// Case 3: X's left child is black; X's right child is red.
	else if ( X->leftChild->color==1 && X->rightChild->color==0 )
	{
		// Case 3-1: data > X.value
		if ( data > X->value )
		{
			G = P; P = X; X = X->rightChild;
			//cout << "L3-1\n"; // for test
		}
		// Case 3-2: data <= X.value
		else 
		{
			X->color = 0; X->rightChild->color = 1;
			rotateWithRightChild( X, X->rightChild, P );
			G = P; P = P->leftChild;
			//cout << "L3-2\n"; // for test
		}
	}
	// Case 4: X's two children are both red.
	else
	{
		// Case 4-1: data < X.value
		if ( data < X->value )
		{
			G = P; P = X; X = X->leftChild;
			//cout << "L4-1\n"; // for test
		}
		// Case 4-2: data > X.value
		else if ( data > X->value )
		{
			G = P; P = X; X = X->rightChild;
			//cout << "L4-2\n"; // for test
		}
	}
	head->color = 0;
	head->leftChild->color = 1;
}

void ReorientRightChild( RBNode *&X, RBNode *&P, RBNode *&G, int data, RBNode *head )
{
	if ( X->color==0 )
		return;
	RBNode *T = P->leftChild; // T is X's sibling
	// Case 1: X has two black children
	if ( X->leftChild->color==1 && X->rightChild->color==1 )
	{
		// Case 1-1: T has two black children
		if ( T->rightChild->color==1 && T->leftChild->color==1 )
		{
			X->color = 0; P->color = 1; T->color = 0;
			//cout << "R1-1\n"; // for test
		}
		// Case 1-2: T's left child is red.
		else if ( T->leftChild->color==0 )
		{
			X->color = 0; P->color = 1; T->color = 0; T->leftChild->color = 1;
			bool temp = ( P==G->rightChild );
			rotateWithLeftChild( P, T, G );
			if ( temp ) G = G->rightChild; else G = G->leftChild;
			//cout << "R1-2\n"; // for test
		}
		// Case 1-3: T's left child is black; T's right child is red.
		else
		{
			X->color = 0; P->color = 1;
			bool temp = ( P==G->rightChild );
			rotateWithRightChild( T, T->rightChild, P );
			rotateWithLeftChild( P, P->leftChild, G );
			if ( temp ) G = G->rightChild; else G = G->leftChild;
			//cout << "R1-3\n"; // for test
		}
	}
	// Case 2: X's right child is red; X's left child is black.
	else if ( X->rightChild->color==0 && X->leftChild->color==1 )
	{
		// Case 2-1: data <= X.value
		if ( data <= X->value )
		{
			X->rightChild->color = 1; X->color = 0;
			rotateWithRightChild( X, X->rightChild, P );
			G = P; P = P->rightChild;
			//cout << "R2-1\n"; // for test
		}
		// Case 2-2: data > X.value
		else 
		{
			G = P; P = X; X = X->rightChild;
			//cout << "R2-2\n"; // for test
		}
	}
	// Case 3: X's right child is black; X's left child is red.
	else if ( X->rightChild->color==1 && X->leftChild->color==0 )
	{
		// Case 3-1: data < X.value
		if ( data < X->value )
		{
			G = P; P = X; X = X->leftChild;
			//cout << "R3-1\n"; // for test
		}
		// Case 3-2: data >= X.value
		else 
		{
			X->color = 0; X->leftChild->color = 1;
			rotateWithLeftChild( X, X->leftChild, P );
			G = P; P = P->rightChild;
			//cout << "R3-2\n"; // for test
		}
	}
	// Case 4: X's two children are both red.
	else
	{
		// Case 4-1: data > X.value
		if ( data > X->value )
		{
			G = P; P = X; X = X->rightChild;
			//cout << "R4-1\n"; // for test
		}
		// Case 4-2: data < X.value
		else if ( data < X->value )
		{
			G = P; P = X; X = X->leftChild;
			//cout << "R4-2\n"; // for test
		}
	}
	head->color = 0;
	head->leftChild->color = 1;
}

bool removeIter( RBNode *head, int data )
{
	null(data);

	// find the node containing the given value
	RBNode *current = head, *parent = head, *grand = head;
	RBNode *X, *P, *G;
	while ( current->value!=data )
	{
		grand = parent; parent = current;
		if ( current->value < data )
		{
			current = current->rightChild;
			if ( current==null(data) )
				break;
			X = current; P = parent; G = grand;
			ReorientRightChild( X, P, G, data, head );
			current = X; parent = P; grand = G;
		}
		else
		{
			current = current->leftChild;
			if ( current==null(data) )
				break;
			X = current; P = parent; G = grand;
			ReorientLeftChild( X, P, G, data, head );
			current = X; parent = P; grand = G;
		}
	}

	if ( current==null(data) ) // the value not in the tree
		return false;

	// find the minimum in the right subtree of the node containing the given value
	if ( current->leftChild!=null(data) && current->rightChild!=null(data) )
	{
		RBNode *found = current;
		grand = parent; parent = current; current = current->rightChild;
		X = current; P = parent; G = grand;
		ReorientRightChild( X, P, G, data, head );
		current = X; parent = P; grand = G;
		while ( current->leftChild!=null(data) )
		{
			grand = parent; parent = current; current = current->leftChild;
			X = current; P = parent; G = grand;
			ReorientLeftChild( X, P, G, data, head );
			current = X; parent = P; grand = G;
		}
		found->value = current->value;
		RBNode *temp = current;
		if ( current==parent->rightChild )
			parent->rightChild = current->rightChild;
		else
			parent->leftChild = current->rightChild;
		delete temp;
	}
	else if ( current->leftChild!=null(data) )
	{
		RBNode *temp = current;
		if ( current==parent->rightChild )
			parent->rightChild = current->leftChild;
		else
			parent->leftChild = current->leftChild;
		delete temp;
	}
	else
	{
		RBNode *temp = current;
		if ( current==parent->rightChild )
			parent->rightChild = current->rightChild;
		else
			parent->leftChild = current->rightChild;
		delete temp;
	}
	head->rightChild->color = 1;
	return true;
}

int main()
{
	// illustration of InsertIter
	cout << "***Illustration of InsertIter***\n";
	int n;
	cout << "Enter n:\n";
	cin >> n;

	RBNode *t1 = BuildRBT();

	cout << endl;
	srand(time(NULL));
	for ( int i=0; i<n; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		InsertIter( t1, data );
		// cout << "After inserting " << data << ":" << endl; // for debugging
		// printInOrderRecur( t1 ); // for debugging
	}

	cout << "\n\nThe tree:\n";
	printInOrderRecur( t1 );
	
	// illustration of findIter
	cout << "\n\n***Illustration of findIter***\n";
	int data;
	cout << "Enter the value:\n";
	cin >> data;
	RBNode *found = findIter( t1, data );
	if ( found==null(0) )
		cout << data << " not found in t1.\n";
	else
		cout << data << " found in t1.\n";

	// illustration of findMinIter
	cout << "\n\nIllustration of findMinIter***\n";
	RBNode *found2 = findMinIter( t1->rightChild );
	if ( found2!=null(0) )
		cout << "The minimum of t1: " << found2->value << endl;

	// illustration of removeMinIter
	cout << "\n\n***Illustration of removeMinIter***\n";
	bool result = removeMinIter( t1 );
	if ( result )
	{
		cout << "After removing the minimum element in t1:\n";
		printInOrderRecur( t1 );
	}

	// illustration of removeIter
	cout << "\n\n***Illustration of removeIter***\n";
	int data2;
	cout << "Enter data2:\n";
	cin >> data2;

	removeIter( t1, data2 );
	cout << "After removing " << data2 << ":\n";
	printInOrderRecur( t1 );

	system("pause");
	return 0;
}