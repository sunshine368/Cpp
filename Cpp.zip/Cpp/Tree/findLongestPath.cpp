/* 
Find the depth of the longest path in a binary search tree (no duplicates) 
and return the leaf node of the longest path.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *leftChild;
	Node *rightChild;
};

void InsertNode( Node **pt, int data )
{
	if ( (*pt)==0 )
	{
		(*pt) = (Node*)malloc( sizeof(Node) );
		(*pt)->value = data;
		(*pt)->leftChild = 0;
		(*pt)->rightChild = 0;
	}
	else
	{
		if ( data > (*pt)->value )
			InsertNode( &((*pt)->rightChild), data );
		else if ( data < (*pt)->value )
			InsertNode( &((*pt)->leftChild), data );
		else
			return;
	}
}

Node* BuildBST( int A[], int n )
{
	Node *root = 0;
	for ( int i=0; i<n; i++ )
	{
		InsertNode( &root, A[i] );
	}
	return root;
}

void findLongestPathHelper( Node *pt, int count, int *max, int *leaf )
{
	if ( pt!=0 )
	{
		++count;
		findLongestPathHelper( pt->leftChild, count, max, leaf );
		findLongestPathHelper( pt->rightChild, count, max, leaf );
		if ( pt->leftChild==0 && pt->rightChild==0 )
		{
			if ( count>(*max) )
			{
				(*max) = count;
				(*leaf) = pt->value;
			}
			cout << pt->value << " is a leaf node." << endl; // leaf nodes
		}
	}
}

int findLongestPath( Node *root )
{
	int count = 0;
	int temp = 0;
	int *max = &temp;
	int tmp = 0;
	int *leaf = &tmp;
	findLongestPathHelper( root, count, max, leaf );
	cout << *leaf << " is the leaf node of the longest path.\n";
	return *max;
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));
	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; i++ )
		A[i] = rand()%100;

	cout << "The array:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	Node *root = BuildBST( A, n );

	int result = findLongestPath( root );

	cout << "Depth of the longest path: " << result << endl;

	system("pause");
	return 0;
}