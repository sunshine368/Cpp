#include <iostream>
#include <ctime>
using namespace std;

struct RBNode
{
	int value;
	int color; // 0 of red; 1 for black
	RBNode *leftChild;
	RBNode *rightChild;
};

// nullNode: always black, both the rightChild and the leftChild point to itself
RBNode *null( int data )
{
	static RBNode *nullNode = new RBNode;
	nullNode->value = data;
	nullNode->leftChild = nullNode;
	nullNode->rightChild = nullNode;
	nullNode->color = 1;
	return nullNode;
}

// head: always red, contains the smallest integer, its rightChild points to the real root
RBNode *BuildRBT()
{
	RBNode *head = new RBNode;
	if ( !head )
		return 0;
	head->value = INT_MIN;
	head->rightChild = null( INT_MIN );
	head->leftChild = null( INT_MIN );
	head->color = 0;
	return head;
}

void printInOrderRecur( RBNode *node )
{
	if ( node!=null(0) )
	{
		printInOrderRecur( node->leftChild );
		cout << node->value << ", " << node->color << endl;
		printInOrderRecur( node->rightChild );
	}
}

// Given a node X, its parent P, its grandparent G s.t. X!=P, P!=G, switch X and P. That is, make G
// the parent of X and X the parent of P.
void Rotate( RBNode* &X, RBNode* &P, RBNode* &G )
{
	if ( X==P || P==G )
    {
        cout << "Parent and child are the same. No rotation carried out.";
        return;
    }
    
    if ( X==P->leftChild )
    {
        if ( P==G->leftChild )
            G->leftChild = X;
        else
            G->rightChild = X;
        P->leftChild = X->rightChild; X->rightChild = P;
    }
    else if ( X==P->rightChild )
    {
        if ( P==G->leftChild )
            G->leftChild = X;
        else
            G->rightChild = X;
        P->rightChild = X->leftChild; X->leftChild = P;
    }
}

// Given a node X, its parent P, its grandparent G, and its great grandparent GG s.t. X->color = red,
// P->color = red, G->color = black, apply single or double rotation based on whether there is an
// inside or outside violation.
void Reorient( RBNode* X, RBNode* P, RBNode* G, RBNode* GG, RBNode* head )
{
    if ( X->color!=0 || P->color!=0 )
    {
        cout << "Parent and child are not both red";
        return;
    }
    
    if ( X==P->leftChild )
    {
        if ( P==G->leftChild )
        {
            Rotate(P, G, GG);
            P->color = 1; G->color = 0;
            G = GG;
        }
        else if ( P==G->rightChild )
        {
            Rotate(X, P, G);
            Rotate(X, G, GG);
            X->color = 1; G->color = 0;
            G = GG; RBNode* temp = P; P = X; X = temp;
        }
    }
    else if ( X==P->rightChild )
    {
        if ( P==G->rightChild )
        {
            Rotate( P, G, GG );
            P->color = 1; G->color = 0;
            G = GG;
        }
        else if ( P==G->leftChild )
        {
            Rotate( X, P, G );
            Rotate( X, G, GG );
            X->color = 1; G->color = 0;
            G = GG; RBNode* temp = P; P = X; X = temp;
        }
    }
    
    head->rightChild->color = 1;
}

bool Insert( RBNode *head, int data )
{
	RBNode *current = head;	RBNode *parent = head; RBNode *grand = head; RBNode *great = head;
	null( data );

	while ( current->value!=data )
	{
		if ( current->leftChild->color==0 && current->rightChild->color==0 )
        {
            current->color = 0; current->leftChild->color = 1; current->rightChild->color = 1;
            if ( parent->color==0 )
                Reorient( current, parent, grand, great, head );
            great = grand; grand = parent; parent = current;
            if ( data < current->value )
                current = current->leftChild;
            else
                current = current->rightChild;
        }
	}

	if ( current!=null(data) ) // if the value is already in the tree
		return false;

	// insert a new node with the given value
	current = new RBNode;
	current->value = data;
	current->leftChild = null( INT_MIN );
	current->rightChild = null( INT_MIN );
	current->color = 0;
	if ( data < parent->value )
		parent->leftChild = current;
	else if ( data > parent->value )
		parent->rightChild = current;

	// make sure that the newly added node does not violate the color rule
	Reorient( current, parent, grand, great, head );
	return true;
}

// Given a node X, its sibling T, its parent P, its grandparent G and a target value s.t.
// P->color = red, X = P->leftChild, make X red without violating any red black tree properties.
void MakeRedLeft( RBNode* &X, RBNode* &T, RBNode* &P, RBNode* &G, int target )
{
    int flag;
    if ( X->leftChild->color==1 && X->rightChild->color==1 )
    {
        if ( T->leftChild->color==1 && T->rightChild->color==1 )
        {
            X->color = 0; P->color = 1; T->color = 0;
        }
        else if ( T->rightChild->color==0 )
        {
            X->color = 0; P->color = 1; T->color = 0; T->rightChild->color = 1;
            flag = (P==G->rightChild ? 1 : 0);
            Rotate( T, P, G );
            G = (flag==1 ? G->rightChild : G->leftChild );
        }
        else
        {
            X->color = 0; P->color = 1;
            flag = ( P==G->rightChild ? 1 : 0 );
            Rotate( T->leftChild, T, P );
            Rotate( P->rightChild, P, G );
            G = (flag==1 ? G->rightChild : G->leftChild);
        }
    }
    else if ( X->leftChild->color==0 && X->rightChild->color==1 )
    {
        if ( target >= X->value )
        {
            X->leftChild->color = 1; X->color = 0;
            Rotate( X->leftChild, X, P );
            G = P; P = P->leftChild;
        }
        else
        {
            G = P; P = X; X = X->leftChild;
        }
    }
    else if ( X->leftChild->color==1 && X->rightChild->color==0 )
    {
        if ( target > X->value )
        {
            G = P; P = X; X = X->rightChild;
        }
        else
        {
            X->color = 0; X->rightChild->color = 1;
            Rotate( X->rightChild, X, P );
            G = P; P = P->leftChild;
        }
    }
    else
    {
        if ( target < X->value )
        {
            G = P; P = X; X = X->leftChild;
        }
        else if ( target > X->value )
        {
            G = P; P = X; X = X->rightChild;
        }
    }
}

// Given a node X, its sibling T, its parent P, its grandparent G and a target value s.t.
// P->color = red, X = P->rightChild, make X red without violating any red black tree properties.
void MakeRedRight( RBNode* &X, RBNode* &T, RBNode* &P, RBNode* &G, int target )
{
    int flag;
    if ( X->leftChild->color==1 && X->rightChild->color==1 )
    {
        if ( T->leftChild->color==1 && T->rightChild->color==1 )
        {
            X->color = 0; P->color = 1; T->color = 0;
        }
        else if ( T->leftChild->color==0 )
        {
            X->color = 0; P->color = 1; T->color = 0; T->rightChild->color = 1;
            flag = (P==G->rightChild ? 1 : 0);
            Rotate( T, P, G );
            G = (flag==1 ? G->rightChild : G->leftChild );
        }
        else
        {
            X->color = 0; P->color = 1;
            flag = ( P==G->rightChild ? 1 : 0 );
            Rotate( T->rightChild, T, P );
            Rotate( P->leftChild, P, G );
            G = (flag==1 ? G->rightChild : G->leftChild);
        }
    }
    else if ( X->rightChild->color==0 && X->leftChild->color==1 )
    {
        if ( target <= X->value )
        {
            X->rightChild->color = 1; X->color = 0;
            Rotate( X->rightChild, X, P );
            G = P; P = P->rightChild;
        }
        else
        {
            G = P; P = X; X = X->rightChild;
        }
    }
    else if ( X->rightChild->color==1 && X->leftChild->color==0 )
    {
        if ( target < X->value )
        {
            G = P; P = X; X = X->leftChild;
        }
        else
        {
            X->color = 0; X->leftChild->color = 1;
            Rotate( X->leftChild, X, P );
            G = P; P = P->rightChild;
        }
    }
    else
    {
        if ( target < X->value )
        {
            G = P; P = X; X = X->leftChild;
        }
        else if ( target > X->value )
        {
            G = P; P = X; X = X->rightChild;
        }
    }
}

// Given a node X, its parent P s.t. P->color = red, and its grand parent G, make X red and avoid any
// conflict with the red black tree properties by applying rotations and color flips if necessary.
void MakeRed( RBNode* &X, RBNode* &P, RBNode* &G, int target, RBNode* head )
{
    if ( X->color==0 )
    {
        cout << "The current node is already red";
        return;
    }
    
    RBNode* T;
    if ( X==P->leftChild )
    {
        T = P->rightChild;
        MakeRedLeft( X, T, P, G, target );
    }
    else if ( X==P->rightChild )
    {
        T = P->leftChild;
        MakeRedRight( X, T, P, G, target );
    }
}

// Given a node X, its parent P, its grandparent G, return the node to be deleted in terms of X,
// together with its parent in terms of P and grandparent in terms of G.
void FindToBeDeleted( RBNode* &X, RBNode* &P, RBNode* &G, RBNode* head )
{
    RBNode* F = X;
    if ( X->rightChild==0 )
        X = X->rightChild;
    
    if ( X->leftChild==null(INT_MIN) || X->rightChild==null(INT_MIN) )
    {
        if ( X!=F )
        {
            int temp = X->value; X->value = F->value; F->value = temp;
        }
        return;
    }
    
    G = P; P = X; X = X->rightChild;
    MakeRedRight( X, P, G, INT_MAX, head );
    
    while ( X->leftChild!=null(INT_MIN) )
    {
        G = P; P = X; X = X->leftChild;
        MakeRedLeft( X, P, G, INT_MIN, head );
    }
    
    int temp = X->value; X->value = F->value; F->value = temp;
}

// Given a node X and its parent P, delete X.
void Delete( RBNode* X, RBNode* P )
{
    RBNode* D = X;
    if ( X->leftChild!=null(INT_MIN) )
    {
        if ( X==P->rightChild )
            P->rightChild = X->leftChild;
        else
            P->leftChild = X->leftChild;
    }
    else
    {
        if ( X==P->rightChild )
            P->rightChild = X->rightChild;
        else
            P->leftChild = X->rightChild;
    }
    delete D;
}

bool remove( RBNode *head, int data )
{
	null(data);

	// find the node containing the given value
	RBNode *current = head, *parent = head, *grand = head;
	Find( current, parent, grand, data, head );

	if ( current==null(data) ) // the value not in the tree
		return false;

    FindToBeDeleted( current, parent, grand, data, head );
    
    Delete( current, parent );
    
    head->color = 0;
	head->rightChild->color = 1;
	return true;
}

int main()
{
	// illustration of InsertIter
	cout << "***Illustration of InsertIter***\n";
	int n;
	cout << "Enter n:\n";
	cin >> n;

	RBNode *t1 = BuildRBT();

	cout << endl;
	srand(time(NULL));
	for ( int i=0; i<n; ++i )
	{
		int data = rand()%100;
		cout << data << endl;
		Insert( t1, data );
		// cout << "After inserting " << data << ":" << endl; // for debugging
		// printInOrderRecur( t1 ); // for debugging
	}

	cout << "\n\nThe tree:\n";
	printInOrderRecur( t1 );
	
	// illustration of find
	cout << "\n\n***Illustration of findIter***\n";
	int data;
	cout << "Enter the value:\n";
	cin >> data;
	RBNode *found = Find( t1, data );
	if ( found==null(0) )
		cout << data << " not found in t1.\n";
	else
		cout << data << " found in t1.\n";

	// illustration of remove 
	cout << "\n\n***Illustration of removeIter***\n";
	int data2;
	cout << "Enter data2:\n";
	cin >> data2;

	Remove( t1, data2 );
	cout << "After removing " << data2 << ":\n";
	printInOrderRecur( t1 );

	system("pause");
	return 0;
}
