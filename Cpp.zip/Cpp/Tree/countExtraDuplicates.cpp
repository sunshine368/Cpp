/*
Write an algorithm to print out how many extra duplicates there are in 
a binary search tree.
Note that: In this program, we allow duplicates in binary search tree, 
which is different from usual binary search tree.
If a duplicate is inserted in the right subtree, we count the number of
duplicates by in-order traversal.
If a duplicate is inserted in the left subtree, we count the number of
duplicates using none of in-order, pre-order, or post-order traversal.
Instead, we check the right subtree first, then the nodes itself, and
finally the left subtree.
*/

#include <iostream>
using namespace std;

struct Node 
{
	int value;
	Node *leftChild;
	Node *rightChild;
};

// Insert a duplicate node in the right subtree.
void InsertNode( Node **pt, int data )
{
	if ( (*pt)==0 )
	{
		(*pt) = (Node*)malloc( sizeof(Node) );
		(*pt)->value = data;
		(*pt)->leftChild = 0;
		(*pt)->rightChild = 0;
	}
	else
	{
		if ( data >= (*pt)->value )
			InsertNode( &((*pt)->rightChild), data );
		else
			InsertNode( &((*pt)->leftChild), data );
	}
}

// Insert a duplicate node in the left subtree.
//void InsertNode( Node **pt, int data )
//{
//	if ( (*pt)==0 )
//	{
//		(*pt) = (Node*)malloc( sizeof(Node) );
//		(*pt)->value = data;
//		(*pt)->leftChild = 0;
//		(*pt)->rightChild = 0;
//	}
//	else
//	{
//		if ( data > (*pt)->value )
//			InsertNode( &((*pt)->rightChild), data );
//		else
//			InsertNode( &((*pt)->leftChild), data );
//	}
//}

Node *BuildBST( int A[], int n )
{
	Node *root = 0;
	for ( int i=0; i<n; i++ )
	{
		InsertNode( &root, A[i] );
	}
	return root;
}

// When a duplicate node is inserted in the right subtree, the following program is used.
void countExtraDuplicatesHelper( Node *pt, int *prev, int *count )
{
	if ( pt!=0 )
	{
		countExtraDuplicatesHelper( pt->leftChild, prev, count );
		if ( (*prev) == (pt->value) )
		{
			(*count)++;
		}
		else
		{
			if ( (*count)>0 )
				cout << *prev << ": " << *count << endl;
			(*count) = 0;
			(*prev) = (pt->value);
		}
		countExtraDuplicatesHelper( pt->rightChild, prev, count );	
	}
}

// When a duplicate node is inserted in the left subtree, the following program is used.
//void countExtraDuplicatesHelper( Node *pt, int *prev, int *count )
//{
//	if ( pt!=0 )
//	{
//		countExtraDuplicatesHelper( pt->rightChild, prev, count );
//		if ( (*prev) == (pt->value) )
//		{
//			(*count)++;
//		}
//		else
//		{
//			if ( (*count)>0 )
//				cout << *prev << ": " << *count << endl;
//			(*count) = 0;
//			(*prev) = (pt->value);
//		}
//		countExtraDuplicatesHelper( pt->leftChild, prev, count );	
//	}
//}

void countExtraDuplicates( Node *root )
{
	int tmp = INT_MIN;
	int *prev = &tmp;
	int temp = 0;
	int *count = &temp;
	countExtraDuplicatesHelper( root, prev, count );
	if ( (*count)>0 )
		cout << *prev << ": " << *count << endl;
}

void DisplayInOrderAux( Node *pt )
{
	if ( pt==0 )
		return;
	DisplayInOrderAux( pt->leftChild );
	cout << pt->value << endl;
	DisplayInOrderAux( pt->rightChild );
}

void DisplayInOrder( Node *root )
{
	DisplayInOrderAux( root );
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; i++ )
	{
		cout << "Please enter A[" << i << "]: ";
		cin >> A[i];
	}
	cout << endl;

	cout << "The array:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	Node *root = BuildBST( A, n );

	DisplayInOrder( root );

	countExtraDuplicates( root );

	system("pause");
	return 0;
}