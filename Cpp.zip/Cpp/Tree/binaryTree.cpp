#include <iostream>
#include <ctime>
#include <stack>
#include <queue>
using namespace std;

struct Node
{
	int value;
	Node *leftChild;
	Node *rightChild;
};

/* 
Build a binary tree based on a given array of integers. Return the root node.
However, this algorithm does not reflect the dynamic property of the tree.
*/
void BuildBinaryTreeStaticAux( Node *node, int data )
{
	node->value = data;
	node->leftChild = 0;
	node->rightChild = 0;
}

Node *BuildBinaryTreeStatic( int* A, int n )
{
	Node *nodes = (Node*)malloc( sizeof(Node)*n );
	for ( int i=0; i<n; ++i )
	{
		BuildBinaryTreeStaticAux( &nodes[i], A[i] );
		if ( i==(2*((i-1)/2)+1) )
		{
			(&nodes[(i-1)/2])->leftChild = &nodes[i];
		}
		else if ( i==(2*((i-1)/2)+2) )
		{
			(&nodes[(i-1)/2])->rightChild = &nodes[i];
		}
	}
	return &nodes[0];
}

/*
To utilize the dynamic property of the tree, we add another struct called Tree which
contains the size of the tree, and a Node pointer to the root of the tree. 
The following program is based on this implementation of tree buildup.
*/
struct Tree
{
	int size;
	Node *root;
};

Tree *BuildBinaryTree( )
{
	Tree *tree = new Tree;
	tree->size = 0;
	tree->root = 0;
	return tree;
}

// insert a new node to the tree; ignore if duplicate
Node *InsertNodeAux( Node *node, int cur, int target )
{
	if ( cur==target/2 )
	{
		return node;
	}
	else if ( cur>target/2 )
	{
		return 0;
	}

	Node *left = InsertNodeAux( node->leftChild, 2*cur, target );
	Node *right = InsertNodeAux( node->rightChild, 2*cur+1, target );
	if ( left!=0 )
		return left;
	else if ( right!=0 )
		return right;
	else
		return 0;
}

bool InsertNode( Tree *tree, int data )  
{
	Node *new_node = new Node;
	if ( !new_node )
		return false;
	new_node->value = data;
	new_node->leftChild = 0;
	new_node->rightChild = 0;	
	++(tree->size);
	int size = tree->size;
	
	if ( size==1 )
	{
		tree->root = new_node;
		return true;
	}
	else
	{
		Node *parent = InsertNodeAux( tree->root, 1, size );
		if ( size==(2*(size/2)) )
			parent->leftChild = new_node;
		else if ( size==(2*(size/2)+1) )
			parent->rightChild = new_node;
		return true;
	}
}


// calculate the size of a given node
int size( Node *node )
{
	if ( node==0 )
		return 0;
	else
		return 1 + size( node->leftChild ) + size( node->rightChild );
}

// calculate the height of a given node
int max( int a, int b )
{
	if ( a>=b )
		return a;
	else 
		return b;
}

int height( Node *node )
{
	if ( node==0 )
		return -1;
	else
		return 1 + max( height( node->leftChild ), height( node->rightChild ) );
}

// make a tree empty
void makeEmptyAux( Node *node )
{
	if ( node!=0 )
	{
		makeEmptyAux( node->leftChild );
		makeEmptyAux( node->rightChild );
		delete node;
		node = 0;
	}
}

void makeEmpty( Tree *tree )
{
	makeEmptyAux( tree->root );
	tree->size = 0;
}

// print preorder
void printPreOrder( Node *node )
{
	if ( node!=0 )
	{
		cout << node->value << endl;
		printPreOrder( node->leftChild );
		printPreOrder( node->rightChild );
	}
}

// print inorder
void printInOrder( Node *node )
{
	if ( node!=0 )
	{
		printInOrder( node->leftChild );
		cout << node->value << endl;
		printInOrder( node->rightChild );
	}
}

// print postorder
void printPostOrder( Node *node )
{
	if ( node!=0 )
	{
		printPostOrder( node->leftChild );
		printPostOrder( node->rightChild );
		cout << node->value << endl;
	}
}

// check for emptiness
bool isEmpty( Tree *tree )
{
	return (tree->size)==0;
}

// form a new tree from a given value and two trees
Tree *merge( Tree *t1, Tree *t2, int data )
{
	Tree *new_tree = BuildBinaryTree();
	Node *new_root = new Node;
	new_root->value = data;
	if ( t1->root==t2->root && t1->root!=0 )
	{
		cout << "Cannot merge a tree with itself.\n";
		new_root->leftChild = 0;
		new_root->rightChild = 0;
		new_tree->size = 1;
	}
	else
	{
		new_root->leftChild = t1->root;
		new_root->rightChild = t2->root;
		new_tree->size = t1->size + t2->size + 1;
		t1->root = 0;
		t2->root = 0;
		delete t1;
		delete t2;
	}
	new_tree->root = new_root;
	return new_tree;
}

// make a copy of a given tree
Node *duplicateAux( Node *node )
{
	if ( node==0 )
		return 0;
	
	Node *new_node = new Node;
	new_node->value = node->value;
	new_node->leftChild = duplicateAux( node->leftChild );
	new_node->rightChild = duplicateAux( node->rightChild );
	return new_node;
}

Tree *duplicate( Tree *old_tree )
{
	Tree *new_tree = new Tree;
	if ( old_tree!=0 )
	{
		new_tree->size = old_tree->size;
		new_tree->root = duplicateAux( old_tree->root );
		return new_tree;
	}
	else
	{
		cout << "Empty tree. No duplicate created.";
		return 0;
	}
}

// In the following, we show iterative algorithms. To do this, we first need to 
// redefine the node.
/*** Version I ***/
struct Node2
{
	int value;	
	int timesPopped;
	Node2 *leftChild;
	Node2 *rightChild;
};

struct Tree2
{
	Node2 *root;
	int size;
};

Tree2* BuildBinaryTree2()
{
	Tree2 *tree = new Tree2;
	tree->size = 0;
	tree->root = 0;
	return tree;
}

Node2* InsertNodeAux2( Node2 *node, int cur, int target )
{
	if ( cur==target/2 )
		return node;
	else if ( cur>target/2 )
		return 0;

	Node2 *left = InsertNodeAux2( node->leftChild, 2*cur, target );
	Node2 *right = InsertNodeAux2( node->rightChild, 2*cur+1, target );
	if ( left!=0 )
		return left;
	else if ( right!=0 )
		return right;
	else
		return 0;
}

bool InsertNode2( Tree2 *tree, int data )
{
	Node2 *new_node = new Node2;
	if ( !new_node )
		return false;
	new_node->value = data;
	new_node->timesPopped = 0;
	new_node->leftChild = 0;
	new_node->rightChild = 0;
	++(tree->size);
	int size = tree->size;

	if ( size==1 )
	{
		tree->root = new_node;
		return true;
	}
	else
	{
		Node2 *parent = InsertNodeAux2( tree->root, 1, size );
		if ( size==(2*(size/2)) )
			parent->leftChild = new_node;
		else if ( size==(2*(size/2)+1) )
			parent->rightChild = new_node;
		return true;
	}
}

// iterative postorder traversal
void printPostOrderIter( Node2 *node )
{
	stack<Node2> StNode;
	if ( node!=0 )
	{
		StNode.push( *node );
		while ( !StNode.empty() )
		{
			Node2* cnode = &StNode.top();
			++(cnode->timesPopped);
			if ( cnode->timesPopped==3 )
			{
				cout << cnode->value << endl;
				StNode.pop();
			}
			else if ( cnode->timesPopped==1 )
			{
				if ( cnode->leftChild!=0 )
					StNode.push( *(cnode->leftChild) );
			}
			else
			{
				if ( cnode->rightChild!=0 )
					StNode.push( *(cnode->rightChild) );
			}
		}
	}
}

// iterative postorder traversal version 2
void printPostOrderIter2( Node2 *node )
{
	stack<Node2*> StNode;
	if ( node!=0 )
	{
		StNode.push( node );
		while ( !StNode.empty() )
		{
			Node2 *cnode = StNode.top();
			++(cnode->timesPopped);
			if ( cnode->timesPopped==3 )
			{
				cout << cnode->value << endl;
				StNode.pop();
			}
			else if ( cnode->timesPopped==1 )
			{
				if ( cnode->leftChild!=0 )
					StNode.push( cnode->leftChild );
			}
			else
			{
				if ( cnode->rightChild!=0 )
					StNode.push( cnode->rightChild );
			}
		}
	}
}

// iterative inorder traversal
void printInOrderIter( Node2 *node )
{
	stack<Node2> StNode;
	if ( node!=0 )
	{
		StNode.push( *node );
		while ( !StNode.empty() )
		{
			Node2 *cnode = &StNode.top();
			++(cnode->timesPopped);
			if ( (cnode->timesPopped)==2 )
			{
				cout << cnode->value << endl;
				StNode.pop();
				if ( cnode->rightChild!=0 )
					StNode.push( *(cnode->rightChild) );
			}
			else if ( cnode->timesPopped==1 )
			{
				if ( cnode->leftChild!=0 )
					StNode.push( *(cnode->leftChild) );
			}
		}
	}
}

// iterative inorder traversal version 2
void printInOrderIter2( Node2 *node )
{
	stack<Node2*> StNode;
	if ( node!=0 )
	{
		StNode.push( node );
		while ( !StNode.empty() )
		{
			Node2 *cnode = StNode.top();
			++(cnode->timesPopped);
			if ( cnode->timesPopped==2 )
			{
				cout << cnode->value << endl;
				StNode.pop();
				if ( cnode->rightChild!=0 )
					StNode.push( cnode->rightChild );
			}
			else if ( cnode->timesPopped==1 )
			{
				if ( cnode->leftChild!=0 )
					StNode.push( cnode->leftChild );
			}
		}
	}
}

// iterative preorder traversal
void printPreOrderIter( Node2 *node )
{
	stack<Node2> StNode;
	if ( node!=0 )
	{
		StNode.push( *node );
		while ( !StNode.empty() )
		{
			Node2 *cnode = &StNode.top();
			++(cnode->timesPopped);
			if ( cnode->timesPopped==1 )
			{
				cout << cnode->value << endl;
				if ( cnode->leftChild!=0 )
					StNode.push( *(cnode->leftChild) );
			}
			else if ( cnode->timesPopped==2 )
			{
				if ( cnode->rightChild!=0 )
					StNode.push( *(cnode->rightChild) );
			}
			else
			{
				StNode.pop();
			}
		}
	}
}

// iterative preorder traversal version 2
void printPreOrderIter2( Node *node )
{
	stack<Node*> StNode;
	if ( node!=0 )
	{
		StNode.push( node );
		while ( !StNode.empty() )
		{
			Node *cnode = StNode.top();
			cout << cnode->value << endl;
			StNode.pop();
			if ( cnode->rightChild!=0 )
				StNode.push( cnode->rightChild );
			if ( cnode->leftChild!=0 )
				StNode.push( cnode->leftChild );
		}
	}
}

// print postorder
void printPostOrderRecur2( Node2 *node )
{
	if ( node!=0 )
	{
		printPostOrderRecur2( node->leftChild );
		printPostOrderRecur2( node->rightChild );
		cout << node->value << endl;
	}
}

// print inorder
void printInOrderRecur2( Node2 *node )
{
	if ( node!=0 )
	{
		printInOrderRecur2( node->leftChild );
		cout << node->value << endl;
		printInOrderRecur2( node->rightChild );
	}
}

// print preorder
void printPreOrderRecur2( Node2 *node )
{
	if ( node!=0 )
	{		
		cout << node->value << endl;
		printPreOrderRecur2( node->leftChild );
		printPreOrderRecur2( node->rightChild );
	}
}

// iterative levelorder traversal
void printLevelOrderIter( Node *node )
{
	queue<Node*> QNode;
	if ( node!=0 )
	{
		QNode.push( node );
		while ( !QNode.empty() )
		{
			Node *cnode = QNode.front();
			cout << cnode->value << endl;
			QNode.pop();
			if ( cnode->leftChild!=0 )
				QNode.push( cnode->leftChild );
			if ( cnode->rightChild!=0 )
				QNode.push( cnode->rightChild );
		}
	}
}

// compute the number of leaves in a binary tree
void countNumOfLeavesAux( Node *node, int *count )
{
	if ( node->leftChild!=0 )
		countNumOfLeavesAux( node->leftChild, count );
	if ( node->rightChild!=0 )
		countNumOfLeavesAux( node->rightChild, count );
	if ( node->leftChild==0 && node->rightChild==0 )
	{
		++(*count);
		return;
	}
}

int countNumOfLeaves( Tree *tree )
{
	int count = 0;
	if ( tree->root!=0 )
		countNumOfLeavesAux( tree->root, &count );
	return count;
}

// compute the number of nodes that contain one child
void countSingleChildNodesAux( Node *node, int *count )
{
	if ( node->leftChild==0 && node->rightChild==0 )
		return;
	else if ( node->leftChild==0 || node->rightChild==0 )
		++(*count);

	if ( node->leftChild!=0 )
		countSingleChildNodesAux( node->leftChild, count );
	if ( node->rightChild!=0 )
		countSingleChildNodesAux( node->rightChild, count );
}

int countSingleChildNodes( Tree *tree )
{
	int count = 0;
	if ( tree->root!=0 )
		countSingleChildNodesAux( tree->root, &count );
	return count;
}

// compute the number of nodes that contain two children
void countDoubleChildNodesAux( Node *node, int *count )
{
	if ( node->leftChild==0 && node->rightChild==0 )
		return;
	else if ( node->leftChild!=0 && node->rightChild!=0 )
		++(*count);

	if ( node->leftChild!=0 )
		countDoubleChildNodesAux( node->leftChild, count );
	if ( node->rightChild!=0 )
		countDoubleChildNodesAux( node->rightChild, count );
}

int countDoubleChildNodes( Tree *tree )
{
	int count = 0;
	if ( tree->root!=0 )
		countDoubleChildNodesAux( tree->root, &count );
	return count;
}

int main()
{
	// illustration of BuildBinaryTreeStatic
	cout << "***Illustration of BuildBinaryTreeStatic***" << endl;
	int n;
	cout << "Enter n:\n";
	cin >> n;

	srand(time(NULL));
	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; ++i )
		A[i] = rand()%100;

	cout << "The array:\n";
	for ( int i=0; i<n; ++i )
		cout << A[i] << " ";
	cout << endl;

	Node *root = BuildBinaryTreeStatic( A, n );

	cout << "In-order traversal of the tree:\n";
	printInOrder( root );

	// illustration of BuildBinaryTree
	cout << endl << endl;
	cout << "***Illustration of BuildBinaryTree***" << endl;
	Tree *t2 = BuildBinaryTree();
	int n2 = rand()%10;
	int min2 = 5;
	cout << "n2: " << n2+min2 << endl << endl;
	for ( int i=0; i<n2+min2; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode( t2, data );
	}

	cout << endl << "In-order traversal of tree2:\n";
	if ( t2->root!=0 )
		printInOrder( t2->root );
	else
		cout << "Empty tree.\n";

	// illustration of merge
	cout << "\n\n***Illustration of merge***";

	cout << "\n\ncase 1: two different full trees" << endl;
	Tree *t3 = BuildBinaryTree();
	int n3 = rand()%10;
	int min3 = 5;
	cout << "n3: " << n3+min3 << endl << endl;
	for ( int i=0; i<n3+min3; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode( t3, data );
	}

	cout << endl << "In-order traversal of tree3:\n";
	if ( t3->root!=0 )
		printInOrder( t3->root );
	else
		cout << "Empty tree.\n";

	int data = rand()%100;
	cout << endl << "new data: " << data << endl;
	cout << endl << "In-order trasveral of the merged tree of tree2, tree3 and the new data:\n";
	Tree *mtree1 = merge( t2, t3, data );
	if ( mtree1->root!=0 )
			printInOrder( mtree1->root );
	else
		cout << "Empty tree.\n";

	cout << "\ncase 2: two duplicate full trees" << endl;
	Tree *t8 = BuildBinaryTree();
	int n8= rand()%10;
	int min8 = 5;
	cout << "n8: " << n8+min8 << endl << endl;
	for ( int i=0; i<n8+min8; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode( t8, data );
	}

	cout << endl << "In-order traversal of tree8:\n";
	if ( t8->root!=0 )
		printInOrder( t8->root );
	else
		cout << "Empty tree.\n";

	Tree *mtree2 = merge( t8, t8, data );
	cout << "The merged tree:\n";
	if ( mtree2->root!=0 )
		printInOrder( mtree2->root );
	else
		cout << "Empty tree.\n";

	cout << "\ncase 3: one empty tree and a full tree" << endl;
	Tree *t4 = BuildBinaryTree();
	if ( t4->root!=0 )
		printInOrder( t4->root );
	else
		cout << "tree4 is empty.\n";

	Tree *mtree3 = merge( mtree1, t4, data );
	cout << endl << "In-order trasveral of the merged tree of the last merged tree, tree4 and the new data:\n";
	if ( mtree3->root!=0 )
		printInOrder( mtree3->root );
	else
		cout << "Empty tree.\n";

	// illustration of duplicate
	cout << "\n\n***Illustration of duplicate***\n";
	Tree *t5 = BuildBinaryTree();
	int n5 = rand()%10;
	int min5 = 5;
	cout << "n5: " << n5+min5 << endl << endl;
	for ( int i=0; i<n5+min5; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode( t5, data );
	}

	cout << "\nIn-order traversal of tree5:\n";
	if ( t5->root!=0 )
		printInOrder( t5->root );
	else
		cout << "Empty tree.\n";

	Tree *t9 = duplicate( t5 );
	cout << "\nIn-order traversal of a duplicate tree of tree5:\n";
	if ( t9->root!=0 )
		printInOrder( t9->root );
	else
		cout << "Empty tree.\n";

	Tree *t6 = BuildBinaryTree();
	cout << "\nIn-order traversal of tree6:\n";
	if ( t6->root!=0 )
		printInOrder( t6->root );
	else
		cout << "Empty tree.\n";

	Tree *t7 = duplicate( t6 );
	cout << "\nIn-order traveral of a duplicate tree of tree6:\n";
	if ( t7->root!=0 )
		printInOrder( t7->root );
	else
		cout << "Empty tree.\n";

	// illustration of makeEmpty
	makeEmpty( t7 );
	cout << "\nAfter emptying tree7:\n";
	if ( t7->root!=0 )
		printInOrder( t7->root );
	else
		cout << "Empty tree.\n";

	// illustration of size and height
	cout << "\n\n***Illustration of size and height***\n";
	cout << "size of tree5: " << size( t5->root ) << endl;
	cout << "height of root in tree5: " << height( t5->root ) << endl;

	// illustration of iterative postorder traversal
	cout << "\n\n***Illustration of postorder traversal***\n";
	Tree2 *t10 = BuildBinaryTree2();
	int n10 = rand()%10;
	int min10 = 5;
	cout << "n10: " << min10 + n10 << endl << endl;
	for ( int i=0; i<min10+n10; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode2( t10, data );
	}

	cout << "\nPost-order traversal of tree10:\n";
	if ( t10->root!=0 )
		printPostOrderRecur2( t10->root );
	else
		cout << "Empty tree.\n";

	cout << "\nPost-order traversal of tree10:\n";
	if ( t10->root!=0 )
		printPostOrderIter( t10->root );
	else
		cout << "Empty tree.\n";

	// illustration of iterative postorder traversal version 2
	cout << "\n\n***Illustration of postorder traversal version 2***\n";
	Tree2 *t14 = BuildBinaryTree2();
	int n14 = rand()%10;
	int min14 = 5;
	cout << "n14: " << min14+n14 << endl << endl;
	for ( int i=0; i<min14+n14; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode2( t14, data );
	}

	cout << "\nPost-order traversal of tree14:\n";
	if ( t14->root!=0 )
		printPostOrderRecur2( t14->root );
	else
		cout << "Empty tree.\n";

	cout << "\nPost-order traversal of tree14:\n";
	if ( t14->root!=0 )
		printPostOrderIter2( t14->root );
	else
		cout << "Empty tree.\n";

	// illustration of iterative inorder traversal
	cout << "\n\n***Illustration of inorder traversal***\n";
	Tree2 *t11 = BuildBinaryTree2();
	int n11 = rand()%10;
	int min11 = 5;
	cout << "n11: " << min11 + n11 << endl << endl;
	for ( int i=0; i<min11+n11; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode2( t11, data );
	}

	cout << "\nIn-order traversal of tree11:\n";
	if ( t11->root!=0 )
		printInOrderRecur2( t11->root );
	else
		cout << "Empty tree.\n";

	cout << "\nIn-order traversal of tree11:\n";
	if ( t11->root!=0 )
		printInOrderIter( t11->root );
	else
		cout << "Empty tree.\n";

	// illustration of iterative inorder traversal version 2
	cout << "\n\n***Illustration of inorder traversal version 2***\n";
	Tree2 *t15 = BuildBinaryTree2();
	int n15 = rand()%10;
	int min15 = 5;
	cout << "n15: " << min15+n15 << endl << endl;
	for ( int i=0; i<min15+n15; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode2( t15, data );
	}

	cout << "\nIn-order traversal of tree15:\n";
	if ( t15->root!=0 )
		printInOrderRecur2( t15->root );
	else
		cout << "Empty tree.\n";

	cout << "\nIn-order traversal of tree15:\n";
	if ( t15->root!=0 )
		printInOrderIter2( t15->root );
	else
		cout << "Empty tree.\n";

	// illustration of iterative preorder traversal
	cout << "\n\n***Illustration of preorder traversal***\n";
	Tree2 *t12 = BuildBinaryTree2();
	int n12 = rand()%10;
	int min12 = 5;
	cout << "n12: " << min12 + n12 << endl << endl;
	for ( int i=0; i<min12+n12; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode2( t12, data );
	}

	cout << "\nPre-order traversal of tree12:\n";
	if ( t12->root!=0 )
		printPreOrderRecur2( t12->root );
	else
		cout << "Empty tree.\n";

	cout << "\nPre-order traversal of tree12:\n";
	if ( t12->root!=0 )
		printPreOrderIter( t12->root );
	else
		cout << "Empty tree.\n";

	// illustration of iterative preorder traversal version 2
	cout << "\n\n***Illustration of preorder traversal Version 2***\n";
	Tree *t13 = BuildBinaryTree();
	int n13 = rand()%10;
	int min13 = 5;
	cout << "n13: " << n13 + min13 << endl << endl;
	for ( int i=0; i<n13 + min13; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode( t13, data );
	}

	cout << "\nPre-order traversal of tree13:\n";
	if ( t13->root!=0 )
		printPreOrder( t13->root );
	else
		cout << "Empty tree.\n";

	cout << "\nPre-order traversal of tree13:\n";
	if ( t13->root!=0 )
		printPreOrderIter2( t13->root );
	else
		cout << "Empty tree.\n";

	// illustration of iterative level order traversal
	cout << "\n\n***Illustration of level order traversal***\n";
	Tree *t16 = BuildBinaryTree();
	int n16 = rand()%10;
	int min16 = 6;
	cout << "n16: " << min16 << endl << endl;
	for ( int i=0; i<min16; ++i )  
	{
		int data = rand()%100;
		cout << "new data: " << data << endl;
		InsertNode( t16, data );
	}

	cout << "\nPre-order traversal of tree16:\n";
	if ( t16->root!=0 )
		printLevelOrderIter( t16->root );
	else
		cout << "Empty tree.\n";

	// illustration of countNumOfLeaves
	cout << "\n\n***Illustration of countNumOfLeaves***";
	int result = countNumOfLeaves( t16 );
	cout << "\nnumber of leaves in tree16: " << result << endl;
	cout << "number of leaves in tree13: " << countNumOfLeaves( t13 ) << endl;
		
	// illustration of countSingleChildNodes
	cout << "\n\n***Illustration of countSingleChildNodes***";
	int result2 = countSingleChildNodes( t16 );
	cout << "\none-child nodes in tree16: " << result2 << endl;
	cout << "one-child nodes in tree13: " << countSingleChildNodes( t13 ) << endl;

	// illustration of countDoubleChildNodes
	cout << "\n\n***Illustration of countDoubleChildNodes***";
	int result3= countDoubleChildNodes( t16 );
	cout << "\ntwo-child nodes in tree16: " << result3 << endl;
	cout << "two-child nodes in tree13: " << countDoubleChildNodes( t13 ) << endl;

	system("pause");
	return 0;
}