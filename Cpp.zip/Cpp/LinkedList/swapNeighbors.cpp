#include <iostream>
#include <ctime>
using namespace std;

// Node of a singly linked list
struct Node
{
	int value;
	Node *next;
};

// Create a new singly linked list which is empty.
Node *BuildAList()
{
	Node *head = 0;
	return head;
}

// Insert a node with a given value at the front of a singly linked list.
bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
	{
		return false;
	}

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

// Display the values of a singly linked list.
void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list, write a function to swap every two neighboring 
nodes and return the head node. Do not change the values of the node, but 
change the links. For example, given 1->2->3->4->5->6->7, the result should
be 2->1->4->3->6->5->7.

Method 1: recursive method.
*/
Node *SwapNeighborsAux( Node *list )
{
	if ( list==0 || list->next==0 )
		return list;

	Node *head = list->next; // new head node
	Node *next_list = head->next;
	head->next = list;
	list->next = SwapNeighborsAux( next_list );
	return head;
}

void SwapNeighborsRecur( Node **head )
{
	if ( (*head)==0 || (*head)->next==0 )
		return;

	Node *second = *head;
	*head = second->next; // new head node
	Node *next_list = (*head)->next;
	(*head)->next = second;
	second->next = SwapNeighborsAux( next_list );
}

/*
Method 2: non-recursive method.
*/
void SwapNeighborsNonRecur( Node **head )
{
	if ( *head==0 || (*head)->next==0 )
		return;

	Node *cur = *head;
	Node *nxt = (cur->next)->next;
	(cur->next)->next = cur;
	*head = cur->next;
	cur->next = nxt;
	Node *prev = cur;

	while ( nxt!=0 )
	{
		cur = nxt;
		nxt = nxt->next;
		if ( nxt==0 )
			return;
		nxt = nxt->next;

		(cur->next)->next = cur;
		prev->next = cur->next;
		cur->next = nxt;
		prev = cur;
	}
}

/*
Given a singly linked list, swap two nodes in place without using any extra
node. You may change the values. For example, given 1->2->3->4->5->6->7, the 
result should be 2->1->4->3->6->5->7.
*/
void SwapNeighborsByValue( Node *head )
{
	while ( head!=0 && head->next!=0 )
	{
		head->value += (head->next)->value;
		(head->next)->value = head->value - (head->next)->value;
		head->value -= (head->next)->value;
		head = head->next->next;
	}
}

int main()
{
	Node *list1 = BuildAList();
	Node *list2 = BuildAList();
	
	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
	{
		InsertAtFront( &list1, rand()%100 );
		InsertAtFront( &list2, rand()%100 );
	}
	InsertAtFront( &list2, rand()%100 );

	cout << "list1 before swapping:\n";
	Display( list1 );

	cout << "list1 after swapping:\n";
	SwapNeighborsRecur( &list1 );
	Display( list1 );

	cout << "list1 after swapping again:\n";
	SwapNeighborsByValue( list1 );
	Display( list1 );

	cout << "list1 after swapping again:\n";
	SwapNeighborsNonRecur( &list1 );
	Display( list1 );

	cout << "list2 before swapping:\n";
	Display( list2 );

	cout << "list2 after swapping:\n";
	SwapNeighborsRecur( &list2 );
	Display( list2 );	

	cout << "list2 after swapping again:\n";
	SwapNeighborsByValue( list2 );
	Display( list2 );

	cout << "list2 after swapping again:\n";
	SwapNeighborsNonRecur( &list2 );
	Display( list2 );

	system("pause");
	return 0;
}