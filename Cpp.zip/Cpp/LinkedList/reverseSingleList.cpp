/*
Given a singly linked list, reverse the list.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Method 1: non-recursive method.
Time complexity: O(n).
Space complexity: O(1).
*/
void ReverseSingleList( Node **head )
{
	if ( *head==0 || (*head)->next==0 )
		return;

	Node *cur = *head;
	Node *prev = 0;
	Node *next;
	while ( cur!=0 )
	{
		next = cur->next;
		cur->next = prev;
		prev = cur;
		cur = next;
	}
	*head = prev;
}

/*
Method 2: recursive method.
Time complexity: O(n).
Space complexity: O(n) (on the stack).
*/
Node *ReverseSingleList2Aux( Node *list, Node **new_head )
{
	if ( list->next==0 )
	{
		*new_head = list;
		return list;
	}

	Node *cur = list;
	Node *prev = ReverseSingleList2Aux( cur->next, new_head );
	prev->next = cur;
	return cur;
}

void ReverseSingleList2( Node **head )
{
	if ( *head==0 || (*head)->next==0 )
		return;

	Node *cur = *head;
	Node *prev = ReverseSingleList2Aux( cur->next, head );
	prev->next = cur;
	cur->next = 0;
}

int main()
{	
	Node *list = BuildAList();

	int n;
	cout << "Enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The list:\n";
	Display( list );

	ReverseSingleList( &list );

	cout << "The reverse list:\n";
	Display( list );

	ReverseSingleList2( &list );

	cout << "Reverse again:\n";
	Display( list );

	ReverseSingleList3( &list );

	cout << "Reverse again:\n";
	Display( list );

	system("pause");
	return 0;
}