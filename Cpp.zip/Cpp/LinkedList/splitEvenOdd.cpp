#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list, arrange the elements such that all
even numbers are placed after odd numbers.
Time complexity: O(n).
Space complexity: O(1).
*/
void splitEvenOdd( Node **head )
{
	if ( *head==0 || (*head)->next==0 ) // return if there is less than two nodes
		return;

	Node *even_begin = 0;
	Node *even_end = 0;
	Node *odd_begin = 0;
	Node *odd_end = 0;

	// find the first odd number and the first even number
	Node *p = *head;
	if ( p->value%2==0 ) // the first node is even
	{
		even_begin = *head;
		even_end = *head;
		p = p->next;
		while ( p!=0 && p->value%2==0 ) // find the first odd number
		{		
			even_end->next = p;
			even_end = p;
			p = p->next;
		}
		if ( p==0 ) // The list contains only even numbers.
			return;
		odd_begin = p;
		odd_end = odd_begin;
	}
	else // the first node is odd
	{
		odd_begin = *head;
		odd_end = odd_begin;
		p = p->next;
		while ( p!=0 && p->value%2!=0 ) // find the first even number
		{
			odd_end->next = p;
			odd_end = p;
			p = p->next;
		} 
		if ( p==0 ) // The list contains only odd numbers.
			return;
		even_begin = p;	
		even_end = even_begin;
	}

	// traverse the rest of the list, append each odd/even number to odd_end/even_end
	p = p->next;
	while ( p!=0 )
	{
		if ( p->value%2==0 ) // if even
		{
			even_end->next = p;
			even_end = p;
		}
		else // if odd
		{
			odd_end->next = p;
			odd_end = p;
		}
		p = p->next;
	}

	odd_end->next = even_begin;
	even_end->next = 0;
	*head = odd_begin;
}

int main()
{
	Node *list = BuildAList();
	srand(time(NULL));
	int max_size = 100;
	int count = 0;
	int data;
	while ( rand()%10!=0 && count<max_size )
	{
		data = rand()%100;
		InsertAtFront( &list, data );
	}

	cout << "The list:\n";
	Display( list );

	splitEvenOdd( &list );

	cout << "After modifying:\n";
	Display( list );

	system("pause");
	return 0;;
}