#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list, print the values of the nodes in reverse order.
Solution 1: use recursive method.
Time complexity: O(n).
Space complexity: O(1).
*/
void PrintReverselyAux( Node *head )
{
	if ( head==0 )
		return;
	PrintReverselyAux( head->next );
	cout << head->value << " ";
}

void PrintReversely( Node *head )
{
	PrintReverselyAux( head );
	cout << endl;
}

/*
Solution 2: use stack data structure.
Time complexity: O(n).
Space complexity: O(n).
*/
void PrintReversely2( Node *head )
{
	Node *stack = BuildAList();
	while ( head!=0 )
	{
		InsertAtFront( &stack, head->value );
		head = head->next;
	}
	while ( stack!=0 )
	{
		cout << stack->value << " ";
		Node *temp = stack;
		stack = stack->next;
		delete temp;
	}
	cout << endl;
}

int main()
{
	Node *list = BuildAList();

	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The list:\n";
	Display( list );

	cout << "The reverse list:\n";
	PrintReversely( list );

	cout << "The reverse list:\n";
	PrintReversely2( list );

	system("pause");
	return 0;
}