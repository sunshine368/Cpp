#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list which contains only 1, 2, and 3, 
sort it in increasing order.
*/

/*
Method 1: modify values of nodes.
Time complexity: O(n).
Space complexity: O(1).
*/
void DutchNationalFlag( Node *head )
{
	int n1 = 0; 
	int n2 = 0;
	int n3 = 0;

	// count the number of 1's, 2's and 3's and store them in n1, n2, n3
	Node *p = head;
	while ( p!=0 )
	{
		if ( p->value==1 )
			++n1;
		else if ( p->value==2 )
			++n2;
		else
			++n3;
		p = p->next;
	}

	// make values of the first n1 nodes to 1, the next n2 nodes to 2, and the last n3 nodes to 3
	p = head;
	while ( n1>0 )
	{
		p->value = 1;
		p = p->next;
		--n1;
	}
	while ( n2>0 )
	{
		p->value = 2;
		p = p->next;
		--n2;
	}
	while ( n3>0 )
	{
		p->value = 3;
		p = p->next;
		--n3;
	}
}

/*
Method 2: group the nodes into three lists by values and link the three lists
Time complexity: O(n).
Space complexity: O(1).
*/
void DutchNationalFlag2( Node **head )
{
	// let one, two, three point to head nodes of lists of 1's, 2's and 3's respectively
	Node *one = 0;
	Node *two = 0;
	Node *three = 0;

	// let end1, end2, end3 point to the last node of lists of 1's, 2's and 3's respectively
	Node *end1 = 0;
	Node *end2 = 0;
	Node *end3 = 0;

	// traverse the list, append each node to lists of 1's, 2's and 3's according to the value
	Node *p = *head;
	while ( p!=0 )
	{
		if ( p->value==1 )
		{
			if ( one==0 )
			{
				one = p;
				end1 = one;
			}
			else
			{
				end1->next = p;
				end1 = p;
			}
		}
		else if ( p->value==2 )
		{
			if ( two==0 )
			{
				two = p;
				end2 = two;
			}
			else
			{
				end2->next = p;
				end2 = p;
			}
		}
		else
		{
			if ( three==0 )
			{
				three = p;
				end3 = three;
			}
			else
			{
				end3->next = p;
				end3 = p;
			}
		}
		p = p->next;
	}

	// connect the three lists
	if ( one!=0 ) // if no 1's in the list
		*head = one;
	else if ( two!=0 ) // if no 1's or 2's in the list
		*head = two;
	else
		*head = three;

	if ( end1!=0 ) // if there are 1's in the list
		end1->next = two;

	if ( end2!=0 ) // if there are 2's in the list
		end2->next = three;

	if ( end3!=0 ) // if there are 3's in the list
		end3->next = 0;
	else if ( end2!=0 ) // if no 3's but 2's in the list
		end2->next = 0;
	else if ( end1!=0 ) // if no 3's or 2's in the list
		end1->next = 0;
}

int main()
{
	// illustration of DutchNationalFlag()
	Node *list = BuildAList();

	int n;
	cout << "Enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%3+1 );

	cout << "The list:\n";
	Display( list );

	DutchNationalFlag( list );

	cout << "After sorting:\n";
	Display( list );

	// illustration of DutchNationalFlag2()
	Node *list2 = BuildAList();

	int n2;
	cout << "Enter number of nodes:\n";
	cin >> n2;

	srand(time(NULL));
	for ( int i=0; i<n2; i++ )
		InsertAtFront( &list2, rand()%3+1 );

	cout << "The list:\n";
	Display( list2 );

	DutchNationalFlag2( &list2 );

	cout << "After sorting:\n";
	Display( list2 );

	system("pause");
	return 0;
}