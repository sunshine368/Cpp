#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *next;
};

Node *BuildAList()
{
    Node *head = 0;
    return head;
}

bool InsertAtFront( Node **head, int data )
{
    Node *new_head = new Node;
    if ( !new_head )
        return false;
    
    new_head->value = data;
    new_head->next = *head;
    *head = new_head;
    return true;
}

void Display( Node *head )
{
    while ( head!=0 )
    {
        cout << head->value << " ";
        head = head->next;
    }
    cout << endl;
}

/*
Given a singly linked list and a number k, swap the kth node from the start with
the kth node from the last.
*/
void SwapTwoNodes( Node *head, int k )
{
    if ( head==0 )
    {
        cout << "Empty list!\n";
        return;
    }
    
    Node *first = head;
    while ( k>1 )
    {
        first = first->next;
        if ( first==0 )
        {
            cout << "List not long enough!\n";
            return;
        }
        k--;
    }
    
    Node *second = head;
    Node *third = first;
    while ( third->next!=0 )
    {
        third = third->next;
        second = second->next;
    }
    
    first->value += second->value;
    second->value = first->value - second->value;
    first->value -= second->value;
}

int main()
{
    Node *list = BuildAList();
    
    int n;
    cout << "Please enter number of nodes:\n";
    cin >> n;
    
    srand(time(NULL));
    for ( int i=0; i<n; i++ )
        InsertAtFront( &list, rand()%100 );

    cout << "The list:\n";
    Display( list );

    int k;
    cout << "Please enter k:\n";
    cin >> k;
    
    SwapTwoNodes( list, k );
    
    cout << "After swapping:\n";
    Display( list );
    
    return 0;
}