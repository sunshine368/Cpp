#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list of length N which is very large but unknown,
return k random numbers from the list. Assume N>k. 
Time complexity: O(N).
*/
void pickNodesRandomly( Node *head, int *sample, int k )
{
	// let p a pointer traversing the linked list
	Node *p = head;

	// copy the first k values to sample[]
	int count = 0;
	while ( count<k && p!=0 )
	{
		sample[count] = p->value;
		p = p->next;	
		++count;
	}

	// For each following node: 
	// increase count by 1;
	// with probability k/count, 
	// choose randomly a value in sample[];
	// replace it with the node's value.	
	while ( p!=0 )
	{
		++count;
		if ( rand()%count < k )
		{
			sample[rand()%k] = p->value;
		}
		p = p->next;
	}
}

int main()
{
	int k;
	cout << "Enter sample size:\n";
	cin >> k;

	Node *list = BuildAList();

	srand(time(NULL));

	// create a linked list whose length and node values are generated randomly
	int num = 0;
	int size = 10;
	while ( num<k || rand()%size!=0 )
	{
		InsertAtFront( &list, rand()%100 );
		++num;
	}

	cout << "The list:\n";
	Display( list );

	// pick k valus from the linked list randomly
	int *result = (int*)malloc( sizeof(int)*k );
	pickNodesRandomly( list, result, k );

	cout << "k samples:\n";
	for ( int i=0; i<k; i++ )
		cout << result[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}