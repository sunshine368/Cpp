#include <iostream>
#include <ctime>
using namespace std;

// Node of a singly linked list
struct Node
{
	int value;
	Node *next;
};

// Create a new singly linked list which is empty.
Node *BuildAList()
{
	Node *head = 0;
	return head;
}

// Insert a node with a given value at the front of a singly linked list.
bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
	{
		return false;
	}

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

// Display the values of a singly linked list.
void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

// Append a singly linked list to another singly linked list.
void AppendAList( Node **list1, Node *list2 )
{
	if ( (*list1)==0 )
	{
		(*list1) = list2;
		return;
	}

	Node *pos = *list1;
	while ( pos->next!=0 )
	{
		pos = pos->next;
	}
	pos->next = list2;
}

/*
Given two singly linked lists, find if they intersect in a single iteration.
*/
bool Intersect( Node *list1, Node *list2 )
{
	Node *p1 = list1;
	while ( p1->next!=0 )
	{
		p1 = p1->next;
	}

	Node *p2 = list2;
	while ( p2->next!=0 )
	{
		p2 = p2->next;
	}

	if ( p1==p2 )
		return true;
	else
		return false;
}

/* 
Given two singly linked lists, find the intersecting node, 
if it exists, in O(n) time and O(1) space.
*/
Node *findIntersection( Node *list1, Node *list2 )
{
	int size1 = 0; // number of nodes in list1
	Node *p1 = list1; 
	while ( p1!=0 )
	{
		size1++;
		p1 = p1->next;
	}
		
	int size2 = 0; // number of nodes in list2
	Node *p2 = list2;
	while ( p2!=0 )
	{
		size2++;
		p2 = p2->next;
	}

	Node *intersect = 0;
	if ( size1>=size2 )
	{
		p1 = list1;
		for ( int i=0; i<size1-size2; i++ )
		{
			p1 = p1->next;
		}

		p2 = list2;
		for ( int i=0; i<size2; i++ )
		{
			if ( p1==p2 )
			{
				intersect = p1;
				break;
			}
			p1 = p1->next;
			p2 = p2->next;
		}
	}
	else
	{
		p2 = list2;
		for ( int i=0; i<size2-size1; i++ )
		{
			p2 = p2->next;
		}

		p1 = list1;
		for ( int i=0; i<size1; i++ )
		{
			if ( p1==p2 )
			{
				intersect = p2;
				break;
			}
			p1 = p1->next;
			p2 = p2->next;
		}
	}

	return intersect;
}

int main()
{
	Node *list1 = BuildAList();
	Node *list2 = BuildAList();
	Node *list3 = BuildAList();
	Node *list4 = BuildAList();

	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
	{
		InsertAtFront( &list1, rand()%100 );
		InsertAtFront( &list2, rand()%100 );
		InsertAtFront( &list3, rand()%100 );
		InsertAtFront( &list4, rand()%100 );
	}

	cout << "Linked list 1:\n";
	Display( list1 );
	cout << "Linked list 2:\n";
	Display( list2 );
	cout << "Linked list 3:\n";
	Display( list3 );
	cout << "Linked list 4:\n";
	Display( list4 );
	cout << endl;

	AppendAList( &list1, list4 );
	AppendAList( &list3, list4 );
	cout << "After appending list4 to list1:\n";
	Display( list1 );
	cout << "After appending list4 to list3:\n";
	Display( list3 );
	cout << endl;

	bool isIntersect13 = Intersect( list1, list3 );
	if ( isIntersect13 )
		cout << "list1 intersects with list3.\n";
	else
		cout << "list1 does not intersect with list3.\n";

	bool isIntersect12 = Intersect( list1, list2 );
	if ( isIntersect12 )
		cout << "list1 intersects with list2.\n";
	else
		cout << "list1 does not intersect with list2.\n";
	cout << endl;

	system("pause");
	return 0;
}