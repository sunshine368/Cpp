/*
Implement a doubly linked list in terms of a singly linked list.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *ptr;
};

Node *BuildAList()
{
    Node *head = 0;
    return head;
}

bool InsertAtFront( Node **head, int data )
{
    if ( *head==0 )
    {
        Node *new_head = new Node;
        if ( !new_head )
            return false;
        new_head->value = data;
        new_head->ptr = 0;
        *head = new_head;
        return true;
    }
    else if ( (*head)->ptr==0 )
    {
        Node *new_head = new Node;
        if ( !new_head )
            return false;
        new_head->value = data;
        new_head->ptr = *head;
        (*head)->ptr = new_head;
        *head = new_head;
        return true;
    }
    else
    {
        Node *new_head = new Node;
        if ( !new_head )
            return false;
        new_head->value = data;
        new_head->ptr = *head;
        (*head)->ptr = (Node *)((int)new_head^(int)(*head)->ptr);
        *head = new_head;
        return true;
    }
}

void Display( Node *head )
{
    if ( head==0 )
        return;
    
    if ( head->ptr==0 )
    {
        cout << head->value << endl;
        return;
    }
    
    cout << head->value << " ";
    Node *prev = head;
    Node *cur = head->ptr;
    Node *next;
    while ( cur!=0 )
    {
        cout << cur->value << " ";
        next = (Node*)((int)cur->ptr^(int)prev);
        prev = cur;
        cur = next;
    }
    cout << endl;
}

int main()
{
    Node *list = BuildAList();
    int n;
    cout << "Enter n:\n";
    cin >> n;
    
    srand(time(NULL));
    for ( int i=0; i<n; i++ )
        InsertAtFront( &list, rand()%100 );
    
    cout << "The list:\n";
    Display( list );
    
    return 0;
}