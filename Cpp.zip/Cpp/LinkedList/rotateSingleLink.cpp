#include <iostream>
#include <ctime>
using namespace std;

// Node of a singly linked list
struct Node
{
	int value;
	Node *next;
};

// Create a new singly linked list which is empty.
Node *BuildAList()
{
	Node *head = 0;
	return head;
}

// Insert a node with a given value at the front of a singly linked list.
bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
	{
		return false;
	}

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

// Display the values of a singly linked list.
void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Rotate a singly linked list to the left by k positions.
*/
void LeftRotate( Node **head, int k )
{
	// find the length of the linked list
	int count = 0;
	Node *temp = *head;
	while ( temp!=0 )
	{
		++count;
		temp = temp->next;
	}
	k = k%count;
	if ( k==0 )
		return;
	
	temp = *head; // save the head node for later use

	// find the head node of the rotated linked list
	Node *list = *head;
	for ( int i=1; i<k; i++ )
	{
		list = list->next;
	}
	*head = list->next;
	list->next = 0;

	// find the end of the original list
	list = *head;
	while ( list->next!=0 )
	{
		list = list->next;
	}

	// append the first part of the original list to the end
	list->next = temp;
}

/*
Rotate a singly linked list to the right by k positions.
*/
void RightRotate( Node **head, int k )
{
	int count = 0;
	Node *temp = *head;
	while ( temp!=0 )
	{
		++count;
		temp = temp->next;
	}
	k = k%count;
	if ( k==0 )
		return;
	k = count - k;

	temp = *head; // save the head node for later use

	// find the head node of the rotated linked list
	Node *list = *head;
	for ( int i=1; i<k; i++ )
	{
		list = list->next;
	}
	*head = list->next;
	list->next = 0;

	// find the end of the original list
	list = *head;
	while ( list->next!=0 )
	{
		list = list->next;
	}

	// append the first part of the original list to the end
	list->next = temp;
}

int main()
{
	Node *list1 = BuildAList();
	Node *list2 = BuildAList();
	
	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
	{
		InsertAtFront( &list1, rand()%100 );
		InsertAtFront( &list2, rand()%100 );
	}
	InsertAtFront( &list2, rand()%100 );

	// illustration of LeftRotate()
	cout << "Before rotating list1:\n";
	Display( list1 );

	LeftRotate( &list1, 1 );
	cout << "After rotating list1 to the left by " << 1 << " position:\n";
	Display( list1 );

	LeftRotate( &list1, n/2 );
	cout << "After rotating list1 to the left by " << n/2 << " more position:\n";
	Display( list1 );

	LeftRotate( &list1, n );
	cout << "After rotating list1 to the left by " << n << " more positions:\n";
	Display( list1 );

	cout << endl;

	// illustration of RightRotate()
	cout << "Before rotating list2:\n";
	Display( list2 );

	RightRotate( &list2, 1 );
	cout << "After rotating list2 to the right by " << 1 << " position:\n";
	Display( list2 );

	RightRotate( &list2, n/2 );
	cout << "After rotating list2 to the right by " << n/2 << " more position:\n";
	Display( list2 );

	RightRotate( &list2, n );
	cout << "After rotating list2 to the right by " << n << " more positions:\n";
	Display( list2 );

	cout << endl;

	system("pause");
	return 0;
}