/*
Given a singly linked list, find the one-third and the two-thirds nodes.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

void TriSection( Node *head, Node **onethird, Node **twothirds )
{
	if ( head==0 || head->next==0 || (head->next)->next==0 )
		return;

	Node *one = head;
	Node *two = head->next;
	Node *three = (head->next)->next;
	while ( three!=0 )
	{
		three = three->next;
		if ( three==0 )
			break;
		two = two->next;

		three = three->next;
		if ( three==0 )
			break;
		two = two->next;
		one = one->next;

		three = three->next;
	}
	*onethird = one;
	*twothirds = two;
}

int main()
{
	Node *list = BuildAList();
	Node *onethird = 0;
	Node *twothirds = 0;

	int n;
	cout << "Enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The list:\n";
	Display( list );

	TriSection( list, &onethird, &twothirds );

	cout << "The one-third node:\n";
	cout << onethird->value << endl;

	cout << "The two-thirds node:\n";
	cout << twothirds->value << endl;

	system("pause");
	return 0;
}