#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list and two integers m>0, n>=0, keep the 
first m nodes and delete the following n nodes; repeat the same
process until the end of the list.
*/
void deleteAlternativeNodes( Node *head, int m, int n )
{
	if ( head==0 )
		return;

	int count;
	Node *temp = 0;
	while ( head!=0 )
	{
		count = m;
		while ( count>1 )
		{
			head = head->next;
			if ( head==0 )
				return;
			--count;
		}
		count = n;
		while ( count>0 )
		{
			if ( head->next==0 )
				return;
			temp = head->next;
			head->next = (head->next)->next;
			delete temp;
			--count;
		}
		head = head->next;
	}
}

int main()
{
	Node *list = BuildAList();

	int size;
	cout << "Please enter number of nodes:\n";
	cin >> size;

	srand(time(NULL));
	for ( int i=0; i<size; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The original list:\n";
	Display( list );

	int m, n;
	cout << "Please enter m:\n";
	cin >> m;
	cout << "Please enter n:\n";
	cin >> n;
	deleteAlternativeNodes( list, m, n );

	cout << "The modified list:\n";
	Display( list );

	system("pause");
	return 0;
}