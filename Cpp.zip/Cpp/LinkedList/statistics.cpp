#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list, find the minimum, maximum, average, 
and size of the list in one traverse.
*/
void Statistics( Node *head, int &min, int &max, int &ave, int &size )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	min = head->value;
	max = head->value;
	double average = 0;
	size = 0;
	while ( head!=0 )
	{
		if ( head->value < min )
			min = head->value;
		if ( head->value > max )
			max = head->value;
		++size;
		average = (average*(size-1) + head->value)/size;
		head = head->next;
	}
	ave = average;
}

int main()
{
	Node *list = BuildAList();
	Node *onethird = 0;
	Node *twothirds = 0;

	int n;
	cout << "Enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The list:\n";
	Display( list );

	int min;
	int max;
	int size;
	int ave;
	Statistics( list, min, max, ave, size );

	cout << "Statistics:\n";
	cout << "min: " << min << endl;
	cout << "max: " << max << endl;
	cout << "size: " << size << endl;
	cout << "average: " << ave << endl;

	system("pause");
	return 0;
}