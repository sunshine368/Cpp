#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Determine if a singly linked list is a palindrome.
*/

/*
Method 1: use stack.
Time complexity: O(n).
Space complexity: O(n).
*/
bool isPalindrome( Node *head )
{
	// count: number of nodes in the list
	// fast: points to the empty node after the last node
	// slow: points to the middle node, i.e., the nth node if there are 2n nodes, or the nth node if there are 2n-1 nodes.
	Node *fast = head;
	Node *slow = head;
	int count = 0;
	while ( fast!=0 )
	{
		++count;
		fast = fast->next;
		if ( fast==0 )
			break;
		++count;
		fast = fast->next;
		if ( fast==0 )
			break;
		slow = slow->next;
	}
	
	// put the first n nodes into a stack, assuming there are 2n or 2n-1 nodes in total
	Node *stack = BuildAList();
	Node *p = head;
	while ( p!=slow )
	{
		InsertAtFront( &stack, p->value );
		p = p->next;
	}
	InsertAtFront( &stack, p->value );

	if ( count%2==0 )
		fast = slow->next;
	else
		fast = slow;
	while ( fast!=0 )
	{
		if ( stack->value != fast->value )
			return false;
		Node *temp = stack;
		stack = stack->next;
		delete temp;
		fast = fast->next;
	}
	return true;
}

/*
Method 2: reverse the second half of the list
Time complexity: O(n).
Space complexity: O(1).
*/
void ReverseSingleList( Node **head )
{
	if ( *head==0 || (*head)->next==0 )
		return;

	Node *prev = 0;
	Node *cur = *head;
	Node *nxt = cur->next;
	cur->next = prev;
	prev = cur;
	cur = nxt;
	while ( cur!=0 )
	{
		nxt = cur->next;
		cur->next = prev;
		prev = cur;
		cur = nxt;
	}
	*head = prev;
}

bool isPalindrome2( Node *head )
{
	// find the right half of the list
	Node *fast = head;
	Node *slow = head;
	while ( fast!=0 )
	{
		fast = fast->next;
		if ( fast==0 )
			break;
		fast = fast->next;
		if ( fast==0 )
			break;
		slow = slow->next;
	}
	Node *rh = slow->next;
	slow->next = 0;

	// reverse the right half of the list
	ReverseSingleList( &rh );

	Node *rp = rh;
	Node *lp = head;
	while ( rp!=0 && lp!=0 )
	{
		if ( rp->value!=lp->value )
			return false;
		rp = rp->next;
		lp = lp->next;
	}
	return true;
}

int main()
{
	Node *list1 = BuildAList(); // a list with n nodes
	Node *list2 = BuildAList(); // a list with odd number of nodes
	Node *list3 = BuildAList(); // a list with even number of nodes

	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
	{
		InsertAtFront( &list1, rand()%100 );
		InsertAtFront( &list2, n-i );
		InsertAtFront( &list3, 2*n-i );
	}
	InsertAtFront( &list2, n );
	for ( int i=0; i<n; i++ )
	{
		InsertAtFront( &list2, i+1 );
		InsertAtFront( &list3, n+i+1 );
	}

	cout << "list1:\n";
	Display( list1 );

	bool result1 = isPalindrome2( list1 );
	if ( result1 )
		cout << "list1 is a palindrome.\n";
	else
		cout << "list1 is not a palindrome.\n";

	cout << "list2:\n";
	Display( list2 );

	bool result2 = isPalindrome2( list2 );
	if ( result2 )
		cout << "list2 is a palindrome.\n";
	else
		cout << "list2 is not a palindrome.\n";

	cout << "list3:\n";
	Display( list3 );

	bool result3 = isPalindrome2( list3 );
	if ( result3 )
		cout << "list3 is a palindrome.\n";
	else
		cout << "list3 is not a palindrome.\n";

	system("pause");
	return 0;
}