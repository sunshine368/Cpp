#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *next;
};

Node *BuildAList()
{
    Node *head = 0;
    return head;
}

bool InsertAtFront( Node **head, int data )
{
    Node *new_head = new Node;
    if ( !new_head )
        return false;
    
    new_head->value = data;
    new_head->next = *head;
    *head = new_head;
    return true;
}

void Display( Node *head )
{
    while ( head!=0 )
    {
        cout << head->value << " ";
        head = head->next;
    }
    cout << endl;
}

/*
Given a singly linked list and an integer number, delete the first node whose 
value equals the given number. Return a pointer to the node after the deleted 
node or a null pointer.
Time complexity: O(n).
Space complexity: O(1).
Cases:
(1). empty list
(2). The head node contains the given value.
(3). A non-head node contains the given value.
(4). No node in the list contains the given value.
*/
Node* DeleteOneNodeByValue( Node **head, int data )
{
	if ( *head==0 ) // empty list
		return 0;

	Node *toBeDeleted;
    if ( (*head)->value == data ) // if the head contains the given value
    {
        toBeDeleted = *head;
        *head = (*head)->next;
        delete toBeDeleted;
        return *head;
    }
    
    Node *prev = *head;
    Node *cur = prev->next;
    while ( cur!=0 && cur->value!=data )
    {
        prev = cur;
        cur = prev->next;
    }
    
    if ( cur!=0 ) // if a non-head node contains the given value
    {
        toBeDeleted = cur;
        prev->next = cur->next;
        delete toBeDeleted;
    }
    
    return prev->next; // return a pointer to the node after the deleted node or a null pointer
}

/*
Given a singly linked list and an integer number, delete all the nodes whose
value equal the given number. Return a pointer to the node after the last 
deleted node or a null pointer.
Time complexity: O(n).
Space complexity: O(1).
Cases:
(1). empty list
(2). The head node contains the given value.
(3). The first k>1 nodes contain the given value.
(4). A node not in the front of the list contains the given value.
(5). No node in the list contains the given value.
 */
Node* DeleteNodesByValue( Node **head, int data )
{
	if ( *head==0 ) // empty list
		return 0;

    while ( (*head)->value == data ) // the first k>0 nodes contain the given value
    {
        Node *toBeDeleted = *head;
        *head = (*head)->next;
        delete toBeDeleted;
    }
    
    Node *prev = *head;
    Node *elem = prev->next;
    while ( elem!=0 )
    {
        if ( elem->value==data ) // a node not in the front of the list contains the given value
        {
            Node *toBeDeleted = elem;
            prev->next = elem->next;
            delete toBeDeleted;
            elem = prev->next;
        }
        else
        {
            prev = elem;
            elem = prev->next;
        }
    }
    
    return prev->next; // return a pointer to the node after the last deleted node or a null pointer
}

int main()
{
    Node *list = BuildAList();
    
    int n;
    cout << "Please enter number of nodes:\n";
    cin >> n;
    
    srand(time(NULL));
    for ( int i=0; i<n; i++ )
        InsertAtFront( &list, rand()%100 );
    
    cout << "The list:\n";
    Display( list );
    
    int deleteValue;
    cout << "Please enter the value to be deleted:\n";
    cin >> deleteValue;
    
    DeleteOneNodeByValue( &list, deleteValue );

    cout << "After deleting the first " << deleteValue << ":\n";
    Display( list );
    
    // illustration of DeleteNodesByValue()
    cout << "\nCreate another list.\n";
    Node *list2 = BuildAList();
    
    int n2;
    cout << "Please enter the number of nodes of the new list:\n";
    cin >> n2;
    
    int data;
    for ( int i=0; i<n2; i++ )
    {
        cout << "Please enter a value:\n";
        cin >> data;
        InsertAtFront( &list2, data );
    }
    
    cout << "The new list:\n";
    Display( list2 );
    
    int toBeDeleted;
    cout << "Please enter the value to be deleted:\n";
    cin >> toBeDeleted;
    
    DeleteNodesByValue( &list2, toBeDeleted );
    
    cout << "After deleting " << toBeDeleted << ":\n";
    Display( list2 );
    
    return 0;
}