#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list with no loop, find the middle Node. 
For example, given 1->2->3->4->5->6->7->8, the output is 4; 
given 1->2->3->4->5->6->7->8->9, the output is 5.
*/
Node *findMidNode( Node *head )
{
	if ( head==0 ) // if empty list
		return 0;
	else if ( head->next==0 ) // if only one node
		return head; 
	else if ( (head->next)->next==0 ) // if only two nodes
		return head;

	Node *end = head;
	Node *mid = head;
	while ( end->next!=0 )
	{
		end = end->next;
		if ( end->next==0 )
			break;
		end = end->next;
		mid = mid->next;
	}
	
	return mid;
}

/*
Given a linked list whose odd-indexed nodes are in increasing order and 
even-indexed nodes are in decreasing order, reorder the list such that
all odd-indexed nodes are linked together and all even-indexed nodes are 
linked together, both in increasing order. For example, given
1->9->3->8->5->7->7, the output is 1->3->5->7->7->8->9.
*/
void reorderList( Node *head )
{
	if ( head==0 || head->next==0 || (head->next)->next==0 ) // if 0, 1, or 2 nodes
		return;

	Node *even = 0; // list of even-indexed nodes
	Node *odd = head; // list of odd-indexed nodes
	Node *temp = 0;
	while ( true )
	{
		if ( odd->next==0 )
			break;
		temp = odd->next; // one more even-indexed node to be added
		odd->next = (odd->next)->next;
		temp->next = even;
		even = temp;
		if ( odd->next==0 )
			break;
		odd = odd->next;
	}
	odd->next = even;
}

int main()
{
	Node *list = BuildAList();

	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	if ( n%2==0 )
	{
		int k = n/2;
		for ( int i=k; i>0; i-- )
		{
			InsertAtFront( &list, 10-i );
			InsertAtFront( &list, 2*i-1 );
		}
	}
	else
	{
		int k = n/2;
		InsertAtFront( &list, n );
		for ( int i=k; i>0; i-- )
		{
			InsertAtFront( &list, 10-i );
			InsertAtFront( &list, 2*i-1 );
		}
	}

	cout << "The orignal list:\n";
	Display( list );

	reorderList( list );
	cout << "After reordering:\n";
	Display( list );

	system("pause");
	return 0;
}