#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

Node *FindKthNode( Node *head, int k )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return 0;
	}

	while ( head!=0 )
	{
		if ( k==1 )
			break;
		--k;
		head = head->next;
	}
	if ( k==1 )
		return head;
	return 0;
}

/*
Given a singly linked list, find the kth-to-the-last node.
*/
Node *FindKthToTheLastNode( Node *head, int k )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return 0;
	}

	Node *first = head;
	while ( first!=0 )
	{
		if ( k==1 )
			break;
		--k;
		first = first->next;
	}
	if ( k!=1 || first==0 )
		return 0;
	
	Node *second = head;
	while ( first->next!=0 )
	{
		first = first->next;
		second = second->next;
	}
	return second;
}

int main()
{
	Node *list = BuildAList();

	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The list:\n";
	Display( list );

	int k1;
	cout << "Please enter the index:\n";
	cin >> k1;

	Node *found1 = FindKthNode( list, k1 );
	if ( found1!=0 )
		cout << found1->value << endl;

	cout << "Please enter the index:\n";
	cin >> k1;
	Node *found2 = FindKthToTheLastNode( list, k1 );
	if ( found2!=0 )
		cout << found2->value << endl;

	system("pause");
	return 0;
}