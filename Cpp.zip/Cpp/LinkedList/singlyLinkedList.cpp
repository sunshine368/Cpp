#include <iostream>
#include <ctime>
using namespace std;

// Node of a singly linked list
struct Node
{
	int value;
	Node *next;
};

// Insert a node with a given value at the front of a singly linked list.
bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
	{
		return false;
	}
	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

// Create a new singly linked list which is empty.
Node *BuildAList( )
{
	Node *head = 0;
	return head;
}

// Display the values of a singly linked list.
void Display( Node *list )
{
	while ( list!=0 )
	{
		cout << list->value << " ";
		list = list->next;
	}
	cout << endl;
}

// Append a singly linked list to another singly linked list.
void AppendAList( Node **list1, Node *list2 )
{
	if ( (*list1)==0 )
	{
		(*list1) = list2;
		return;
	}

	Node *pos = *list1;
	while ( pos->next!=0 )
	{
		pos = pos->next;
	}
	pos->next = list2;
}

int main()
{
	// illustration of BuildAList()
	Node *list1 = BuildAList();
	Node *list2 = BuildAList();
	Node *list3 = BuildAList();
	Node *list4 = BuildAList();

	// illustration of InsertAtFront()
	int n;
	cout << "Please enter n:\n";
	cin >> n;
	srand(time(NULL));
	for ( int i=0; i<n; i++ )
	{
		InsertAtFront( &list1, rand()%100 );
		InsertAtFront( &list2, rand()%100 );
		InsertAtFront( &list3, rand()%100 );
		InsertAtFront( &list4, rand()%100 );
	}
	InsertAtFront( &list1, rand()%100 );
	InsertAtFront( &list3, rand()%100 );
	cout << "Linked list 1:\n";
	Display( list1 );
	cout << "Linked list 2:\n";
	Display( list2 );
	cout << "Linked list 3:\n";
	Display( list3 );
	cout << "Linked list 4:\n";
	Display( list4 );
	cout << endl;

	// illustration of AppendAList()
	AppendAList( &list1, list4 );
	AppendAList( &list3, list4 );
	cout << "After appending list4 to list1:\n";
	Display( list1 );
	cout << "After appending list4 to list3:\n";
	Display( list3 );
	cout << endl;

	system("pause");
	return 0;
}