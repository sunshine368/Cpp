// Given a sorted linked list and a value to be searched, find the node having the value.
// Time complexity: O(n).

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;
	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
		return;
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

Node *findInSortedList( Node *head, int data )
{
    Node *p = head;
    while ( p!=0 )
    {
        if ( p->value==data )
            return p;
        p = p->next;
    }
    return 0;
}

int main()
{
    Node *list = BuildAList();
    srand(time(NULL));
    int n;
    cout << "Enter n:\n";
    cin >> n;
    for ( int i=0; i<n; i++ )
    {
        InsertAtFront( &list, rand()%100 );
    }
    
    Display( list );
    
    int data;
    cout << "Enter the value for searching:\n";
    cin >> data;
    
    Node *result = findInSortedList( list, data );
    if ( !result )
        cout << data << " not found.\n";
    else
        cout << data << " found.\n";

	return 0;
}