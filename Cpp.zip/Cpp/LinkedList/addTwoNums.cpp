/*
Given two numbers represented by two singly linked lists, add 
the two numbers and store the sum in another linked list.
For example, given 1->2->3 and 1->0->2->3->4, the output is 
1->0->3->5->7.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Method 1: 
(1). Convert the linked lists to two integers.
(2). Add the two integers and obtain a sum.
(3). Convert the sum integer to a linked list.
No reverse of linked list is needed.
Time complexity: O(n1+n2).
*/
int AddTwoNumsAux( Node *h1, Node *h2 )
{
	Node *p1 = h1;
	int n1 = 0;
	while ( p1!=0 )
	{
		n1 = n1*10 + p1->value;
		p1 = p1->next;
	}

	Node *p2 = h2;
	int n2 = 0;
	while ( p2!=0 )
	{
		n2 = n2*10 + p2->value;
		p2 = p2->next;
	}

	return n1+n2;
}

Node *AddTwoNums( Node *h1, Node *h2 )
{
	int sum = AddTwoNumsAux( h1, h2 );
	Node *head = BuildAList();
	while ( sum!=0 )
	{
		InsertAtFront( &head, sum%10 );
		sum = sum/10;
	}
	return head;
}

/*
Method 2:
(1). Reverse the two lists.
(2). Add the two values of each pair of nodes, together with the 
carry. Add the sum to the resultant list.
Time complexity: O(max{n1,n2}).
*/
void ReverseSingleList( Node **head )
{
	Node *cur = *head;
	Node *prev = 0;
	Node *next;
	while ( cur!=0 )
	{
		next = cur->next;
		cur->next = prev;
		prev = cur;
		cur = next;
	}
	*head = prev;
}

Node *AddTwoNums2( Node *h1, Node *h2 )
{
	ReverseSingleList( &h1 );
	ReverseSingleList( &h2 );

	int carry = 0;
	Node *result = BuildAList();
	int temp;
	while ( h1!=0 && h2!=0 )
	{
		temp = h1->value + h2->value + carry;
		InsertAtFront( &result, temp%10 );
		carry = temp/10;
		h1 = h1->next;
		h2 = h2->next;
	}

	if ( h1!=0 )
	{
		while ( h1!=0 )
		{
			temp = h1->value + carry;
			InsertAtFront( &result, temp%10 );
			carry = temp/10;
			h1 = h1->next;
		}
	}
	else
	{
		while ( h2!=0 )
		{
			temp = h2->value + carry;
			InsertAtFront( &result, temp%10 );
			carry = temp/10;
			h2 = h2->next;
		}
	}

	if ( carry!=0 )
		InsertAtFront( &result, carry );

	return result;
}

int main()
{
	srand(time(NULL));
	
	// illustration of AddTwoNums()
	Node *list1 = BuildAList();
	Node *list2 = BuildAList();

	int n1;
	cout << "Enter number of nodes in list1:\n";
	cin >> n1;

	for ( int i=0; i<n1; i++ )
		InsertAtFront( &list1, rand()%10 );

	cout << "list1:\n";
	Display( list1 );

	int n2;
	cout << "Enter number of nodes in list2:\n";
	cin >> n2;

	for ( int i=0; i<n2; i++ )
		InsertAtFront( &list2, rand()%10 );

	cout << "list2:\n";
	Display( list2 );

	Node *result = AddTwoNums( list1, list2 );

	cout << "The sum:\n";
	Display( result );

	// illustration of AddTwoNums2()
	Node *list3 = BuildAList();
	Node *list4 = BuildAList();

	int n3;
	cout << "Enter number of nodes in list3:\n";
	cin >> n3;

	for ( int i=0; i<n3; i++ )
		InsertAtFront( &list3, rand()%10 );

	cout << "list3:\n";
	Display( list3 );

	int n4;
	cout << "Enter number of nodes in list4:\n";
	cin >> n4;

	for ( int i=0; i<n4; i++ )
		InsertAtFront( &list4, rand()%10 );

	cout << "list4:\n";
	Display( list4 );

	Node *result2 = AddTwoNums2( list3, list4 );

	cout << "The sum:\n";
	Display( result2 );

	system("pause");
	return 0;
}