#include <iostream>
#include <ctime>
#include <string>
using namespace std;

/*
Assume that the head node of a doubly linked list has no previous node,
and the last node of a doubly linked list has no next node.
*/
struct Node 
{
	int value;
	Node *prev;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->prev = 0;
	new_head->next = *head;
	if ( *head!=0 )
		(*head)->prev = new_head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Method 1: 
Traverse the list and count the number of 1's, 2's and 3's.
Traverse the list again, modify the values according to the numbers obtained above.
Also applicable to singly linked list.
Time complexity: O(n).
Space complexity: O(1).
*/
void DutchNationalFlag( Node *head )
{
	int hashtable[3] = {0};
	Node *p = head;
	while ( p!=0 )
	{
		hashtable[p->value-1]++;
		p = p->next;
	}

	p = head;
	for ( int i=0; i<3; i++ )
	{
		while ( hashtable[i]>0 )
		{
			--hashtable[i];
			p->value = i+1;
			p = p->next;
		}
	}
}

/*
Method 2:
*/
/* 
Delete a node from a doubly linked list, and return the node 
with no previous or next node. 
*/
Node *DeleteByNode( Node **head, Node *d )
{
	if ( d==0 )
		return 0;

	if ( d==*head ) // delete the head node of a doubly linked list
	{
		if ( d->next==0 ) // the list contains only one node
		{
			Node *r = d;
			*head = 0;
			return r;
		}
		else // the list contains more than one node
		{
			Node *r = d;
			*head = d->next;
			(d->next)->prev = 0;
			r->next = 0;
			return r;
		}
	}
	else // delete a non-head node of a doubly linked list
	{
		if ( d->next==0 ) // delete the last node of the list
		{
			Node *r = d;
			(d->prev)->next = 0;
			r->prev = 0;
			r->next = 0;
			return r;
		}
		else // delete a node in the middle of the list, neither head nor last node
		{
			Node *r = d;
			(d->prev)->next = d->next;
			(d->next)->prev = d->prev;
			r->prev = 0;
			r->next = 0;
			return r;
		}
	}
}

/*
Insert a node of a doubly linked list after another node, return a 
pointer to the node inserted.
*/
Node *InsertAfterNode( Node *n, Node *i )
{
	if ( i==0 || n==0 )
		return 0;

	if ( n->next==0 )
	{
		n->next = i;
		i->next = 0;
		i->prev = n;
		return i;
	}
	else
	{
		i->next = n->next;
		(i->next)->prev = i;
		n->next = i;
		i->prev = n;
		return i;
	}
}

/*
Insert a node to the front of a doubly linked list.
*/
void InsertAtFrontByNode( Node **head, Node *i )
{
	if ( i==0 )
		return;

	if ( *head==0 )
	{
		i->prev = 0;
		i->next = 0;
		*head = i;
	}
	else
	{
		i->prev = 0;
		i->next = *head;
		(*head)->prev = i;
		*head = i;
	}
}

/*
Method 2: 
Let three point to the last node of the list.
Traverse the list: put each node of value 1 to the front of the list;
put each node of value 3 to the end of the list; do nothing to node
of value 2.
Time complexity: O(n).
Space complexity: O(1).
*/
void DutchNationalFlag2( Node **head )
{
	if ( *head==0 )
		return;

	// find the last node of the list
	Node *three = *head;
	while ( three->next!=0 )
	{
		three = three->next;
	}
	Node *end = three; // mark the last node of the list

	Node *p = *head;
	while ( p!=end ) 
	{
		Node *move = p;
		p = p->next;
		if ( move->value==1 ) // move the node of value 1 to the head of the list
		{
			move = DeleteByNode( head, move );
			InsertAtFrontByNode( head, move );
		}
		else if ( move->value==3 ) // move the node of value 3 to the end of the list
		{
			move = DeleteByNode( head, move );
			three = InsertAfterNode( three, move );
		}
	} 

	// put the last node in its right place
	if ( p->value==1 )
	{
		p = DeleteByNode( head, p );
		InsertAtFrontByNode( head, p );
	}
	else if ( p->value==3 )
	{
		p = DeleteByNode( head, p );
		three = InsertAfterNode( three, p );
	}
}


int main()
{
	// illustration of DutchNationalFlag()
	Node *list = BuildAList();

	string data;
	cout << "Please enter 1, 2, or 3; enter any other character to end the list:\n";
	cin >> data;
	for ( int i=0; i<data.length(); i++ )
		InsertAtFront( &list, (int)(data[i]-'0') );

	cout << "The list:\n";
	Display( list );

	DutchNationalFlag( list );

	cout << "After sorting:\n";
	Display( list );

	// illustration of DeleteByNode()
	Node *list2 = BuildAList();

	int n2;
	cout << "Please enter number of nodes:\n";
	cin >> n2;

	srand(time(NULL));
	for ( int i=0; i<n2; i++ )
		InsertAtFront( &list2, rand()%100 );

	cout << "The list:\n";
	Display( list2 );

	DeleteByNode( &list2, list2 );

	cout << "After deleting the first node:\n";
	Display( list2 );

	// illustration of DutchNationalFlag2()
	Node *list3 = BuildAList();

	string data3;
	cout << "Please enter 1, 2, or 3; enter any other character to end the list:\n";
	cin >> data3;
	for ( int i=0; i<data3.length(); i++ )
		InsertAtFront( &list3, (int)(data3[i]-'0') );

	cout << "The list:\n";
	Display( list3 );

	DutchNationalFlag2( &list3 );

	cout << "After sorting:\n";
	Display( list3 );

	system("pause");
	return 0;
}