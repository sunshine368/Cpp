#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *next;
};

Node *BuildAList()
{
    Node *head = 0;
    return head;
}

bool InsertAtFront( Node **head, int data )
{
    Node *new_head = new Node;
    if ( !new_head )
        return false;
    new_head->value = data;
    new_head->next = *head;
    *head = new_head;
    return true;
}

void Display( Node *head )
{
    if ( head==0 )
        return;
    while ( head!=0 )
    {
        cout << head->value << " ";
        head = head->next;
    }
    cout << endl;
}

/*
Given a sorted linked list, delete all duplicate numbers and leave only distinct numbers
from original list. For example, given 1->2->3->3->4->4->5, return 1->2->5.
*/
void deleteDuplicates( Node **head )
{
    Node *cur = *head;
    Node *prev = *head;
    bool duplicate = false;
    while ( cur!=0 )
    {
        // search duplicate nodes after cur and delete them
        Node *p = cur->next;
        while ( p!=0 && p->value==cur->value )
        {
            Node *temp = p;
            cur->next = p->next;
            p = cur->next;
            delete temp;
            duplicate = true;
        }
        if ( duplicate )
        {
            if ( cur==*head )
            {
                Node *temp = cur;
                *head = cur->next;
                delete temp;
                duplicate = false;
                cur = *head;
            }
            else
            {
                Node *temp = cur;
                prev->next = cur->next;
                delete temp;
                duplicate = false;
            }
        }
        else
        {
            prev = cur;
            cur = cur->next;
        }
    }
}

void SelectSortSingleList( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}
    
	for ( Node *first = head; first->next!=0; first=first->next )
	{
		for ( Node *second = first->next; second!=0; second=second->next )
		{
			if ( second->value < first->value )
			{
				int temp = second->value;
				second->value = first->value;
				first->value = temp;
			}
		}
	}
}

int main()
{
    Node *list = BuildAList();
    int n;
    cout << "Enter n:\n";
    cin >> n;
    
    srand(time(NULL));
    for ( int i=0; i<n; i++ )
        InsertAtFront( &list, rand()%100 );
    
    SelectSortSingleList( list );

    cout << "The sorted list:\n";
    Display( list );
    
    deleteDuplicates( &list );
    
    cout << "The modified list:\n";
    Display( list );
    
    return 0;
}