#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
	Node *prev;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	new_head->prev = 0;
	if ( *head!=0 )
		(*head)->prev = new_head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a doubly linked list which contains only 1, 2, and 3, 
sort it in increasing order.
*/

/*
Method 1: modify values of nodes. Also applicable to singly linked list.
Time complexity: O(n).
Space complexity: O(1).
*/
void DutchNationalFlagDouble( Node *head )
{
	int n1 = 0; 
	int n2 = 0;
	int n3 = 0;

	// count the number of 1's, 2's and 3's and store them in n1, n2, n3
	Node *p = head;
	while ( p!=0 )
	{
		if ( p->value==1 )
			++n1;
		else if ( p->value==2 )
			++n2;
		else
			++n3;
		p = p->next;
	}

	// make values of the first n1 nodes to 1, the next n2 nodes to 2, and the last n3 nodes to 3
	p = head;
	while ( n1>0 )
	{
		p->value = 1;
		p = p->next;
		--n1;
	}
	while ( n2>0 )
	{
		p->value = 2;
		p = p->next;
		--n2;
	}
	while ( n3>0 )
	{
		p->value = 3;
		p = p->next;
		--n3;
	}
}

/*
Method 2: group the nodes into three lists by values and link the three lists
Time complexity: O(n).
Space complexity: O(1).
*/
void DutchNationalFlagDouble2( Node **head )
{
	// let one, two, three point to head nodes of lists of 1's, 2's and 3's respectively
	Node *one = 0;
	Node *two = 0;
	Node *three = 0;

	// let end1, end2, end3 point to the last node of lists of 1's, 2's and 3's respectively
	Node *end1 = 0;
	Node *end2 = 0;
	Node *end3 = 0;

	// traverse the list, append each node to lists of 1's, 2's and 3's according to the value
	Node *p = *head;
	while ( p!=0 )
	{
		if ( p->value==1 )
		{
			if ( one==0 )
			{
				one = p;
				p->prev = 0;
				end1 = one;
			}
			else
			{
				end1->next = p;
				p->prev = end1;
				end1 = p;
			}
		}
		else if ( p->value==2 )
		{
			if ( two==0 )
			{
				two = p;
				p->prev = 0;
				end2 = two;
			}
			else
			{
				end2->next = p;
				p->prev = end2;
				end2 = p;
			}
		}
		else
		{
			if ( three==0 )
			{
				three = p;
				p->prev = 0;
				end3 = three;
			}
			else
			{
				end3->next = p;
				p->prev = end3;
				end3 = p;
			}
		}
		p = p->next;
	}

	// connect the three lists
	if ( one!=0 ) // if no 1's in the list
		*head = one;
	else if ( two!=0 ) // if no 1's or 2's in the list
		*head = two;
	else
		*head = three;

	if ( end1!=0 ) // if there are 1's in the list
	{
		if ( two!=0 ) // if there are 1's and 2's in the list
		{
			end1->next = two;
			two->prev = end1;
		}
		else if ( three!=0 ) // if there are 1's, 3's but no 2's
		{
			end1->next = three;
			three->prev = end1;
		}
		else
		{
			end1->next = 0; // if there are 1's, but no 2's or 3's
		}
	}

	if ( end2!=0 ) // if there are 2's in the list
	{
		if ( three!=0 ) // if there are 2's and 3's
		{
			end2->next = three;
			three->prev = end2;
		}
		else // if there are 2's but no 3's
			end2->next = 0;
	}

	if ( end3!=0 ) // if there are 3's in the list
		end3->next = 0;
	//else if ( end2!=0 ) // if no 3's but 2's in the list
	//	end2->next = 0;
	//else if ( end1!=0 ) // if no 3's or 2's in the list
	//	end1->next = 0;
}

// To test if the prev links in a doubly linked list DO work.
void DisplayReverse( Node *head )
{
	while ( head!=0 && head->next!=0 )
	{
		head = head->next;
	}
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->prev;
	}
	cout << endl;
}

int main()
{
	// illustration of DutchNationalFlagDouble()
	Node *list = BuildAList();

	int n;
	cout << "Enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%3+1 );

	cout << "The list:\n";
	Display( list );

	DutchNationalFlagDouble( list );

	cout << "After sorting:\n";
	Display( list );

	cout << "Reverse of list:\n";
	DisplayReverse( list );

	// illustration of DutchNationalFlagDouble2()
	Node *list2 = BuildAList();

	int n2;
	cout << "Enter number of nodes:\n";
	cin >> n2;

	srand(time(NULL));
	for ( int i=0; i<n2; i++ )
		InsertAtFront( &list2, rand()%3+1 );

	cout << "The list:\n";
	Display( list2 );

	DutchNationalFlagDouble2( &list2 );

	cout << "After sorting:\n";
	Display( list2 );

	cout << "Reverse of list2:\n";
	DisplayReverse( list2 );

	system("pause");
	return 0;
}