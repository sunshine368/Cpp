#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
	bool isVertex;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data, bool isVert )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	if ( isVert )
		new_head->isVertex = true;
	else
		new_head->isVertex = false;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	cout << "Value\t" << "Is Vertext?" << endl;
	while ( head!=0 )
	{
		cout << head->value << "\t";
		if ( head->isVertex )
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
		head = head->next;
	}
	cout << endl;
}
/*
Given a singly linked list with three fields, value, next node and whether it is 
a vertex, find the maximum distance between any pair of vertices.
Time complexity: O(n).
Space complexity: O(n).
*/
int findMaxSubSum( Node *head )
{
	// traverse the list, find the distance between each pair of consecutive vertice
	Node *p = head;
	int sum = 0; // sum of the values between each pair of consecutive vertice
	bool flag = false;
	Node *d = BuildAList(); // a linked list storing the distance between each pair of consecutive vertice
	while ( p!=0 )
	{
		if ( p->isVertex )
		{
			if ( !flag ) // set flag=true when the first vertex node is met
				flag = true;
			else
				InsertAtFront( &d, sum, 0 ); // save the distance between each pair of consecutive vertice
			sum = 0; // reset sum for each vertex node
		}
		else if ( flag ) // add the values between each pair of consecutive vertice
			sum += p->value;
		p = p->next;
	}

	// display the distance between each pair of consecutive vertice
	p = d;
	while ( p!=0 )
	{
		cout << p->value << endl;
		p = p->next;
	}

	// find the maximum distance between each node and one of its following nodes
	p = d;
	if ( p==0 ) // if there is at most one vertex in the original list
		return 0;
	if ( p->next==0 ) // if there are exactly two vertice in the original list
		return p->value;
	int prev = p->value;
	p = p->next;
	while ( p!=0 )
	{
		if ( p->value < p->value + prev )
		{
			p->value = p->value + prev;
			prev = p->value;
		}
		else
			prev = p->value;
		p = p->next;
	}

	// find the maximum distance between any pair of vertice
	p = d;
	int max = p->value;
	while ( p!=0 )
	{
		if ( p->value > max )
			max = p->value;
		p = p->next;
	}
	return max;
}

int main()
{
	Node *list = BuildAList();
	srand(time(NULL));
	int max_size = 100;
	int count = 0;
	int data;
	int min = -50;
	bool isVertex;
	cout << "Value\t" << "Is Vertex?\n";
	while ( rand()%10!=0 && count<max_size )
	{
		data = rand()%100 + min;
		isVertex = rand()%2;
		InsertAtFront( &list, data, isVertex );
		cout << data << "\t" << isVertex << "\n";
		++count;
	}
	cout << endl;

	int result = findMaxSubSum( list );
	cout << "The maximum subsequence sum is: " << result << endl;

	system("pause");
	return 0;
}