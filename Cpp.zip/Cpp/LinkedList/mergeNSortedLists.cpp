#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given n sorted non-empty linked lists, return a linked list which contains
all the nodes of the n lists in sorted order. (Duplicates allowed.)
*/
Node *MergeNSortedLists( Node **list, int *size, int n ) // Assume no list is empty.
{
	// find the minimum value of all head nodes
	int min = list[0]->value;
	int index = 0;
	for ( int i=1; i<n; i++ )
	{
		if ( list[i]!=0 && list[i]->value < min )
		{
			min = list[i]->value;
			index = i;
		}
	}

	// let head point to the head node of the merged list
	Node *head = list[index]; 

	// let p[0,...,n-1] be an array of pointers to nodes of the n lists
	Node **p = (Node**)malloc( sizeof(Node*)*n );
	for ( int i=0; i<n; i++ )
	{
		p[i] = list[i];
	}
	p[index] = p[index]->next;

	// let end point to the last node of the merged list
	Node *end = head;
	while ( true )
	{
		index = -1;
		// find the first non-zero pointer of p[0,...,n-1]
		for ( int i=0; i<n; i++ )
		{
			if ( p[i]!=0 )
			{
				min = p[i]->value;
				index = i;
				break;
			}
		}
		if ( index==-1 ) // end the loop if p[i], i=0,...,n-1, are all zero
			break;
		// find the minimum value of all nodes pointed to by non-zero p[i], i=0,...,n-1
		for ( int i=index+1; i<n; i++ )
		{
			if ( p[i]!=0 && p[i]->value < min )
			{
				min = p[i]->value;
				index = i;
			}
		}
		// append the node containing the minimum value to the merged list
		end->next = p[index];
		end = end->next;
		p[index] = p[index]->next;
	}

	return head;
}

/*
Given n sorted non-empty linked lists, return a linked list which contains
all the nodes of the n lists in sorted order. (No duplicates allowed.)
*/
Node *MergeNSortedListsNoDup( Node **list, int *size, int n ) // Assume no list is empty.
{
	// find the minimum value of all head nodes
	int min = list[0]->value;
	int index = 0;
	for ( int i=1; i<n; i++ )
	{
		if ( list[i]!=0 && list[i]->value < min )
		{
			min = list[i]->value;
			index = i;
		}
	}

	// let head point to the head node of the merged list
	Node *head = list[index]; 

	// let p[0,...,n-1] be an array of pointers to nodes of the n lists
	Node **p = (Node**)malloc( sizeof(Node*)*n );
	for ( int i=0; i<n; i++ )
	{
		p[i] = list[i];
	}
	p[index] = p[index]->next;

	// let end point to the last node of the merged list
	Node *end = head;
	int prev = head->value;
	while ( true )
	{
		index = -1;
		// find the first non-zero pointer of p[0,...,n-1]
		for ( int i=0; i<n; i++ )
		{
			if ( p[i]!=0 )
			{
				min = p[i]->value;
				index = i;
				break;
			}
		}
		if ( index==-1 ) // end the loop if p[i], i=0,...,n-1, are all zero
			break;
		// find the minimum value of all nodes pointed to by non-zero p[i], i=0,...,n-1
		for ( int i=index+1; i<n; i++ )
		{
			if ( p[i]!=0 && p[i]->value < min )
			{
				min = p[i]->value;
				index = i;
			}
		}
		// append the node containing the minimum value to the merged list if it is not a duplicate
		if ( min!=prev )
		{
			end->next = p[index];
			end = end->next;
			prev = min;
		}
		p[index] = p[index]->next;
	}

	return head;
}

void SelectSortSingleList( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	for ( Node *first = head; first->next!=0; first=first->next )
	{
		for ( Node *second = first->next; second!=0; second=second->next )
		{
			if ( second->value < first->value )
			{
				int temp = second->value;
				second->value = first->value;
				first->value = temp;
			}
		}
	}
}

int main()
{
	// illustration of MergeNSortedLists()
	int n;
	cout << "Enter number of lists:\n";
	cin >> n;

	int *size = (int*)malloc( sizeof(int)*n );
	Node **list = (Node**)malloc( sizeof(Node*)*n );
	srand(time(NULL));
	for ( int i=0; i<n; i++ )
	{
		size[i] = rand()%20;
		list[i] = BuildAList();
		for ( int j=0; j<size[i]; j++ )
			InsertAtFront( &list[i], rand()%100 );
		SelectSortSingleList( list[i] );
		cout << "list" << i+1 << ":\n";
		Display( list[i] );
	}

	Node *head = MergeNSortedLists( list, size, n );

	cout << "The merged list:\n";
	Display( head );

	// illustration of MergeNSortedListsNoDup()
	int n2;
	cout << "Enter number of lists:\n";
	cin >> n2;

	int *size2 = (int*)malloc( sizeof(int)*n2 );
	Node **list2 = (Node**)malloc( sizeof(Node*)*n2 );
	for ( int i=0; i<n2; i++ )
	{
		size2[i] = rand()%20;
		list2[i] = BuildAList();
		for ( int j=0; j<size2[i]; j++ )
			InsertAtFront( &list2[i], rand()%100 );
		SelectSortSingleList( list2[i] );
		cout << "list" << i+1 << ":\n";
		Display( list2[i] );
	}

	Node *head2 = MergeNSortedListsNoDup( list2, size2, n2 );

	cout << "The merged list:\n";
	Display( head2 );

	system("pause");
	return 0;
}