#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

Node *AccessByIndex( Node *head, int index )
{
	while ( head!=0 )
	{		
		if ( index==1 )
			break;
		head = head->next;
		--index;
	}
	if ( index==1 )
	{
		return head;
	}
	return 0;
}

/*
Given a pointer to a node of a singly linked list, delete the node from the list.
Limitation: The node cannot be deleted if it is the last node.
*/
bool DeleteByNode( Node *del )
{
	if ( del==0 )
	{
		cout << "Empty node.\n";
		return false;
	}
	if ( del->next==0 )
	{
		cout << "The last node of a singly linked list cannot be deleted.\n";
		return false;
	}

	Node *temp = del->next;
	del->value = (del->next)->value;
	del->next = (del->next)->next;
	delete temp;
	return true;
}

int main()
{
	Node *list = BuildAList();

	int size;
	cout << "Please enter number of nodes:\n";
	cin >> size;

	srand(time(NULL));
	for ( int i=0; i<size; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The original list:\n";
	Display( list );

	int pos;
	cout << "Please enter the index of the node to be deleted:\n";
	cin >> pos;
	Node *tobedeleted = AccessByIndex( list, pos );

	bool result = DeleteByNode( tobedeleted );

	cout << "After deletion:\n";
	Display( list );

	system("pause");
	return 0;
}