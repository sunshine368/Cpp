#include <iostream>
#include <ctime>
using namespace std;

// Node of a singly linked list
struct Node
{
	int value;
	Node *next;
};

// Create a new singly linked list which is empty.
Node *BuildAList()
{
	Node *head = 0;
	return head;
}

// Insert a node with a given value at the front of a singly linked list.
bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
	{
		return false;
	}

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

// Display the values of a singly linked list.
void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

/*
Given a singly linked list, sort the nodes in increasing order without 
using an additional node. 

Version I: selection sort method.

Pseudo-code:
SelectSortSingleList( head )
1  if head==0
1      return
1  let first and second be two pointers to node
2  for first=head to the second-to-the-last node of the list
3      for second=first->next to the last node of the list
4          if second->value < first->value
5              swap first->value and second->value 

Time complexity: O(n^2).
Space complexity: O(1), in place.
*/
void SelectSortSingleList( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	for ( Node *first = head; first->next!=0; first=first->next )
	{
		for ( Node *second = first->next; second!=0; second=second->next )
		{
			if ( second->value < first->value )
			{
				int temp = second->value;
				second->value = first->value;
				first->value = temp;
			}
		}
	}
}

/*
Version II: insertion sort method.

Pseudo-code:
InsertSortSingleList( head )
1  let first and second be two pointers to node
2  for first=head->next to the last node of the list
3      second=head
4      while ( second->value < first->value )
5          second = second->next
6      while second!=first
7          temp = first->value
8          first->value = second->value
9          second->value = temp
10         second = second->next

Time complexity: O(n^2).
Space complexity: O(1), in place.
*/

void InsertSortSingleList( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	Node *second = 0;
	for ( Node *first = head->next; first!=0; first=first->next )
	{
		second = head;
		while ( second->value < first->value )
		{
			second = second->next;
		}
		while ( second!=first )
		{
			int temp = first->value;
			first->value = second->value;
			second->value = temp;
			second = second->next;
		}
	}
}

/*
Version III: merge sort method.

Time complexity: O(nlog(n)).
Space complexity: O(n).

Pseudo-code:
MergeSortSingleList( head )
1  if head==0 or head->next==0
2      return 
3  end = head
4  while ( end->next!=0 )
5      end = end->next
6  MergeSortSingleListAux( head, end )

MergeSortSingleListAux( start, end )
1  if start==end
2      return
3  slow = start
4  fast = start
5  while fast!=end
6      fast = fast->next
7      if fast==end
8          break
9      fast = fast->next
10     if fast==end
11         break
12     slow = slow->next
13 MergeSortSingleListAux( start, slow )
14 MergeSortSingleListAux( slow+1, end )
15 Merge( start, slow, end )

Merge( start, mid, end )
1  left = start
2  right = mid->next
3  let head point to a new list
4  p = head
5  while left!=mid->next && right!=end->next
6      if ( left->value <= right->value )
7			if ( p==0 )
8				head = InsertAtBack( &p, left->value )
9			else
10				p = InsertAtBack( &p, left->value )
11			left = left->next
12     else
13			if ( p==0 )
14				head = InsertAtBack( &p, right->value )
15			else
16				p = InsertAtBack( &p, right->value )
17			right = right->next
18 if ( left==mid->next )
19     while ( right!=end->next )
20			p = InsertAtBack( &p, right->value )
21			right = right->next
22 else
23     while ( left!=mid->next )
24			p = InsertAtBack( &p, left->value )
25			left = left->next
26 copy_to = start
27 copy_from = head
28 while ( copy_to!=end->next )
29		copy_to->value = copy_from->value
30		copy_to = copy_to->next
31		copy_from = copy_from->next
32 DeleteList( head )
*/

void DisplayRange( Node *start, Node *end )
{
	while ( start!=end )
	{
		cout << start->value << " ";
		start = start->next;
	}
	cout << end->value << endl;
}

Node *InsertAtBack( Node **p, int data )
{
	Node *new_node = new Node;
	if ( !new_node )
	{
		cout << "Node construction failed!\n";
		return 0;
	}
	new_node->value = data;
	new_node->next = 0;
	if ( *p==0 )
		*p = new_node;
	else
		(*p)->next = new_node;
	return new_node;
}

void DeleteList( Node *head )
{
	if ( head==0 )
		return;

	while ( head->next!=0 )
	{
		Node *tobedeleted = head->next;
		head->next = (head->next)->next;
		delete tobedeleted;
	}

	delete head;
}

void Merge( Node *start, Node *mid, Node *end )
{
	Node *left = start;
	Node *right = mid->next;
	Node *head = BuildAList();
	Node *p = head;
	while ( left!=mid->next && right!=end->next )
	{
		if ( left->value <= right->value )
		{
			if ( p==0 )
				head = InsertAtBack( &p, left->value );
			else
				p = InsertAtBack( &p, left->value );
			left = left->next;
		}
		else
		{
			if ( p==0 )
				head = InsertAtBack( &p, right->value );
			else
				p = InsertAtBack( &p, right->value );
			right = right->next;
		}
	}

	if ( left==mid->next )
	{
		while ( right!=end->next )
		{
			p = InsertAtBack( &p, right->value );
			right = right->next;
		}
	}
	else
	{
		while ( left!=mid->next )
		{
			p = InsertAtBack( &p, left->value );
			left = left->next;
		}
	}

	Node *copy_to = start;
	Node *copy_from = head;
	while ( copy_to!=end->next )
	{
		copy_to->value = copy_from->value;
		copy_to = copy_to->next;
		copy_from = copy_from->next;
	}

	DeleteList( head );
}

void MergeSortSingleListAux( Node *start, Node *end )
{
	if ( start==end )
		return;

	Node *fast = start;
	Node *slow = start;
	while ( fast!=end )
	{
		fast = fast->next;
		if ( fast==end )
			break;
		slow = slow->next;
		fast = fast->next;
		if ( fast==end )
			break;
	}

	MergeSortSingleListAux( start, slow );
	MergeSortSingleListAux( slow->next, end );
	Merge( start, slow, end );
}

void MergeSortSingleList( Node *head )
{
	if ( head==0 || head->next==0 )
		return;

	Node *end = head;
	while ( end->next!=0 )
	{
		end = end->next;
	}

	MergeSortSingleListAux( head, end );
}

/*
Version IV: bubble sort.

Time complexity: O(n^2).
Space compleixty: O(1).

bubbleSort( head )
1  let p point to the head node
2  count = 0
3  while p!=0
4      ++count
5      p = p->next
6  for ( int i=count-1; i>=1; i-- )    
7      p = head
8      j = i
9      while ( j>0 )
10         if p->value > (p->next)->value
11             swap p->value and (p->next)->value
12         p = p->next;
13         --j
*/

void BubbleSort( Node *head )
{
    Node *p = head;
    int count = 0;
    while ( p!=0 )
    {
        ++count;
        p = p->next;
    }
    for ( int i=count-1; i>=1; --i )
    {
        p = head;
        int j = i;
        while ( j>0 && p->next!=0 )
        {
            if ( p->value > (p->next)->value )
            {
                int temp = p->value;
                p->value = (p->next)->value;
                (p->next)->value = temp;
            }
            p = p->next;
            --j;
        }
    }
}

int main()
{
	Node *list1 = BuildAList();
	Node *list2 = BuildAList();
	Node *list3 = BuildAList();
    Node *list4 = BuildAList();
	
	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
	{
		InsertAtFront( &list1, rand()%100 );
		InsertAtFront( &list2, rand()%100 );
		InsertAtFront( &list3, rand()%100 );
        InsertAtFront( &list4, rand()%100 );
	}

	cout << "list1 before sorting:\n";
	Display( list1 );

	cout << "list1 after sorting:\n";
	SelectSortSingleList( list1 );
	Display( list1 );

	cout << "list2 before sorting:\n";
	Display( list2 );

	cout << "list2 after sorting:\n";
	InsertSortSingleList( list2 );
	Display( list2 );

	cout << "list3 before sorting:\n";
	Display( list3 );

	cout << "list3 after sorting:\n";
	MergeSortSingleList( list3 );
	Display( list3 );
    
	cout << "list4 before sorting:\n";
	Display( list4 );
    
	cout << "list4 after sorting:\n";
	MergeSortSingleList( list4 );
	Display( list4 );

	return 0;
}