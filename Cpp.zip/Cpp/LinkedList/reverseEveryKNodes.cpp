#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildAList()
{
	Node *head = 0;
	return head;
}

bool InsertAtFront( Node **head, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *head;
	*head = new_head;
	return true;
}

void Display( Node *head )
{
	while ( head!=0 )
	{
		cout << head->value << " ";
		head = head->next;
	}
	cout << endl;
}

Node *ReverseAux( Node *head, int k )
{
	if ( head==0 )
		return 0;

	Node *cur = head;
	Node *prev = 0;
	Node *next;
	int count = 0;
	while ( cur!=0 && count<k )
	{
		next = cur->next;
		cur->next = prev;
		prev = cur;
		cur = next;
		++count;
	}
	if ( next!=0 )
		head->next = ReverseAux( cur, k );

	return prev;
}

/*
Given a singly linked list and a positive number k, reverse every k
node of the list. For example, given 1->2->3->4->5->6->7->8, the
output is 3->2->1->6->5->4->8->7.
*/
void Reverse( Node **head, int k )
{
	if ( k<=0 )
		return;

	if ( head==0 )
		return;

	Node *cur = *head;
	Node *prev = 0;
	Node *next;
	int count = 0;
	while ( cur!=0 && count<k )
	{
		next = cur->next;
		cur->next = prev;
		prev = cur;
		cur = next;
		++count;
	}

	if ( next!=0 )
	{
		(*head)->next = ReverseAux( cur, k );
	}
	*head = prev;
}

int main()
{
	Node *list = BuildAList();

	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%100 );

	cout << "The list:\n";
	Display( list );

	int k;
	cout << "Please enter k:\n";
	cin >> k;

	Reverse( &list, k );

	cout << "After modification:\n";
	Display( list );

	system("pause");
	return 0;
}