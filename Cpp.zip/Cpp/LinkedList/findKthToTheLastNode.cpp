#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *next;
};

Node *BuildAList()
{
    Node *head = 0;
    return head;
}

bool InsertAtFront( Node **head, int data )
{
    Node *new_head = new Node;
    if ( !new_head )
        return false;
    
    new_head->value = data;
    new_head->next = *head;
    *head = new_head;
    return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

    while ( head!=0 )
    {
        cout << head->value << " ";
        head = head->next;
    }
    cout << endl;
}

/*
Given a singly linked list and an integer k, return the kth-to-the-last node.
*/
Node *findKthToTheLastNode( Node *head, int k )
{
	if ( k<=0 )
		return 0;

	if ( head==0 )
		return 0;

	Node *p = head;
	int count = 0;
	while ( p!=0 && count<k )
	{
		++count;
		p = p->next;
	}
	if ( count<k )
	{
		cout << "Not long enough.\n";
		return 0;
	}
	else
	{
		Node *r = head;
		while ( p!=0 )
		{
			p = p->next;
			r = r->next;
		}
		return r;
	}
}
	 
int main()
{
    Node *list = BuildAList();
	int max_size = 100;
	srand(time(NULL));
	int count = 0;
	int data;
	while ( rand()%10!=0 && count<max_size )
	{
		++count;
		data = rand()%100;
		InsertAtFront( &list, data );
	}

	cout << "The list:\n";
	Display( list );

	int k;
	cout << "Enter k:\n";
	cin >> k;

	Node *result = findKthToTheLastNode( list, k );
	if ( result!=0 )
		cout << result->value << endl;
	    
    system("pause");
    return 0;
}