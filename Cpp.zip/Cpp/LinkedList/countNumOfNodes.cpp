/*
void ConvertToLoop( Node *head ):
Given a singly linked list with no loop, convert it to a loop.

void AppendAList( Node **head, Node *list2 ):
Given a singly linked list which contains no loop, append to it another 
singly linked list which may or may not contain a loop.

bool isCyclic( Node *head ):
Given a singly linked list, check if it contains a loop.

int NumOfNodes( Node *head ):
Given a singly linked list which may or may not contain a loop and 
the loop may or may not start from the head node, count the number 
of elements in the list.

void DisplayII( Node *head ):
Given a singly linked list which may or may not contain a loop and the loop
may or may not start from the head node, display all the values of the nodes.

Node *findStartOfLoop( Node *head ):
Given a singly linked list which may or may not contain a loop and 
the loop may or may not start from the head node, return the start 
node of the loop if there exists one.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
    int value;
    Node *next;
};

Node *BuildAList()
{
    Node *head = 0;
    return head;
}

bool InsertAtFront( Node **head, int data )
{
    Node *new_head = new Node;
    if ( !new_head )
        return false;
    
    new_head->value = data;
    new_head->next = *head;
    *head = new_head;
    return true;
}

// Given a singly linked list with no loop, display all the values of its nodes.
void Display( Node *head )
{
    while ( head!=0 )
    {
        cout << head->value << " ";
        head = head->next;
    }
    cout << endl;
}

// Given a singly linked list with no loop, convert it to a loop.
void ConvertToLoop( Node *head )
{
    if ( head==0 )
    {
        cout << "Empty list!\n";
        return;
    }
    
    Node *temp = head;
    while ( temp->next!=0 )
    {
        temp = temp->next;
    }
    temp->next = head;
}

/* 
Given a singly linked list which contains no loop, append to it another 
singly linked list which may or may not contain a loop.
*/
void AppendAList( Node **head, Node *list2 )
{
    if ( *head==0 )
    {
        *head = list2;
        return;
    }
    
    Node *temp = *head;
    while ( temp->next!=0 )
    {
        temp = temp->next;
    }
    temp->next = list2;
}

// Check if a list is cyclic.
bool isCyclic( Node *head )
{
	if ( head==0 )
		return 0;

	Node *first = head;
	Node *second = head;
	while ( true )
	{
		first = first->next;
		if ( first==0 )
			break;
		if ( first==second )
			return 1;
		first = first->next;
		if ( first==0 )
			break;
		if ( first==second )
			return 1;
		second = second->next;	
	}
	return 0;
}

/* 
Given a singly linked list which may or may not contain a loop and 
the loop may or may not start from the head node, count the number 
of elements in the list.

Version I:
Pseudo-code:
NumOfNodes( head )
1  count = 0
2  if there is no loop
3      p = head
4      while ( p!=0 )
5          ++count
6          p = p->next
7  else
8      first = head
9      second = head
10     // In the following, find a node inside the loop.
10     while ( true ) 
11         first = first->next
12         if first==second
13             break
14         first = first->next
15         if first== second
16             break
17         second = second->next
18     // In the following, find the number of nodes in the loop.
18     first = second->next
19     ++count
20     while ( first!=second )
21         ++count
22         first = first->next
23     n2 = count // number of nodes in the loop
24     // In the following, find the number of nodes in the non-loop if exists.
25     found = 0 // a flag indicating whether the start of the loop is found
26     first = head
27     n1 = 0 // number of nodes in the non-loop
28     while true
29         traverse the pointer second along the loop until it intersects with the pointer first or one cycle is reached
30         if first intersects with second 
31             found = 1
32             break
33         else if one cycle is reached
34             ++n1
35             first = first->next
36             count = n2
37     count = n1 + n2
38 return count

Time complexity: O(n1*n2) where n1 is the number of nodes in the 
non-loop and n2 is the number of nodes in the loop. n1 = 0 if the
loop starts from the head node. n2 = 0 if there is no loop.
*/
int NumOfNodes( Node *head )
{
	int count = 0;

	if ( !isCyclic( head ) ) // if no loop exists
	{
		Node *p = head;
		while ( p!=0 )
		{
			++count;
			p = p->next;
		}
	}
	else // if there exists a loop
	{
		// find a position inside the loop 
		Node *first = head;
		Node *second = head;
		while ( true )
		{
			first = first->next;
			if ( first==second )
				break;
			first = first->next;
			if ( first==second )
				break;
			second = second->next;
		}

		// find the number of nodes in the loop 
		first = second->next;
		++count;
		while ( first!=second )
		{
			first = first->next;
			++count;
		}
		int n2 = count; // number of nodes in the loop

		// find the number of nodes in the non-loop if it exists
		bool found = 0;
		first = head;
		int n1 = 0; // number of nodes in the non-loop, with the intersection of the loop and the non-loop excluded
		while ( true ) 
		{
			while ( count>0 )
			{
				if ( first==second )
				{
					found = 1;
					break;
				}
				second = second->next;
				--count;
			}
			if ( found )
			{
				break;
			}
			++n1;
			first = first->next;
			count = n2;
		}

		count = n1 + n2;
	}

	return count;
}

/* 
Given a singly linked list which may or may not contain a loop and the loop
may or may not start from the head node, display all the values of the nodes.
*/
void DisplayII( Node *head )
{
	if ( !isCyclic(head) )
	{
		while ( head!=0 )
		{
			cout << head->value << " ";
			head = head->next;
		}
		cout << endl;
	}
	else
	{
		int count = NumOfNodes( head );
		while ( count>0 )
		{
			cout << head->value << " ";
			head = head->next;
			--count;
		}
		cout << endl;
	}
}

/*
Given a singly linked list which may or may not contain a loop and 
the loop may or may not start from the head node, return the start 
node of the loop if there exists one.
*/
Node *findStartOfLoop( Node *head )
{
	if ( !isCyclic( head ) ) // if no loop exists
		return 0;
	
	// find a position inside the loop 
	Node *first = head;
	Node *second = head;
	while ( true )
	{
		first = first->next;
		if ( first==second )
			break;
		first = first->next;
		if ( first==second )
			break;
		second = second->next;
	}

	// find the number of nodes in the loop 
	first = second->next;
	int n2 = 1;
	while ( first!=second )
	{
		first = first->next;
		++n2;
	}

	// locate the start node of the loop
	first = head;
	int count = n2;
	while ( true ) 
	{
		while ( count>0 )
		{
			if ( first==second )
			{
				return first;
			}
			second = second->next;
			--count;
		}
		first = first->next;
		count = n2;
	}
}

int main()
{
	// illustration of BuildAList()
    Node *list1 = BuildAList();
    Node *list2 = BuildAList();
	Node *list3 = BuildAList();
    
	// Usually, the length of a linked list is not necessarily to 
	// be known in advance. The n here is for illustration.
    int n;
    cout << "Please enter number of nodes:\n";
    cin >> n;
	cout << endl;
    
	// illustration of InsertAtFront()
    srand(time(NULL));
    for ( int i=0; i<n; i++ )
    {
        InsertAtFront( &list1, rand()%100 );
        InsertAtFront( &list2, rand()%100 );
		InsertAtFront( &list3, rand()%100 );
    }
    
	// illustration of Display()
    cout << "list1:\n";
    Display( list1 );
    cout << "list2:\n";
    Display( list2 );
	cout << "list3:\n";
    Display( list3 );
	cout << endl;
    
	// illustration of ConvertToLoop()
    cout << "Convert list2 to a loop.\n";
    ConvertToLoop( list2 );
	cout << endl;

	// illustration of AppendAList()
	cout << "Append list2 to list1.\n";
	AppendAList( &list1, list2 );
	cout << endl;
    
	// illustration of isCyclic()
	bool isCycle1 = isCyclic( list1 );
	if ( isCycle1 )
		cout << "list1 is a cycle.\n";
	else
		cout << "list1 is not a cycle.\n";

	bool isCycle2 = isCyclic( list2 );
	if ( isCycle2 )
		cout << "list2 is a cycle.\n";
	else
		cout << "list2 is not a cycle.\n";

	bool isCycle3 = isCyclic( list3 );
	if ( isCycle3 )
		cout << "list3 is a cycle.\n";
	else
		cout << "list3 is not a cycle.\n";

	// illustration of NumOfNodes()
	int n1 = NumOfNodes( list1 );
	cout << "The number of nodes in list1: " << n1 << endl;

	int n2 = NumOfNodes( list2 );
	cout << "The number of nodes in list2: " << n2 << endl;

	int n3 = NumOfNodes( list3 );
	cout << "The number of nodes in list3: " << n3 << endl;

	// illustration of DisplayII()
    cout << "list1:\n";
    DisplayII( list1 );
    cout << "list2:\n";
    DisplayII( list2 );
	cout << "list3:\n";
    DisplayII( list3 );
	cout << endl;

	// ilustration of findStartOfLoop()
	Node *result = findStartOfLoop( list1 );
	if ( result==0 )
		cout << "No loop in list1.\n";
	else
		cout << "The loop in list1 starts from " << result->value << endl;

	Node *result2 = findStartOfLoop( list2 );
	if ( result2==0 )
		cout << "No loop in list2.\n";
	else
		cout << "The loop in list2 starts from " << result2->value << endl;

	Node *result3 = findStartOfLoop( list3 );
	if ( result3==0 )
		cout << "No loop in list3.\n";
	else
		cout << "The loop in list3 starts from " << result3->value << endl;

	system("pause");
    return 0;
}