/*
Given a linked list where each node has a value, a pointer to the 
following node and a pointer to a random node in the list, make a 
copy of the list and return the clone list.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
	Node *random;
};

Node *BuildAList( int &size )
{
	Node *head = 0;
	size = 0;
	return head;
}

bool InsertAtFront( Node **head, int data, int &size )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	++size; // size of the list increased by 1

	new_head->value = data;
	new_head->next = *head;
	new_head->random = 0;
	*head = new_head;

	//srand(time(NULL));
	int index = rand()%size;
	if ( rand()%2==0 )
	{
		Node *p = *head;
		while ( index>0 && p!=0 )
		{
			p = p->next;
			--index;
		}
		if ( p!=(*head) && p!=0 ) 
		{
			(*head)->random = p;
		}
		else
			(*head)->random = 0;
	}
	else
		(*head)->random = 0;

	return true;
}

void Display( Node *head )
{
	if ( head==0 )
	{
		cout << "Empty list.\n";
		return;
	}

	cout << "Node\t" << "Next\t" << "Random\n";
	while ( head!=0 )
	{
		cout << head->value << "\t";
		if ( head->next!=0 )
			cout << (head->next)->value << "\t";
		if ( head->random!=0 )
			cout << (head->random)->value << "\t";
		cout << endl;
		head = head->next;
	}
}

Node *CloneRandomLink( Node *head )
{
	if ( head==0 )
		return 0;

	if ( head->next==0 ) 
	{
		Node *list = new Node;
		list->value = head->value;
		list->next = head->next;
		list->random = head->random;
		return list;
	}

	// copy the list without the random link
	Node *p = head;
	Node *copy;
	while ( p!=0 )
	{
		copy = new Node;
		copy->value = p->value;
		copy->next = p->next;
		p->next = copy;
		p = copy->next;
	}

	// copy the random link
	p = head;
	while ( p!=0 )
	{
		if ( p->random!=0 )
			(p->next)->random = (p->random)->next;
		else
			(p->next)->random = 0;
		p = (p->next)->next;
	}

	// split the original list and the clone 
	Node *clone = head->next;
	p = head;
	Node *p2 = clone;
	while ( p->next!=0 && p2->next!=0 )
	{
		p->next = p2->next;
		p2->next = (p->next)->next;
		p = p->next;
		p2 = p2->next;
	}
	return clone;
}

int main()
{
	int size = 0;
	Node *list = BuildAList( size );

	int n;
	cout << "Please enter number of nodes:\n";
	cin >> n;

	srand(time(NULL));
	for ( int i=0; i<n; i++ )
		InsertAtFront( &list, rand()%100, size );

	cout << "The list:\n";
	Display( list );

	Node *clone_list = CloneRandomLink( list );

	cout << "The clone list:\n";
	Display( clone_list );

	system("pause");
	return 0;
}