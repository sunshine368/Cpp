// Given an array of numbers, find the number that is the nearest to zero. If two
// numbers are equally close to zero, return the positive number.

#include <iostream>
using namespace std;

int findClosestToZero( int *A, int n )
{
    int min = A[0];
    for ( int i=1; i<n; i++ )
    {
        if ( abs(min)>abs(A[i]) )
            min = A[i];
        else if ( abs(min)==abs(A[i]) && min<0 && A[i]>0 )
            min = A[i];
    }
    return min;
}

int main()
{
    const int n = 8;
    int A[n] = {5,3,7,6,8,-2,4,-3};
    int min = findClosestToZero( A, n );
    cout << min << endl;
    return 0;
}