// Given an array of integers which may contain duplicates, determine if it is
// a continuous sequence.

#include <iostream>
using namespace std;

bool isContSub( int *A, int n )
{
    int min = A[0];
    int max = A[0];
    for ( int i=1; i<n; i++ )
    {
        if ( A[i]>max )
            max = A[i];
        else if ( A[i]<min )
            min = A[i];
    }
    
    if ( (max-min)!=(n-1) )
        return false;
    
    for ( int i=0; i<n; i++ )
    {
        if ( (A[i]-min) != i )
        {
            if ( A[A[i]-min] == A[i] )
                return false;
            else
            {
                swap( A[i], A[A[i]-min] );
            }
        }
    }
    
    return true;
}

int main()
{
    const int n = 6;
    int A[n] = {45,50,47,46,49,48};
    bool isCont = isContSub( A, n );
    cout << isCont << endl;
    return 0;
}