// Given an array, find out the maximum j-i such that A[j]>A[i] in O(n) time.

#include <iostream>
using namespace std;

void findMaxPair( int *A, int n )
{
    int *min = (int*)malloc( sizeof(int)*n );
    min[0] = A[0];
    for ( int i=1; i<n; i++ )
    {
        if ( min[i-1]>A[i] )
            min[i] = A[i];
        else
            min[i] = min[i-1];
    }
    
    int *max = (int*)malloc( sizeof(int)*n );
    max[n-1] = A[n-1];
    for ( int i=n-2; i>=0; i-- )
    {
        if ( max[i+1]<A[i] )
            max[i] = A[i];
        else
            max[i] = max[i+1];
    }
    
    int first = 0, second = 0, max_first = 0, max_second = 0, max_length = 0;
    while ( second<n )
    {
        while ( min[first]<max[second] && second<n )
        {
            second++;
        }
        second--;
        if ( max_length<second-first )
        {
            max_length = second - first;
            max_first = first;
            max_second = second;
        }
        first++;
        second++;
    }
    
    cout << "The maximum j-i is " << max_second << " - " << max_first << " = " << max_length << endl;
}

int main()
{
    const int n = 8;
    int A[n] = {20,30,2,11,12,10,1,25};
    findMaxPair( A, n );
    int A2[n] = {20,30,2,11,12,10,1,4};
    findMaxPair( A2, n );
    const int n2 = 10;
    int A3[n2] = {10,2,7,9,0,3,1,1,1,1};
    findMaxPair( A3, n2 );
    return 0;
}