// Given a sorted array with no duplicates, find all triplets (a,b,c) such that
// a - b = c. Time complexity: O(n^2).
// For example, given {-12,-7,-4,0,3,5,9,10,15,16}, the output should be
// 15 - 5 = 10
// 15 - 10 = 5
// 9 - (-7) = 16
// 9 - 16 = -7
// 5 - (-4) = 9
// 5 - 9 = -4
// 3 - (-12) = 15
// 3 - (-7) = 10
// 3 - 10 = -7
// 3 - 15 = -12
// -4 - (-7) = 3
// -4 - 3 = -7
// -7 - (-12) = 5
// -7 - 5 = -12

#include <iostream>
using namespace std;

void findTriplets( int *A, int n )
{
    int *temp = (int*)malloc( sizeof(int)*n );    
    int sum;
    for ( int i=n-1; i>=0; i-- )
    {
        sum = A[i];
        int pt = 0;
        while (pt<n )
        {
            if ( pt==i )
                temp[pt++] = 0;
            else
            {
                temp[pt] = sum - A[pt];
                pt++;
            }
        }
        
        pt = n-1;
        int pa = 0;
        while ( pa<n && pt>=0 )
        {
            if ( pa==i )
                pa++;
            
            if ( A[pa]==temp[pt] )
            {
                if ( pt!=i && A[pa]!=(sum-A[pa]) )
                {
                    cout << sum << " - " << A[pa] << " = " << sum-A[pa] << endl;
                }
                pa++;
                pt--;
            }
            else if ( A[pa]>temp[pt] )
                pt--;
            else
                pa++;
        }
    }
}

int main()
{
    const int n = 10;
    int A[n] = {-12,-7,-4,0,3,5,9,10,15,16};
    findTriplets( A, n );
    return 0;
}