// Given a 10 digit mobile number, with each number correponding to 3 or 4 letters in the keypad,
// print all words which can be created by replacing each number with a letter. 3^10 total.
// http://www.careercup.com/page?pid=arrays-interview-questions&n=2

#include <iostream>
using namespace std;


void phoneNumToWordAux( char *A, int n, int cur )
{

}

void phoneNumToWord( char *A, int n )
{
	phoneNumToWordAux( A, n, 0 );
}

int main()
{


	system("pause");
	return 0;
}