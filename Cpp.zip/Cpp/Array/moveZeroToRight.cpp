// Move all 0's of a given array to the end and keep the original order of the other elements.
// For example, given {1,2,0,4,0,0,8}, the output should be {1,2,4,8,0,0,0}.

#include <iostream>
using namespace std;

const int n = 7;

void moveZeroToRight( int A[n] )
{
	int pos = 0;
	for ( int i=0; i<n; i++ )
	{
		if ( A[i]!=0 )
		{
			A[pos] = A[i];
			pos++;
		}
	}
	while ( pos<n )
	{
		A[pos] = 0;
		pos++;
	}
}

int main()
{
	int A[n] = {1,2,0,4,0,0,8};
	moveZeroToRight( A );
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}