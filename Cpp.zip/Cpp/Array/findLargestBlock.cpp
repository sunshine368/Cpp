/* Given a two-dimensional array of 1's and 0's, find the size of the largest block of 0's.
For example, given the 2D array
1,0,1,0,0,0,1,0
1,0,0,0,0,0,1,1
1,1,1,0,0,0,1,1
the largest block of 0's is the 3-by-3 block starting at (0,3).
*/ 

#include <iostream>
using namespace std;

const int m = 3, n = 8;

void findLargestBlock( int A[m][n], int row, int col )
{
	int **R = (int**)malloc( sizeof(int*) * (row+1) );
	int **C = (int**)malloc( sizeof(int*) * (row+1) );
	for ( int i=0; i<row+1; i++ )
	{
		R[i] = (int*)malloc( sizeof(int) * (col+1) );
		C[i] = (int*)malloc( sizeof(int) * (col+1) );
		for ( int j=0; j<col+1; j++ )
		{
			R[i][j] = 0;
			C[i][j] = 0;
		}
	}

	for ( int i=0; i<row; i++ )
	{
		for ( int j=col-1; j>=0; j-- )
		{
			if ( A[i][j]==0 )
			{
				R[i][j] = R[i][j+1] + 1;
			}
		}
	}

	for ( int j=0; j<col; j++ )
	{
		for ( int i=row-1; i>=0; i-- )
		{
            int k = i;
            int key = R[i][j];
            C[i][j] = 1;
			while( k<row-1 )
            {
                k++;
                if ( R[k][j]<key )
                {
                    break;
                }
                else
                {
                    C[i][j]++;
                }
            }
            k = i;
            while ( k>0 )
            {
                k--;
                if ( R[k][j]<key )
                {
                    break;
                }
                else
                {
                    C[i][j]++;
                }
            }
		}
	}

    int maxarea = 0;
    int area = 0;
    int maxrow = 0;
    int maxcol = 0;
    for ( int i=0; i<row; i++ )
    {
        for ( int j=0; j<col; j++ )
        {
            area = R[i][j] * C[i][j];
            if ( area > maxarea )
            {
                maxarea = area;
                maxrow = i;
                maxcol = j;
            }
        }
    }
    
    cout << "The largest block of 0's is at (" << maxrow << ", " << maxcol << ") of size " << C[maxrow][maxcol] << " by " << R[maxrow][maxcol] << "." << endl;
}

int main()
{
	int A[m][n] = {{1,0,1,0,0,0,1,0},{1,0,0,0,0,0,1,1},{1,1,1,0,0,1,1,1}};
    findLargestBlock( A, m, n );

	system("pause");
	return 0;
}