// Copy the contents of an array A to another array B of equal length without using loops
// and any standard string copy functions.

#include <iostream>
using namespace std;

void copyArrayRecurAux( char *A, char *B, int n, int copy_from, int copy_to )
{
	if ( A[copy_from]=='\0' )
	{
		B[copy_to] = '\0';
		return;
	}
	B[copy_to] = A[copy_from];
	copyArrayRecurAux( A, B, n, copy_from+1, copy_to+1 );
}

void copyArrayRecur( char *A, char *B, int n )
{
	copyArrayRecurAux( A, B, n, 0, 0 );
}

int main()
{
	char A[] = "abcd1234";
	int n = strlen(A);

	cout << "strlen(A) = " << n << endl;

	char *B = (char*)malloc( sizeof(char)*(n+1) );
	copyArrayRecur( A, B, n );

	for ( int i=0; i<n; i++ )
		cout << B[i] << endl;

	cout << B << endl;

	system("pause");
	return 0;
}