// Given a sequence of numbers, find the largest subsequence which is a zigzag.
// A sequence is a zigzag sequence if the differences between successive numbers
// strictly alternate between positive and negative.
// For example, given {1,2,7,3,4,5}, the largest zigzag subsequence is {1,7,5}, {1,7,3}, or {1,7,4}.

#include <iostream>
using namespace std;

void LongestZigZagSub( int *A, int n )
{
    int *B = (int*)malloc( sizeof(int)*n );
    for ( int i=0; i<n-1; i++ )
    {
        B[i] = (A[i+1]>A[i] ? 1 : 0);
    }
    if ( B[n-3]==0 && B[n-2]==1 )
    {
        B[n-1] = 0;
    }
    else if ( B[n-3]==1 && B[n-2]==0 )
    {
        B[n-1] = 1;
    }
    else if ( B[n-3]==1 && B[n-2]==1 )
    {
        B[n-1] = 0;
    }
    else
    {
        B[n-1] = 1;
    }
    
    int temp = B[0];
    int i = 0;
    cout << A[0] << endl;
    while ( i<n )
    {
        while ( B[i]==temp && i<n )
        {
            i++;
            if ( i==n )
                return;
        }

        cout << A[i] << endl;
        temp = B[i];
    }
}

int main()
{
    const int n = 6;
    int A[n] = {1,2,7,3,4,5};
    LongestZigZagSub( A, n );
    return 0;
}