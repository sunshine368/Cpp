// Given n sorted arrays of equal length m, merge these arrays to a sorted array
// in place, i.e., no extra space allowed except the given arrays.

#include <iostream>
using namespace std;

void swap( int *a, int *b )
{
	(*a) += (*b);
	(*b) = (*a) - (*b);
	(*a) -= (*b);
}

void sortAnArrayInPlace( int *A, int m )
{
	for ( int i=0; i<m-1; i++ )
	{
		for ( int j=0; j<m-1-i; j++ )
		{
			if ( A[j] > A[j+1] )
				swap( &A[j], &A[j+1] );
		}
	}
}

void sortNSortedArraysInPlace( int **A, int m, int n )
{
	for ( int i=0; i<n-1; i++ ) // compare the elements of an array to those of the previous array
	{
		for ( int j=0; j<m; j++ ) // go through all the elements in an array; compare an element with each of the m elements before it one by one, swap the two if in reverse order
		{
			int k = (i+1)*m + j; 
			int r = k-1;
			while ( (A[k/m][k%m] < A[r/m][r%m]) && r>=0 )
			{
				swap( &A[k/m][k%m], &A[r/m][r%m] );
				k--;
				r = k-1;
			}
		}
	}
}

int main()
{
	int m = 6;
	int n = 4;
	int **A = (int**)malloc( sizeof(int*) * n );
	for ( int i=0; i<n; i++ )
	{
		A[i] = (int*)malloc( sizeof(int) * m );
		for ( int j=0; j<m; j++ )
		{
			A[i][j] = rand()%( m*n );
		}
	}

	cout << "The original arrays:\n";
	for ( int i=0; i<n; i++ )
	{
		for ( int j=0; j<m; j++ )
			cout << A[i][j] << " ";
		cout << endl;
	}

	cout << "\nAfter sorting each array:\n";
	for ( int i=0; i<n; i++ )
	{
		sortAnArrayInPlace( A[i], m );
		for ( int j=0; j<m; j++ )
			cout << A[i][j] << " ";
		cout << endl;
	}

	cout << "\nAfter sorting all arrays:\n";
	sortNSortedArraysInPlace( A, m, n );
	for ( int i=0; i<n; i++ )
	{
		for ( int j=0; j<m; j++ )
		{
			cout << A[i][j] << " ";
		}
		cout << endl;
	}

	system("pause");
	return 0;
}