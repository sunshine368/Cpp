// Given two arrays, A and B, where A has unsorted integers, B has the same number
// of elements as A, and all elements of B are in the set {-1,0,1}, return an array
// C with the following constraint:
// (1). If B[i]=0, then C[i] = A[i];
// (2). If B[i]=-1, then A[i] must be in the left subarray C[0]...C[i-1];
// (3). If B[i]=1, then A[i] must be in the right subarray C[i+1]...C[n-1].

#include <iostream>
using namespace std;

void copyArray( int *A, int *B, int *C, int n )
{
    int index = 0;
    int pos = 0;
    int neg = 0;
    while ( index<n )
    {
        while ( B[index]==0 || B[index]==2 )
        {
            if ( B[index]==0 )
                C[index] = A[index];
            index++;
            if ( index>=n )
                return;
        }
        if ( B[index]==-1 )
        {
            cout << "No solution!" << endl;
            return;
        }
        else
        {
            pos = index;
            neg = pos + 1;
            while ( B[neg]!=-1 )
            {
                neg++;
                if ( neg>=n )
                {
                    cout << "No solution!" << endl;
                    return;
                }
            }
            C[pos] = A[neg];
            C[neg] = A[pos];
            B[pos] = 2;
            B[neg] = 2;
        }
    }
}

int main()
{
    const int n = 8;
    int A[n] = {1,2,3,4,5,6,7,8};
    int B[n] = {1,0,1,-1,-1,0,0,0};
    int C[n] = {0};
    copyArray( A, B, C, n );
    for ( int i=0; i<n; i++ )
        cout << C[i] << " ";
    cout << endl;
    return 0;
}