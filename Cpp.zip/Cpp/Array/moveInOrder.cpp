// Given an array of integers, move all negative numbers to the rightmost while 
// keeping the original order. 
// For example, given the array {3,-1,-2,2,2,3,2,-6,2,3,-8,0,2}, the output
// should be {3,2,2,3,2,2,3,0,2,-1,-2,-6,-8}.

#include <iostream>
using namespace std;

void reverse( int *A, int i, int j ) // reverse A[i],...,A[j]
{
	int first = i;
	int second = j;
	while ( first < second )
	{
		A[first] += A[second];
		A[second] = A[first] - A[second];
		A[first] -= A[second];
		first++;
		second--;
	}
}

void rightRotate( int *A, int i, int j, int k ) // right rotate A[i],...,A[j] by k positions
{
	reverse( A, i, j-k );
	reverse( A, j-k+1, j );
	reverse( A, i, j );
}

void moveInOrder( int *A, int n )
{
	int neg = 0;
	int pos = 0;
	int nextneg = 0;
	int i = 0;
	while ( i<n )
	{
		while ( A[i] >= 0 && i<n )
		{
			i++;
		}
		neg = i; // the first of a sequence of negative numbers in a row

		while ( A[i] < 0 && i<n )
		{
			i++;
		}
		pos = i; // the first of a sequence of positive numbers in a row

		while ( A[i] >= 0 && i<n )
		{
			i++;
		}
		nextneg = i; // after the last of a sequence of positive numbers in a row

		int negnum = pos - neg;
		int posnum = nextneg - pos;
		if ( posnum == 0 || negnum == 0 )
		{
			return;
		}
		else 
		{
			rightRotate( A, neg, nextneg-1, posnum ); // shift the positive numbers left and shift the negative numbers right
			i = neg + posnum; // move to the first of the sequence of negative numbers in a row
		}
	}
}

int main()
{
	const int n = 13;
	int A[n] = {3,-1,-2,2,2,3,2,-6,2,3,-8,0,2};
	moveInOrder( A, n );

	for ( int i=0; i<n; i++ )
		cout << A[i] << endl;

	system("pause");
	return 0;
}