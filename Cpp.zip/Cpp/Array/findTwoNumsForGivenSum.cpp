// Given an array of integers, find two numbers whose sum equals to a given number.

#include <iostream>
using namespace std;

// sort the array first, time complexity: O(nlog(n)), space complexity: O(n)
void merge( int *A, int n, int first, int last, int *temp )
{
	int i = first;
	int left = first;
	int mid = (first+last)/2;
	int right = mid + 1;
    
	while ( left<=mid && right<=last )
	{
		if ( A[left]<=A[right] )
			temp[i++] = A[left++];
		else
			temp[i++] = A[right++];
	}
    
	if ( left==mid+1 )
	{
		while ( right<=last )
			temp[i++] = A[right++];
	}
	else
	{
		while ( left<=mid )
			temp[i++] = A[left++];
	}
    
	for ( int i=first; i<=last; i++ )
		A[i] = temp[i];
}

void mergeSortAux( int *A, int n, int first, int last, int *temp )
{
	if ( first==last )
		return;
	int mid = (first+last)/2;
	mergeSortAux( A, n, first, mid, temp );
	mergeSortAux( A, n, mid+1, last, temp );
	merge( A, n, first, last, temp );
}

void mergeSort( int *A, int n )
{
	int *temp = (int*)malloc( sizeof(int)*n );
	mergeSortAux( A, n, 0, n-1, temp );
}

bool findTwoNumsGivenSum( int *A, int n, int sum )
{
    mergeSort( A, n );
    int first = 0;
    int second = n-1;
    bool found = 0;
    while ( first<second )
    {
        if ( A[first]+A[second]==sum )
        {
            cout << "A[" << first << "] + A[" << second << "] = " << A[first] << " + " << A[second] << " = " << sum << endl;
            found = 1;
            first++;
            second = n-1;
        }
        else if ( A[first]+A[second]>sum )
            second--;
        else
            first++;
    }
    return found;
}

// brute force method, time complexity: O(n^2)
bool findTwoNumsGivenSum2( int *A, int n, int sum )
{
    bool found = 0;
    for ( int i=0; i<n-1; i++ )
    {
        for ( int j=i+1; j<n; j++ )
        {
            if ( A[j]==sum-A[i] )
            {
                cout << "A[" << i << "] + A[" << j << "] = " << A[i] << " + " << A[j] << " = " << sum << endl;
                found = 1;
            }
        }
    }
    return found;
}

// hashing method, time complexity: O(n), space complexity: O(range of A[])
bool findTwoNumsGivenSum3( int *A, int n, int sum )
{
    int max = A[0];
    int min = A[0];
    for ( int i=0; i<n; i++ )
    {
        if ( A[i]>max )
            max = A[i];
        else if ( A[i]<min )
            min = A[i];
    }
    
    int *hashtable = (int*)malloc( sizeof(int)*(max-min+1) );
    for ( int i=0; i<max-min+1; i++ )
    {
        hashtable[i] = 0;
    }
    
    for ( int i=0; i<n; i++ )
    {
        hashtable[A[i]-min] = 1;
    }
    
    int temp;
    bool found = 0;
    for ( int i=0; i<n; i++ )
    {
        temp = sum - A[i];
        if ( temp>=min && temp<=max )
        {
            if ( hashtable[temp-min]==1 )
            {
                cout << temp << " + " << sum-temp << " = " << sum << endl;
                hashtable[temp-min]--;
                hashtable[sum-temp-min]--;
                found = 1;
            }
        }
    }
    
    return found;
}

int main()
{
    const int n = 8;
    int A[n] = {15,2,11,-3,4,-5,6,7};
    int sum = 10;
    
    bool found1 = findTwoNumsGivenSum( A, n, sum );
    cout << found1 << endl;
    
    bool found2 = findTwoNumsGivenSum2( A, n, sum );
    cout << found2 << endl;
    
    bool found3 = findTwoNumsGivenSum3( A, n, sum );
    cout << found3 << endl;
    
    return 0;
}