// Given an array containing 0 or 1, sort this array such that all 0's appear before all 1's.
// The constraint is that you can swap only the adjacent elements in the array. 
// Find the minimum number of swaps required to sort the given array.

#include <iostream>
using namespace std;

int minSwapZeroOne( int *A, int n )
{
	int swap = 0, count = 0;
	for ( int i=n; i>=1; i-- )
	{
		if ( A[i] == 0 )
			count++;
		else
			swap += count;
	}
	return swap;
}

int main()
{
	const int n1 = 8;
	int A1[n1] = {0,0,1,0,1,0,1,1};
	cout << minSwapZeroOne( A1, n1 ) << endl;

	const int n2 = 6;
	int A2[n2] = {1,1,1,0,0,0};
	cout << minSwapZeroOne( A2, n2 ) << endl;


	system("pause");
	return 0;
}