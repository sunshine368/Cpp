// Given an array, determine if there exists a contiguous subsequence such that the sum is zero.

#include <iostream>
using namespace std;

// Time complexity: O(n), space complexity: O(range of sum[])
bool existZeroSumSub( int *A, int n )
{
    if ( A[0]==0 )
    {
        cout << "A[0]" << endl;
        return 1;
    }
    
    int *sum = (int*)malloc( sizeof(int)*n );
    sum[0] = A[0];
    for ( int i=1; i<n; i++ )
    {
        sum[i] = sum[i-1] + A[i];
        if ( sum[i]==0 )
        {
            cout << "A[0]...A[" << i << "]" << endl;
            return 1;
        }
    }
    
    int max = A[0];
    int min = A[0];
    for ( int i=1; i<n; i++ )
    {
        if ( sum[i]>max )
            max = sum[i];
        else if ( sum[i]<min )
            min = sum[i];
    }
    
    int *hashtable = (int*)malloc( sizeof(int)*(max-min+1) );
    for ( int i=0; i<=max+min; i++ )
    {
        hashtable[i] = 0;
    }
    
    // find duplicate elements in sum[]
    for ( int i=0; i<n; i++ )
    {
        hashtable[sum[i]-min]++;
        if ( hashtable[sum[i]-min]>1 )
        {
            // find the subarray
            int first = -1, second = -1;
            for ( int j=0; j<n; j++ )
            {
                if ( sum[j]==sum[i] )
                {
                    if ( first==-1 )
                        first = j+1;
                    else
                        second = j;
                }
            }
            cout << "A[" << first << "]...A[" << second << "]" << endl;
            return 1;
        }
    }
    
    return 0;
}

int main()
{
    const int n = 4;
    int A[n] = {-4,1,2,3};
    bool found = existZeroSumSub( A, n );
    cout << found << endl;
    
    const int n2 = 7;
    int A2[n2] = {2,-1,3,-4,1,2,3};
    bool found2 = existZeroSumSub( A2, n2 );
    cout << found2 << endl;

    const int n3 = 6;
    int A3[n3] = {2,-1,3,-5,2,2};
    bool found3 = existZeroSumSub( A3, n3 );
    cout << found3 << endl;
    
    return 0;
}