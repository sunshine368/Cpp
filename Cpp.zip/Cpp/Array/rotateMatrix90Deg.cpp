// Given a matrix, rotate it by 90 degrees clockwise.

#include <iostream>
using namespace std;

const int row = 4, col = 4;

void swap( int &a, int &b )
{
	if ( a==b )
		return;
	a += b;
	b = a - b;
	a -= b;
}

void transpose( int A[][col] ) 
{
	for ( int i=0; i<row; i++ )
	{
		for ( int j=i; j<col; j++ )
		{
			swap( A[i][j], A[j][i] );
		}
	}
}

void reverseRow( int A[][col], int m )
{
	for ( int j=0; j<col/2; j++ )
	{
		swap( A[m][j], A[m][col-1-j] );
	}
}

void rotateMatrix90Deg( int A[][col] )
{
	transpose( A );
	for ( int i=0; i<row; i++ )
	{
		reverseRow( A, i );
	}
}

int main()
{
	int A[row][col] = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
	cout << "Before rotation:\n";
	for ( int i=0; i<row; i++ )
	{
		for ( int j=0; j<col; j++ )
			cout << A[i][j] << ", ";
		cout << endl;
	}
	rotateMatrix90Deg( A );
	cout << "After rotation:\n";
	for ( int i=0; i<row; i++ )
	{
		for ( int j=0; j<col; j++ )
			cout << A[i][j] << ", ";
		cout << endl;
	}

	system("pause");
	return 0;
}