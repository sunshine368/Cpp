// Given two arrays, A and B, find the smallest window in A that contains all the elements of B.
// http://www.careercup.com/question?id=2456709