// Remove duplicates in an array.

#include <iostream>
#include <cstdlib>
using namespace std;

// Time complexity: O(n), space complexity: O(range of A[])
void removeDuplicates( int *A, int n )
{
    int max = A[0];
    for ( int i=0; i<n; i++ )
    {
        if ( A[i] > max )
        {
            max = A[i];
        }
    }
    
    int *hashtable = (int*)malloc( sizeof(int)*(max+1) );
    for ( int i=0; i<=max; i++ )
    {
        hashtable[i] = 0;
    }
    
    int *temp = (int*)malloc( sizeof(int)*n );
    int pos = 0;
    for ( int i=0; i<n; i++ )
    {
        hashtable[A[i]]++;
        if ( hashtable[A[i]]==1 )
        {
            temp[pos++] = A[i];
        }
    }
    
    for ( int i=0; i<pos; i++ )
        cout << temp[i] << endl;
}

int main()
{
    const int n = 8;
    int A[n] = {1,3,3,3,3,5,5,6};
    removeDuplicates( A, n );

    return 0;
}