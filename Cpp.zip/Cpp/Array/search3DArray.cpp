// Search an element in a 1D/2D/3D sorted array without modifying the original array.
// Time complexity: O(log(n))

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void merge( int *A, int n, int first, int last, int *temp )
{
    if ( first==last )
        return;
    int mid = (first+last)/2;
    int left = first;
    int right = mid+1;
    int i = first;
    while ( left<=mid && right<=last )
    {
        if ( A[left]<=A[right] )
        {
            temp[i++] = A[left++];
        }
        else{
            temp[i++] = A[right++];
        }
    }
    
    if ( left==mid+1 )
    {
        while ( right<=last )
        {
            temp[i++] = A[right++];
        }
    }
    else if ( right==last+1 )
    {
        while ( left<=mid )
        {
            temp[i++] = A[left++];
        }
    }
    
    for ( int i=first; i<=last; i++ )
    {
        A[i] = temp[i];
    }
}

void mergeSortAux( int *A, int n, int first, int last, int *temp )
{
    if ( first==last )
        return;
    int mid = (first+last)/2;
    mergeSortAux( A, n, first, mid, temp );
    mergeSortAux( A, n, mid+1, last, temp );
    merge( A, n, first, last, temp );
}

void mergeSort( int *A, int n )
{
    int *temp = (int*)malloc( sizeof(int)*n );
    mergeSortAux( A, n, 0, n-1, temp );
}


// search a key in a 1D array
int binarySearch( int *A, int n, int key, int first, int last )
{
    if ( first==last )
    {
        if ( A[first]==key )
            return first;
        else
            return -1;
    }
    
    int mid = (first+last)/2;
    if ( A[mid]==key )
    {
        return mid;
    }
    else if ( A[mid]>key )
    {
        return binarySearch( A, n, key, first, mid );
    }
    else
    {
        return binarySearch( A, n, key, mid+1, last );
    }
}

int search1DArray( int *A, int n, int key )
{
    return binarySearch( A, n, key, 0, n-1 );
}


// search a key in a 2D array, with all rows and columns sorted in increasing order

int binarySearch2D( int **A, int n1, int n2, int key, int x1, int y1, int x2, int y2 )
{
    if ( x1==x2 && y1==y2 )
    {
        if ( A[x1][y1]==key )
        {
            cout << key << " found at index (" << x1 << ", " << y1 << ")" << endl;
            return 1;
        }
        else{
            return 0;
        }
    }
    else if ( x1==x2 )
    {
        int mid = (y1+y2)/2;
        if ( A[x1][mid]==key )
        {
            cout << key << " found at (" << x1 << ", " << mid << ")" << endl;
            return 1;
        }
        else if ( A[x1][mid]>key )
        {
            return binarySearch2D( A, n1, n2, key, x1, y1, x1, mid );
        }
        else{
            return binarySearch2D( A, n1, n2, key, x1, mid+1, x1, y2 );
        }
    }
    else
    {
        int mid2 = (x1+x2)/2;
        if ( mid2==0 && A[0][n2-1]>=key )
            return binarySearch2D( A, n1, n2, key, 0, y1, 0, y2 );
        else
        {
            if ( A[mid2-1][n2-1]<key && A[mid2][n2-1]>=key )
            {
                return binarySearch2D( A, n1, n2, key, mid2, y1, mid2, y2 );
            }
            else if ( A[mid2-1][n2-1]>=key )
            {
                return binarySearch2D( A, n1, n2, key, x1, y1, mid2, y2 );
            }
            else
            {
                return binarySearch2D( A, n1, n2, key, mid2+1, y1, x2, y2 );
            }
        }
    }
}

int search2DArray( int **A, int n1, int n2, int key )
{
    if ( A[0][0]>key || A[n1-1][n2-1]<key )
        return 0;
    else
        return binarySearch2D( A, n1, n2, key, 0, 0, n1-1, n2-1 );
}


// search in a 3D array
int binarySearch3D( int ***A, int n1, int n2, int n3, int key, int x1, int y1, int z1, int x2, int y2, int z2 )
{
    if ( x1==x2 && y1==y2 && z1==z2 )
    {
        if ( A[z1][x1][y1]==key )
        {
            cout << key << " found at (" << x1 << ", " << y1 << ") of Matrix " << z1 << endl;
            return 1;
        }
        else{
            return 0;
        }
    }
    else if ( x1==x2 && z1==z2 ) // determine the column to which the key belongs
    {
        int mid = (y1+y2)/2;
        if ( A[z1][x1][mid]==key )
        {
            cout << key << " found at (" << x1 << ", " << mid << ") of Matrix " << z1 << endl;
            return 1;
        }
        else if ( A[z1][x1][mid]>key )
        {
            return binarySearch3D( A, n1, n2, n3, key, x1, y1, z1, x1, mid, z1 );
        }
        else
        {
            return binarySearch3D( A, n1, n2, n3, key, x1, mid+1, z1, x1, y2, z1 );
        }
    }
    else if ( z1==z2 ) // determine the row of the matrix to which the key belongs
    {
        int mid2 = (x1+x2)/2;
        if ( A[z1][0][n2-1]>=key )
        {
            return binarySearch3D( A, n1, n2, n3, key, 0, y1, z1, 0, y2, z1 );
        }
        else
        {
            if ( A[z1][mid2-1][n2-1]<key && A[z1][mid2][n2-1]>=key )
                return binarySearch3D( A, n1, n2, n3, key, mid2, y1, z1, mid2, y2, z1 );
            else if ( A[z1][mid2-1][n2-1]>=key )
                return binarySearch3D( A, n1, n2, n3, key, x1, y1, z1, mid2, y2, z1 );
            else
                return binarySearch3D( A, n1, n2, n3, key, mid2+1, y1, z1, x2, y2, z1 );
        }
    }
    else // determine the matrix which the key belongs to
    {
        int mid3 = (z1+z2)/2;
        if ( A[0][n1-1][n2-1]>=key && mid3==0 )
            return binarySearch3D( A, n1, n2, n3, key, x1, y1, 0, x2, y2, 0 );
        else
        {
            if ( A[mid3-1][n1-1][n2-1]<key && A[mid3][n1-1][n2-1]>=key )
                return binarySearch3D( A, n1, n2, n3, key, x1, y1, mid3, x2, y2, mid3 );
            else if ( A[mid3][n1-1][n2-1]<key )
                return binarySearch3D( A, n1, n2, n3, key, x1, y1, mid3+1, x2, y2, z2 );
            else
                return binarySearch3D( A, n1, n2, n3, key, x1, y1, z1, x2, y2, mid3 );
        }
    }
}


int search3DArray( int ***A, int n1, int n2, int n3, int key ) // A[i][j][k]: element (j,k) of the ith matrix; n1: # of rows; n2: # of columns; n3: # of matrices
{
    if ( A[0][0][0]>key || A[n3-1][n1-1][n2-1]<key ) // out of range
        return 0;
    else
        return binarySearch3D( A, n1, n2, n3, key, 0, 0, 0, n1-1, n2-1, n3-1 );
}


int main()
{
    srand( time(NULL) );
    
    // search in 1D array
    // generate a 1D array of n elements and sort it in increasing order
    int n = 8;
    int *A = (int*)malloc( sizeof(int)*n );
    for ( int i=0; i<n; i++ )
    {
        A[i] = rand()%100;
    }
    mergeSort( A, n );
    
    // display the 1D array
    cout << "The sorted 1D array:\n";
    for ( int i=0; i<n; i++ )
        cout << A[i] << " ";
    cout << endl;
    
    // search the 1D array
    int key = 58;
    int found = search1DArray( A, n, key );
    if ( found==-1 )
        cout << "Not found!\n";
    else
        cout << key << " found at index: " << found << endl;
    
    
    // search in 2D array
    // generate a 1D array of n1*n2 elements and sort it in increasing order
    int n1 = 4, n2 = 4;
    int *temp = (int*)malloc( sizeof(int)*n1*n2 );
    for ( int i=0; i<n1*n2; i++ )
    {
        temp[i] = rand()%100;
    }
    mergeSort( temp, n1*n2 );
    
    // put the 1D array to a 2D array, keeping the original order
    int **AA = (int**)malloc( sizeof(int*)*n1 );
    for ( int i=0; i<n1; i++ )
    {
        AA[i] = (int*)malloc( sizeof(int)*n2 );
        for ( int j=0; j<n2; j++ )
        {
            AA[i][j] = temp[i*n2+j];
        }
    }
    
    // display the 2D array
    cout << "The sorted 2D array:\n";
    for ( int i=0; i<n1; i++ )
    {
        for ( int j=0; j<n2; j++ )
        {
            cout << AA[i][j] << " ";
        }
        cout << endl;
    }
    
    // search the 2D array
    int key2 = 58;
    int found2 = search2DArray( AA, n1, n2, key2 );
    if ( !found2 )
        cout << "Not found!" << endl;
    
    // search in 3D array
    const int n3 = 3, n4 = 3, n5 = 3;
    int *temp3 = (int*)malloc( sizeof(int)*n3*n4*n5 );
    for ( int i=0; i<n3*n4*n5; i++ )
    {
        temp3[i] = rand()%100;
    }
    mergeSort( temp3, n3*n4*n5 );
    
    int ***AAA = (int***)malloc( sizeof(int**)*n5 );
    for ( int i=0; i<n5; i++ )
    {
        AAA[i] = (int**)malloc( sizeof(int*)*n3 );
        for ( int j=0; j<n3; j++ )
        {
            AAA[i][j] = (int*)malloc( sizeof(int)*n4 );
            for ( int k=0; k<n4; k++ )
                AAA[i][j][k] = temp3[i*n3*n4+n4*j+k];
        }
    }
    
    // display the 3D array
    cout << "The 3D array:\n";
    for ( int i=0; i<n5; i++ )
    {
        cout << "The " << i+1 << "th matrix:\n";
        for ( int j=0; j<n3; j++ )
        {
            for ( int k=0; k<n4; k++ )
                cout << AAA[i][j][k] << " ";
            cout << endl;
        }
    }
    
    int key3 = 18;
    int found3 = search3DArray( AAA, n3, n4, n5, key3 );
    if ( !found3 )
        cout << "Not found!" << endl;
    
    return 0;
}