// Given the contents of a book as a single text file, find the top 3 frequently used
// words in the book.
// http://www.careercup.com/question?id=12391700
// Use trie.
