// Given an array of integers where all but one repeat an even number of times, find the number which
// appears only once or repeats an odd number of times.

#include <iostream>
using namespace std;

int findOddRepeating( int *A, int n )
{
    int result = 0;
    for ( int i=0; i<n; i++ )
        result ^= A[i];
    return result;
}

int main()
{
    const int n = 7;
    int A[n] = {1,1,2,2,3,3,3};
    int odd = findOddRepeating( A, n );
    cout << odd << endl;
    return 0;
}