// Given a sorted but rotated array, find the pivot.

#include <iostream>
using namespace std;

int findPivotInRotatedArray( int *A, int n )
{
	int first = 0;
	int second = n-1;
	int mid = (first + second)/2;

	while ( first<mid && mid<second )
	{
		if ( A[first] > A[mid] )
		{
			second = mid;
		}
		else if ( A[second] < A[mid] )
		{
			first = mid;
		}
		mid = (first + second)/2;
	}

	return mid; // return the index of the greatest number
}

int main()
{
	const int n = 8;
	int A[n] = {6,9,11,15,16,2,3,4};
	cout << findPivotInRotatedArray( A, n ) << endl;

	system("pause");
	return 0;
}