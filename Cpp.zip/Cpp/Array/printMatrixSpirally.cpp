// Given a matrix, print it spirally. For example, given 
// 1, 2, 3
// 4, 5, 6
// 7, 8, 9
// The output should be 1, 2, 3, 6, 9, 8, 7, 4, 5, 6.

#include <iostream>
#include <ctime>
using namespace std;

const int m = 5, n = 5;

void printMatrixSpirally( int A[m][n] )
{
	for ( int j=0; j<n; j++ )
		cout << A[0][j] << " ";
	int count = n;
	int direction = 1; // 0:right; 1:down; 2:left; 3:up
	int layer = 0;
	while ( count<m*n )
	{
		switch ( direction%4 )
		{
			case 0:
				for ( int j=layer/4+1; j<=n-2-layer/4; j++ )
				{
					cout << A[1+layer/4][j] << " ";
					count++;
					if ( count==m*n )
						return;
				}
				layer++;
				direction++;
				break;
			case 1:
				for ( int i=1+layer/4; i<=m-1-layer/4; i++ )
				{
					cout << A[i][n-1-layer/4] << " ";
					count++;
					if ( count==m*n )
						return;
				}
				layer++;
				direction++;
				break;
			case 2:
				for ( int j=n-2-layer/4; j>=layer/4; j-- )
				{
					cout << A[m-1-layer/4][j] << " ";
					count++;
					if ( count==m*n )
						return;
				}
				layer++;
				direction++;
				break;
			case 3:
				for ( int i=m-2-layer/4; i>=layer/4+1; i-- )
				{
					cout << A[i][layer/4] << " ";
					count++;
					if ( count==m*n )
						return;
				}
				layer++;
				direction++;
				break;
		}
	}
	cout << endl;
}

int main()
{
	srand( time(NULL) );
	int A[m][n] = {0};
	for ( int i=0; i<m; i++ )
	{
		for ( int j=0; j<n; j++ )
			A[i][j] = i*n + j + 1;
	}
	printMatrixSpirally( A );

	system("pause");
	return 0;
}