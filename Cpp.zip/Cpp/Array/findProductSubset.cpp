// Given an array A, find a subset A' of A such that every element of A' is the product of remaining elements of A.
// http://www.careercup.com/question?id=3402688