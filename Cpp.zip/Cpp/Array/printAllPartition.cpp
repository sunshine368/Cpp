/*
Given two integers, n and m (n>=m), print all unique partitions of n into m integers.
For example, given 10 and 4, the output should be:
7 1 1 1
6 2 1 1
5 3 1 1
4 4 1 1
5 2 2 1
4 3 2 1
3 3 3 1
4 2 2 2
3 3 2 2
*/

#include <iostream>
using namespace std;

void printAllPartitionAux( int sum, int num, int rsum, int rnum, int *A )
{
    if ( rnum==0 )
    {
        if ( rsum==0 )
        {
            for ( int i=0; i<num; i++ )
            {
                cout << A[i] << " ";
            }
            cout << endl;
            return;
        }
        else
            return;
    }
    
    for ( int i=A[rnum]; i<=rsum+1-rnum; i++ )
    {
        A[rnum-1] = i;
        printAllPartitionAux( sum, num, rsum-i, rnum-1, A );
    }
}

void printAllPartition( int n, int m )
{
    int *temp = (int*)malloc( sizeof(int)*(m+1) );
    temp[m] = 1;
    printAllPartitionAux( n, m, n, m, temp );
}

int main()
{
    printAllPartition( 10, 4 );
    return 0;
}