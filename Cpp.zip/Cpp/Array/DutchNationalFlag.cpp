// Given a character array which contains only three types of characters, 'R', 'G' and 'B',
// sort the array such that all R's come before G's and all G's come before B's.

#include <iostream>
using namespace std;

void swap( char &a, char &b )
{
	char temp = a;
	a = b;
	b = temp;
}

void arrangeRGB( char A[], int size )
{
	int low = -1;
	int high = size;
	for ( int i=0; i<high; i++ )
	{
		if ( A[i]=='R' )
		{
			swap( A[i], A[++low] );
		}
		else if ( A[i]=='B' )
			swap( A[i], A[--high] );
	}
}

int main()
{
	const int n = 8;
	char A[] = {'R','B','R','G','R','B','G','G'};
	cout << "strlen(A) = " << strlen(A) << endl;
	cout << "sizeof(A) = " << sizeof(A) << endl;
	cout << "sizeof(char) = " << sizeof(char) << endl;
	cout << "sizeof(A)/sizeof(char) = " << sizeof(A)/sizeof(char) << endl;

	cout << "The original array:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << endl;

	arrangeRGB( A, n );

	cout << "\nThe modified array:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << endl;

	system("pause");
	return 0;
}