// Knapsack program:
// Given a list L of positive integers and a positive integer M, find the largest subset of L
// whose sum is at most M. The complexity should be O(n).

#include <iostream>
using namespace std;

void printLargestSubset( int *A, int n, int **L, int i, int j )
{
	if ( j==0 )
	{
		return;
	}
	if ( j==1 )
	{
		if ( L[i][j]==0 )
		{
			return;
		}
		else
		{
			cout << A[j-1] << endl;
			return;
		}
	}
	if ( L[i][j]==L[i][j-1] )
	{
		printLargestSubset( A, n, L, i, j-1 );
	}
	else
	{
		printLargestSubset( A, n, L, i-A[j-1], j-1 );
		cout << A[j-1] << endl;
	}
}

int findLargestSubset( int *A, int n, int M )
{
	int **L = (int**)malloc( sizeof(int*) * (M+1) );
	for ( int i=0; i<M+1; i++ )
	{
		L[i] = (int*)malloc( sizeof(int)*(n+1) );
		for ( int j=0; j<n+1; j++ )
		{
			L[i][j] = 0;
		}
	}

	for ( int j=0; j<n+1; j++ )
	{
		L[0][j] = 0;
	}

	for ( int i=0; i<=M; i++ )
	{
		L[i][0] = 0;
	}

	for ( int i=0; i<=M; i++ )
	{
		for ( int j=1; j<n+1; j++ )
		{
			if ( A[j-1] > i )
			{
				L[i][j] = L[i][j-1];
			}
			else
			{
				int temp = L[i-A[j-1]][j-1] + 1;
				if ( temp > L[i][j-1] )
				{
					L[i][j] = temp;
				}
				else
				{
					L[i][j] = L[i][j-1];
				}
			}
		}
	}

	printLargestSubset( A, n, L, M, n );

	return L[M][n];
}

int main()
{
	const int n = 8;
	int A[n] = {1,2,2,1,5,3,1,1};
	int M = 8;
	int maxlength = findLargestSubset( A, n, M );
	cout << maxlength << endl;

	system("pause");
	return 0;
}