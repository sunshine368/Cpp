// Given an array of 0's and non-zeros, move all 0's to the beginning and all non-zeros to the end.
// The original order should be kept.

#include <iostream>
using namespace std;

void moveZeroToBeginning( int *A, int n )
{
	int first = n-1;
	int second = n-1;
	
	while ( first>=0 )
	{
		if ( A[first]==0 )
		{
			first--;
		}
		else
		{
			A[second] = A[first];
			second--;
			first--;
		}
	}

	while ( second>=0 )
	{
		A[second] = 0;
		second--;
	}
}

int main()
{
	const int n = 11;
	int A[n] = {1,9,8,4,0,0,2,7,0,6,0};
	moveZeroToBeginning( A, n );
	for ( int i=0; i<n; i++ )
		cout << A[i] << endl;

	system("pause");
	return 0;
}