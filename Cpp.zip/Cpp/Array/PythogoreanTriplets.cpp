// Given an array of integers, find all pythogoream triplets, i.e., a^2 + b^2 = c^2,
// print a, b, c and the indexes.

#include <iostream>
using namespace std;

void swap( int *a, int *b )
{
	(*a) += (*b);
	(*b) = (*a) - (*b);
	(*a) -= (*b);
}

void sort( int *A, int n )
{
	for ( int i=0; i<n-1; i++ )
	{
		for ( int j=0; j<n-1-i; j++ )
		{
			if ( A[j] > A[j+1] )
				swap( &A[j], &A[j+1] );
		}
	}
}

int max( int *A, int n )
{
	int m = 0;
	for ( int i=0; i<n; i++ )
	{
		if ( A[i] > m )
			m = A[i];
	}
	return m;
}


void PythogoreanTriplets( int *A, int n )
{
	int *B = (int*)malloc( sizeof(int) * n );
	for ( int i=0; i<n; i++ )
	{
		B[i] = A[i]*A[i];
	}

	for ( int i=0; i<n; i++ )
	{
		cout << B[i] << endl;
	}

	int m = max(B,n);
	int *hashtable = (int*)malloc( sizeof(int) * (m+1) );
	for ( int i=0; i<n; i++ )
	{
		hashtable[B[i]] = i;
	}

	sort(B, n);

	for ( int i=0; i<n; i++ )
	{
		cout << B[i] << endl;
	}

	bool flag = 0;
	for ( int i=0; i<n-2; i++ )
	{
		for ( int first=i+1; first<n-1; first++ )
		{
			int second = n-1;
			while ( first < second )
			{
				if ( B[i] == B[second] - B[first] )
				{
					cout << "A[" << hashtable[B[i]] << "]: " << A[hashtable[B[i]]] << ", " << "A[" << hashtable[B[first]] << "]: " << A[hashtable[B[first]]] << ", " << "A[" << hashtable[B[second]] << "]: " << A[hashtable[B[second]]] << "\n";
					second--;
					first++;
				}
				else if ( B[i] + B[first] < B[second] )
				{
					second--;
				}
				else
				{				
					flag = 1;
					break;
				}
			}
			if ( flag )
				break;
		}
	}
}

int main()
{
	const int n = 8;
	int A[n] = {-1, 5, -3, 4, 2, 6, 10, -8};
	PythogoreanTriplets( A, n );

	system("pause");
	return 0;
}