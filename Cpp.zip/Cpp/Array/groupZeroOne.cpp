// Sort an array of 0/1 in O(n) time complexity without using counting.

#include <iostream>
using namespace std;

void groupZeroOne( int *A, int n )
{
	int first = 0;
	int second = n-1;
	while( first < second )
	{
		while ( A[first]==0 )
		{
			first++;
		}

		while ( A[second]==1 )
		{
			second--;
		}

		if ( first < second )
		{
			A[first] = 0;
			A[second] = 1;
			first++;
			second--;
		}
	}
}

int main()
{
	const int n = 6;
	int A[n] = {0,1,0,1,0,1};

	groupZeroOne( A, n );

	for ( int i=0; i<n; i++ )
		cout << A[i] << endl;

	system("pause");
	return 0;
}