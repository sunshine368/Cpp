// Given three arrays, a, b and c, find all triples (i,j,k) such that a[i] + b[j] = c[k].
// The solution is O((a.length+b.length)*c.length) in time complexity.

#include <iostream>
using namespace std;

void threeArraysSum( int *a, int *b, int *c, int na, int nb, int nc )
{
	int sum;
	int apos;
	int bpos;
	for ( int k=0; k<nc; k++ )
	{
		sum = c[k];
		apos = 0;
		bpos = nb-1;
		while ( apos<na && bpos>=0 )
		{
			if ( a[apos]+b[bpos]==sum )
			{
				cout << "a[" << apos << "] + b[" << bpos << "] = " << "c[" << k << "], " << a[apos] << " + " << b[bpos] << " = " << sum << endl;
				apos++;
				bpos--;
			}
			else if ( a[apos]+b[bpos]>sum )
			{
				bpos--;
			}
			else
			{
				apos++;
			}
		}
	}
}

int main()
{
	const int n = 6;
	int A[n] = {1,2,3,4,5,6};
	int B[n] = {1,2,3,4,5,6};
	int C[n] = {1,2,3,4,5,6};
	threeArraysSum( A, B, C, n, n, n );

	system("pause");
	return 0;
}