// Given two arrays, A and B, add the two arrays and return a new array C.
// For example, given {1,2,3,4} and {5,6,7,8}, return {6,9,1,2}.

#include <iostream>
using namespace std;

void addTwoArraysAsTwoIntegers( int *A, int *B, int *C, int na, int nb, int &nc )
{
	int size;
	if ( na>=nb )
	{
		size = na;
	}
	else
	{
		size = nb;
	}

	if ( nc<size+1 )
	{
		cout << "Array C not long enough!\n";
		return;
	}

	nc = size + 1;
	int apos = na-1;
	int bpos = nb-1;
	int cpos = nc-1;
	int carry = 0;
	while ( apos>=0 || bpos>=0 )
	{
		if ( apos>=0 )
		{
			carry += A[apos];
			apos--;
		}

		if ( bpos>=0 )
		{
			carry += B[bpos];
			bpos--;
		}

		C[cpos] = carry%10;
		cpos--;
		carry = carry/10;
	}
	C[cpos] = carry;

	if ( C[0]==0 )
	{
		for ( int i=0; i<nc; i++ )
		{
			C[i] = C[i+1];
		}
		nc--;
	}
}

int main()
{
	const int na = 4;
	const int nb = 5;
	int A[na] = {1,2,3,4};
	int B[nb] = {9,6,7,8,2};
	int nc;
	if ( na >= nb )
		nc = na + 1;
	else
		nc = nb + 1;
	int *C = (int*)malloc( sizeof(int)*nc );
	for ( int i=0; i<nc; i++ )
	{
		C[i] = 0;
	}
	addTwoArraysAsTwoIntegers( A, B, C, na, nb, nc );
	for ( int i=0; i<nc; i++ )
		cout << C[i];
	cout << endl;

	system("pause");
	return 0;
}