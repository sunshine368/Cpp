// Given an array of stock prices, find the buying price and the selling price such that the profit is maximized.

#include <iostream>
using namespace std;

void stockMaxProfit( int *A, int n )
{
    int *D = (int*)malloc( sizeof(int)*(n-1) );
    for ( int i=0; i<n-1; i++ )
    {
        D[i] = A[i+1] - A[i];
    }
    
    int *S = (int*)malloc( sizeof(int)*(n-1) );
    S[0] = D[0];
    int maxProfit = S[0];
    int sell = 0;
    for ( int i=1; i<n-1; i++ )
    {
        int temp = S[i-1] + D[i];
        if ( temp > D[i] )
        {
            S[i] = temp;
        }
        else
        {
            S[i] = D[i];
        }
        if ( S[i] > maxProfit )
        {
            sell = i;
            maxProfit = S[i];
        }
    }

    int buy = sell;
    sell = A[sell+1];
    int temp = maxProfit;
    while ( temp>0 )
    {
        temp -= D[buy];
        buy--;
    }
    buy = A[buy+1];
    
    cout << "The maximum profit is " << maxProfit << " by buying at price " << buy << " and selling at price " << sell << endl;
}

int main()
{
    const int n = 8;
    int A[n] = {-2, 4, 30, -50, 90, -60, 100, 90};
    stockMaxProfit( A, n );
    return 0;
}