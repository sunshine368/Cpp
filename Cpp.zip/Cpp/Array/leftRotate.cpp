#include <iostream>
using namespace std;

void reverse( int *A, int i, int j )
{
	while ( i<j )
	{
		A[i] += A[j];
		A[j] = A[i] - A[j];
		A[i] -= A[j];
		i++;
		j--;
	}
}

void leftRotate( int *A, int n, int k )
{
	reverse( A, 0, k-1 );
	reverse( A, k, n-1 );
	reverse( A, 0, n-1 );
}

int main()
{
	const int n = 8;
	int A[n] = {1,2,3,4,5,6,7,8};
	leftRotate( A, n, 3 );

	for ( int i=0; i<n; i++ )
		cout << A[i] << endl;

	system("pause");
	return 0;
}