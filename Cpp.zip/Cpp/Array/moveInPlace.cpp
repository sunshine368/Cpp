// Given an array of integers with the first half and the second half sorted in increasing order,
// merge the two halves into one sorted array. In-place operation only, i.e., no extra space allowed.
// For example, given {1,3,6,8,-5,-2,3,8}, the output should be {-5,-2,1,3,3,6,8,8}.

#include <iostream>
using namespace std;

void leftShiftOne( int *A, int n, int left, int right )
{
    for ( int i=left; i<=right; i++ )
        A[i-1] = A[i];
}

void moveInPlace( int *A, int n )
{
    if ( n%2!=0 )
        return;
    
    int first = n/2-1, second = n-1, temp;
    while ( first>=0 )
    {
        if ( A[first]>A[second] )
        {
            temp = A[first];
            leftShiftOne( A, n, first+1, second-1 );
            A[second-1] = A[second];
            A[second] = temp;
            second--;
            first--;
        }
        else
        {
            second--;
        }
        for ( int i=0; i<n; i++ )
            cout << A[i] << " ";
        cout << endl;
    }
}

int main()
{
    const int n = 8;
    int A[n] = {1,3,6,8,-5,-2,3,8};
    moveInPlace( A, n );
    for ( int i=0; i<n; i++ )
        cout << A[i] << " ";
    cout << endl;
    return 0;
}