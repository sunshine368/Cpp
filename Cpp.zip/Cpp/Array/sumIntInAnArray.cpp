// Given an array of integers/characters/special characters, find out the sum of 
// integers. For example, given "PST456DA85M2A!!23++46", the sum of all integers 
// is 612.

#include <iostream>
using namespace std;

int sumIntInAnArray( char *A, int n )
{
	int number = 0;
	int sum = 0;
	for ( int i=0; i<n; i++ )
	{
		if ( A[i]>='0' && A[i]<='9' )
		{
			number = number*10 + A[i]-'0';
		}
		else
		{
			sum += number;
			number = 0;
		}
	}
	sum += number;
	return sum;
}

int main()
{
	char A[] = "PST456DA85M2A!!23++46";
	int sum = sumIntInAnArray( A, strlen(A) );
	cout << sum << endl;

	system("pause");
	return 0;
}