// Given two arrays, A and B, find the intersection of the two arrays.

#include <iostream>
using namespace std;


// Use merge sort and binary search, time complexity O(nlog(n) + mlog(n)), space complexity: O(n)
// where n is the length of array A and m is the length of array B, assume n<=m
void merge( int *A, int first, int last, int *temp )
{
	int i = first;
	int mid = (first+last)/2;
	int left = first;
	int right = mid+1;

	while ( left<=mid && right<=last )
	{
		if ( A[left]<=A[right] )
			temp[i++] = A[left++];
		else
			temp[i++] = A[right++];
	}

	if ( left==mid+1 )
	{
		while ( right<=last )
			temp[i++] = A[right++];
	}
	else if ( right==last+1 )
	{
		while ( left<=mid )
			temp[i++] = A[left++];
	}

	for ( int i=first; i<=last; i++ )
		A[i] = temp[i];
}

void mergeSortAux( int *A, int first, int last, int *temp, int n )
{
	if ( first==last )
		return;
	int mid = (first+last)/2;

	mergeSortAux( A, first, mid, temp, n );
	mergeSortAux( A, mid+1, last, temp, n );
	merge( A, first, last, temp );
}

void mergeSort( int *A, int n )
{
	int *temp = (int*)malloc( sizeof(int) * n );
	mergeSortAux( A, 0, n-1, temp, n );
}

int binarySearchAux( int *A, int n, int key, int left, int right )
{
	if ( left==right )
	{
		if ( A[left]==key )
			return 0;
		else
			return -1;
	}
	int mid = (left+right)/2;
	if ( A[mid]==key )
		return mid;
	else if ( A[mid]>key )
		return binarySearchAux( A, n, key, left, mid );
	else
		return binarySearchAux( A, n, key, mid+1, right );
}

int binarySearch( int *A, int n, int key )
{
	return binarySearchAux( A, n, key, 0, n-1 );
}

void findIntersection( int *A, int *B, int na, int nb )
{
	mergeSort( A, na );
	int found;
	for ( int i=0; i<nb; i++ )
	{
		found = binarySearch( A, na, B[i] );
		if ( found!=-1 )
			cout << "B[" << i << "] = " <<  B[i] << " is found at: A[" << found << "]" << endl;
	}
}


// Use hashtable, time complexity: O(m+n), space complexity: O(max(A)) where n is 
// the length of array A and m is the length of array B, assume n<=m 
int findMax( int *A, int n )
{
	int max = A[0];
	for ( int i=0; i<n; i++ )
	{
		if ( A[i] >max )
			max = A[i];
	}
	return max;
}

void findIntersection2( int *A, int *B, int na, int nb )
{
	int max = findMax( A, na );
	int *hashtable = (int*)malloc( sizeof(int)*max );
	for ( int i=0; i<=max; i++ )
		hashtable[i] = 0;
	for ( int i=0; i<na; i++ )
		hashtable[A[i]]++;
	for ( int i=0; i<nb; i++ )
	{
		if ( hashtable[B[i]]>0 )
			cout << "B[" << i << "] = " <<  B[i] << endl;
	}
}


int main()
{
	const int n = 10;
	int A[n] = {30,47,22,67,79,18,60,78,26,54};

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	mergeSort( A, n );
	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	const int m = 12;
	int B[m] = {13,18,30,6,8,26,22,47,15,29,12,18};
	findIntersection( A, B, n, m );

	findIntersection2( A, B, n, m );

	system("pause");
	return 0;
}