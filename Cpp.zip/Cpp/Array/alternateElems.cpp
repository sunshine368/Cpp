// Given an array of 2n integers, {a1,a2,a3,...,an,b1,b2,b3,...,bn}, rearrange the array such that
// the resultant array is {a1,b1,a2,b2,a3,b3,...,an,bn}.

#include <iostream>
using namespace std;

void alternativeElems( int *A, int n )
{
    for ( int i=n-1; i>0; i-- )
    {
        for ( int j=i; j<=2*n-2-i; j+=2 )
        {
            swap( A[j], A[j+1] );
        }
    }
}

int main()
{
    const int n = 4;
    int A[2*n] = {1,2,3,4,5,6,7,8};
    
    for ( int i=0; i<2*n; i++ )
        cout << A[i] << " ";
    cout << endl;
    
    alternativeElems( A, n );
    
    for ( int i=0; i<2*n; i++ )
        cout << A[i] << " ";
    cout << endl;
    
    const int n2 = 6;
    int A2[2*n2] = {1,2,3,4,5,6,7,8,9,10,11,12};
    
    for ( int i=0; i<2*n2; i++ )
        cout << A2[i] << " ";
    cout << endl;
    
    alternativeElems( A2, n2 );
    
    for ( int i=0; i<2*n2; i++ )
        cout << A2[i] << " ";
    cout << endl;
    
    return 0;
}