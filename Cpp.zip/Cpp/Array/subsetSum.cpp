// Given an array of n integers and a number k, determine if there are k elements which sum up to 0.
// http://en.wikipedia.org/wiki/Subset_sum_problem

#include <iostream>
using namespace std;

/*
Let Q(i,s) be a bool indicating whether there is a subset of the first i elements 
of the array A which sum up to s. 
We want to solve for Q(n,0). 
When i=1, we have
Q(1,s) = (A[1]==s).
When i=2,...,n, we have
Q(i,s) = Q(i-1,s) or (A[i]==s) or Q(i-1,s-A[i]).
Let n(i,s) denote the size of the subset of the first i elements of the array A
which sum up to s.
*/

bool subsetSumAux( int *A, int n, int sum, int i );

bool subsetSum( int *A, int n, int sum )
{
	return subsetSumAux( A, n, 0, n-1 );
}

bool subsetSumAux( int *A, int n, int sum, int i )
{
	if ( i==0 )
		return (A[0] == sum);
	else
		return ((subsetSumAux(A,n,sum,i-1)) || (subsetSumAux(A,n,sum-A[i],i-1)) || (A[i]==sum));
}


/*
Besides Q(n,0), we also want to find out if there are k elements which sum up to 0.
Every time we call subsetSumAux(A,n,sum-A[i],i-1), the number of elements required 
is decreased by one.
*/
bool subsetKSumAux( int *A, int n, int sum, int i, int k );

bool subsetKSum( int *A, int n, int sum, int k )
{
	return subsetKSumAux( A, n, 0, n-1, k );
}

bool subsetKSumAux( int *A, int n, int sum, int i, int k )
{
	if ( i==0 )
		return ((A[0] == sum)&&(k==1)); 
	else
		return ( (subsetKSumAux(A,n,sum,i-1,k)) || (subsetKSumAux(A,n,sum-A[i],i-1,k-1)) || ( (A[i]==sum)&&(k==1) ) );
}

int main()
{
	const int n = 6;
	int A[n] = {-4,-2,1,3,5,0};
	cout << subsetSum( A, n, 0 ) << endl;

	cout << subsetKSum( A, n, 0, 1 ) << endl;

	system("pause");
	return 0;
}