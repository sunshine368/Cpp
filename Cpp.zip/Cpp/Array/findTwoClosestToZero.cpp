// Given an array of integers, find two numbers whose sum is closest to zero.

#include <iostream>
using namespace std;

// Time complexity: O(n^2)
void findTwoClosetToZero( int *A, int n )
{
    int first = A[0], second = A[1], sum = abs(first+second), temp;
    for ( int i=0; i<n-1; i++ )
    {
        for ( int j=i+1; j<n; j++ )
        {
            temp = abs( A[i] + A[j] );
            if ( temp<sum )
            {
                first = A[i];
                second = A[j];
                sum = temp;
            }
        }
    }
    cout << first << " + " << second << " = " << sum << endl;
}


// Time complexity: O(nlog(n))
void merge( int *A, int n, int first, int last, int *temp )
{
	int i = first;
	int left = first;
	int mid = (first+last)/2;
	int right = mid + 1;
    
	while ( left<=mid && right<=last )
	{
		if ( A[left]<=A[right] )
			temp[i++] = A[left++];
		else
			temp[i++] = A[right++];
	}
    
	if ( left==mid+1 )
	{
		while ( right<=last )
			temp[i++] = A[right++];
	}
	else
	{
		while ( left<=mid )
			temp[i++] = A[left++];
	}
    
	for ( int i=first; i<=last; i++ )
		A[i] = temp[i];
}

void mergeSortAux( int *A, int n, int first, int last, int *temp )
{
	if ( first==last )
		return;
	int mid = (first+last)/2;
	mergeSortAux( A, n, first, mid, temp );
	mergeSortAux( A, n, mid+1, last, temp );
	merge( A, n, first, last, temp );
}

void mergeSort( int *A, int n )
{
	int *temp = (int*)malloc( sizeof(int)*n );
	mergeSortAux( A, n, 0, n-1, temp );
}

void findTwoClosetToZero2( int *A, int n )
{
    mergeSort(  A, n );
    int first = 0;
    int second = n-1;
    int sum = abs(A[first]+A[second]);
    int temp1, temp2;
    while ( first<second )
    {
        if ( sum==0 )
        {
            cout << A[first] << " + " << A[second] << " = 0" << endl;
            return;
        }
        
        if ( first<second-1 )
        {
            temp1 = abs(A[first+1]+A[second]);
            temp2 = abs(A[first]+A[second-1]);
        }
        
        if ( temp1<sum )
        {
            first++;
            sum = temp1;
        }
        else if ( temp2<sum )
        {
            second--;
            sum = temp2;
        }
        else
        {
            cout << A[first] << " + " << A[second] << " = " << sum << endl;
            return;
        }
    }
    cout << A[first] << " + " << A[second+1] << " = " << sum << endl;
}

int main()
{
    const int n = 8;
    int A[n] = {1,2,3,4,5,6,7,8};
    findTwoClosetToZero( A, n );
    findTwoClosetToZero2( A, n );
    return 0;
}