// Given an array of positive integers, find the subsequence whose elements should not be adjacent and their 
// sum should be maximum among all such subsequences. For example, given {10,1,3,25}, the subsequence with
// the maximum sum is {10,25}.

#include <iostream>
using namespace std;

void printAux( int *A, int *sum, int n, int i )
{
	if ( i==1 )
	{
		cout << sum[1] << endl;
		return;
	}
	if ( i==0 )
	{
		cout << A[0] << endl;
		return;

	}
	if ( sum[i] != sum[i-1] )
	{
		printAux( A, sum, n, i-2 );
		cout << A[i] << endl;
	}
	else
	{
		printAux( A, sum, n, i-1 );
	}
}


void printNonadjacentMax( int *A, int n )
{
	int *sum = (int*)malloc( sizeof(int)*n );
	sum[0] = A[0];
	if ( A[1] > A[0] )
	{
		sum[1] = A[1];
	}
	else
	{
		sum[1] = A[0];
	}

	for ( int i=2; i<n; i++ )
	{
		if ( sum[i-1] > A[i]+sum[i-2] )
		{
			sum[i] = sum[i-1];
		}
		else
		{
			sum[i] = A[i] + sum[i-2];
		}
	}

	cout << "sum: " << sum[n-1] << endl;

	printAux( A, sum, n, n-1 );
}

int main()
{
	const int n=7;
	int A[n] = {10,1,3,25,2,4,20};
	printNonadjacentMax( A, n );

	system("pause");
	return 0;
}