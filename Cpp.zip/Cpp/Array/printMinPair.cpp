// Given an array of integers, print a pair whose sum is closest to zero.

#include <iostream>
using namespace std;

void swap( int *a, int *b )
{
	(*a) += (*b);
	(*b) = (*a) - (*b);
	(*a) -= (*b);
}

void sort( int *A, int n )
{
	for ( int i=0; i<n-1; i++ )
	{
		for ( int j=0; j<n-1-i; j++ )
		{
			if ( A[j] > A[j+1] )
				swap( &A[j], &A[j+1] );
		}
	}
}

void printMinPair( int *A, int n )
{
	sort( A, n );

	int left = 0;
	int right = n-1;
	int sum = A[0] + A[n-1];
	for ( int first=0, second=n-1; first<second; (A[first]+A[second]>0) ? (second--) : (first++) )
	{
		int temp = A[first] + A[second];
		if ( abs(sum) > abs(temp) )
		{
			sum = temp;
			left = first;
			right = second;
		}
		if ( sum == 0 )
			break;
	}

	cout << A[left] << " + " << A[right] << " = " << sum << endl;
}

int main()
{
	const int n = 6;
	int A[n] = {1,5,8,-7,2,9};
	printMinPair( A, n );

	system("pause");
	return 0;
}