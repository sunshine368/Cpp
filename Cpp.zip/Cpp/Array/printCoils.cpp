// Given an 4n-by-4n matrix where n is a positive integer, imagine the matrix consisting
// of two interleaved coils whose centers are at the center of the matrix. Print the two
// coils in two separate lines.

#include <iostream>
using namespace std;

void printCoils( int **A, int *x1, int *x2, int n )
{
	int a = 4*n;

	int xpos = 0.5*a + 1;
	int ypos = 0.5*a;
	x1[0] = A[xpos-1][ypos-1];
	x2[0] = A[a-xpos][a-ypos];

	int direction = 0; // "direction" controls the moving direction in the matrix A, up, right, down, or left
	int count = 1; // number of elements in each one of the two results
	int increment = 1; // controls the number of elements to be copied in a row or column

	while ( count<8*n*n )
	{
		int i;
		switch( direction )
		{
		case 0:
			i=1;
			while ( count<8*n*n && i<=2*increment )
			{
				xpos--;
				x1[count] = A[xpos-1][ypos-1];
				x2[count] = A[a-xpos][a-ypos];
				count++;
				i++;
			}
			break;
		case 1:
			i=1;
			while ( count<8*n*n && i<=2*increment )
			{
				ypos++;
				x1[count] = A[xpos-1][ypos-1];
				x2[count] = A[a-xpos][a-ypos];
				count++;	
				i++;
			}
			increment++;
			break;
		case 2:
			i=1;
			while ( count<8*n*n && i<=2*increment )
			{
				xpos++;
				x1[count] = A[xpos-1][ypos-1];
				x2[count] = A[a-xpos][a-ypos];
				count++;
				i++;
			}
			break;
		case 3:
			i=1;
			while ( count<8*n*n && i<=2*increment )
			{
				ypos--;
				x1[count] = A[xpos-1][ypos-1];
				x2[count] = A[a-xpos][a-ypos];
				count++;
				i++;
			}
			increment++;
			break;
		}

		if ( direction == 4 )
		{
			direction = 0;
		}
		else
		{
			direction++;
		}
	}
}

int main()
{
	int n = 2;
	int **A = (int**)malloc( sizeof(int*)*4*n );
	for ( int i=0; i<4*n; i++ )
	{
		A[i] = (int*)malloc( sizeof(int)*4*n );
		for ( int j=0; j<4*n; j++ )
		{
			A[i][j] = i*4*n + j + 1;
		}
	}
	int *x = (int*)malloc( sizeof(int)*8*n*n );
	int *y = (int*)malloc( sizeof(int)*8*n*n );
	printCoils( A, x, y, n );

	for ( int i=0; i<8*n*n; i++ )
		cout << x[i] << " ";
	cout << endl;

	for ( int i=0; i<8*n*n; i++ )
		cout << y[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}