#include <iostream>
using namespace std;

void reverseArrayRecurAux( char A[], int i, int j )
{
	if ( i>=j )
		return;
	A[i] += A[j];
	A[j] = A[i] - A[j];
	A[i] -= A[j];
	reverseArrayRecurAux( A, i+1, j-1 );
}

void reverseArrayRecur( char A[] )
{
	int size = strlen(A);
	reverseArrayRecurAux( A, 0, size-1 );
}

int main()
{
	char A[] = "gdfeabbcegwln";
	cout << "The original array:\n" << A << endl;
	reverseArrayRecur( A );
	cout << "The modified array:\n" << A << endl;
	system("pause");
	return 0;
}