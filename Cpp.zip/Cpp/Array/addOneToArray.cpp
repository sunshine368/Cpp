// Given a number, e.g., 2789, as an array [2,7,8,9], write a method that returns the
// array incremented by one, i.e., [2,7,9,0].

#include <iostream>
using namespace std;

void addOneToArray( int *A, int n )
{
    int carry = 1;
    for ( int i=n-1; i>=0; i-- )
    {
        carry += A[i];
        A[i] = carry%10;
        carry = carry/10;
    }
    if ( carry==1 )
    {
        cout << carry;
        for ( int i=0; i<n; i++ )
        {
            cout << A[i];
        }
        cout << endl;
    }
    else
    {
        for ( int i=0; i<n; i++ )
            cout << A[i];
        cout << endl;
    }
}

int addOneToArray2( int *A, int n )
{
    int carry = 1;
    int num = 0;
    int tens = 1;
    for ( int i=n-1; i>=0; i-- )
    {
        carry += A[i];
        A[i] = carry%10;
        num += A[i]*tens;
        tens *= 10;
        carry = carry/10;
    }
    return num;
}

int main()
{
    const int n = 4;
    int A[n] = {9,9,8,9};
    addOneToArray( A, n );
    
    const int n2 = 4;
    int A2[n2] = {9,9,8,9};
    int result = addOneToArray2( A2, n2 );
    cout << result << endl;
    return 0;
}
