// Rotate a matrix by 180 degrees.

#include <iostream>
#include <ctime>
using namespace std;

void rotateMatrix180Deg( int **A, int row, int col )
{
    for ( int i=0; i<row/2; i++ )
    {
        for ( int j=0; j<col/2; j++ )
        {
            A[i][j] += A[row-1-i][col-1-j];
            A[row-1-i][col-1-j] = A[i][j] - A[row-1-i][col-1-j];
            A[i][j] -= A[row-1-i][col-1-j];
            A[i][col-1-j] += A[row-1-i][j];
            A[row-1-i][j] = A[i][col-1-j] - A[row-1-i][j];
            A[i][col-1-j] -= A[row-1-i][j];
        }
    }
    
    if ( row%2==1 )
    {
        for ( int j=0; j<col/2; j++ )
        {
            A[row/2][j] += A[row/2][col-1-j];
            A[row/2][col-1-j] = A[row/2][j] - A[row/2][col-1-j];
            A[row/2][j] -= A[row/2][col-1-j];
        }
    }
    
    if ( col%2==1 )
    {
        for ( int i=0; i<row/2; i++ )
        {
            A[i][col/2] += A[row-1-i][col/2];
            A[row-1-i][col/2] = A[i][col/2] - A[row-1-i][col/2];
            A[i][col/2] -= A[row-1-i][col/2];
        }
    }
}

int main()
{
    srand(time(NULL));
    int row = 4, col = 5;
    int **A = (int**)malloc( sizeof(int*)*row );
    for ( int i=0; i<row; i++ )
    {
        A[i] = (int*)malloc( sizeof(int)*col );
        for ( int j=0; j<col; j++ )
        {
            A[i][j] = rand()%100;
        }
    }
    
    for ( int i=0; i<row; i++ )
    {
        for ( int j=0; j<col; j++ )
            cout << A[i][j] << " ";
        cout << endl;
    }
    cout << endl;
    
    rotateMatrix180Deg( A, row, col );
    
    for ( int i=0; i<row; i++ )
    {
        for ( int j=0; j<col; j++ )
            cout << A[i][j] << " ";
        cout << endl;
    }
    
    return 0;
}