// Given an array of integers, determine if it is possible to divide it into two groups such that
// the sums of the two groups are the same. 

#include <iostream>
using namespace std;

// non-recursive method
int divideInHalfAux( int *A, int n, int sum )
{
    int **found = (int**)malloc( sizeof(int*)*(n+1) );
    for ( int i=0; i<=n; i++ )
    {
        found[i] = (int*)malloc( sizeof(int)*(sum+1) );
        for ( int j=0; j<=sum; j++ )
        {
            found[i][j] = 0;
        }
    }
    
    found[0][0] = 0;
    for ( int i=1; i<=n; i++ )
    {
        found[i][0] = ( A[i-1]==0 || found[i-1][0] );
    }
    
    for ( int j=1; j<=sum; j++ )
    {
        found[0][j] = 0;
    }
    
    for ( int i=1; i<=n; i++ )
    {
        for ( int j=1; j<=sum; j++ )
        {
            found[i][j] = ( found[i-1][j] || found[i-1][j-A[i-1]] );
        }
    }
    
    return found[n][sum];
}

int divideInHalf( int *A, int n )
{
    int sum = 0;
    for ( int i=0; i<n; i++ )
        sum += A[i];
    if ( sum%2!=0 )
    {
        return 0;
    }
    else
    {
        sum /= 2;
        return divideInHalfAux( A, n, sum );
    }
}

// recursive method
int divideInHalfAux2( int *A, int n, int i, int sum )
{
    if ( i==n )
    {
        return (sum==0);
    }
    
    return ( divideInHalfAux2( A, n, i+1, sum-A[i] ) || divideInHalfAux2( A, n, i+1, sum ) );
}

int divideInHalf2( int *A, int n )
{
    int sum = 0;
    for ( int i=0; i<n; i++ )
        sum += A[i];
    if ( sum%2!=0 )
    {
        return 0;
    }
    else
    {
        sum /= 2;
        return divideInHalfAux2( A, n, 0, sum );
    }
}

int main()
{
    const int n = 8;
    int A[n] = {5,2,9,0,3,2,1,4};
    int found = divideInHalf( A, n );
    cout << found << endl;
 
    const int n2 = 3;
    int A2[n2] = {5,2,9};
    int found2 = divideInHalf2( A2, n2 );
    cout << found2 << endl;
    return 0;
}