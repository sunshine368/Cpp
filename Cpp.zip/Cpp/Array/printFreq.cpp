// Given an array of integers, find the mode and the frequency of the mode. 
// In addition, print each number along with its frequency.

#include <iostream>
using namespace std;

int max( int *A, int n )
{
	int m = 0;
	for ( int i=0; i<n; i++ )
	{
		if ( A[i] > m )
			m = A[i];
	}
	return m;
}

void printFreq( int *A, int n )
{
	int m = max( A, n );
	int *hashtable = (int*)malloc( sizeof(int) * (m+1) );
	for ( int i=0; i<m+1; i++ )
	{
		hashtable[i] = 0;
	}

	for ( int i=0; i<n; i++ )
	{
		hashtable[A[i]]++;
	}

	int count = 0;
	if ( n%2 == 0 )
	{
		for ( int i=0; i<m+1; i++ )
		{
			count += hashtable[i];
			if ( count == n/2 )
			{
				int j=i+1;
				while ( !hashtable[j] )
				{
					j++;
				}
				double median = double(i + j)/2.0;
				cout << "The median: " << median << endl;
			}
			else if ( count>n/2 && count-hashtable[i]<n/2 )
			{
				cout << "The median: " << i << endl;
			}
		}
	}
	else
	{
		for ( int i=0; i<m+1; i++ )
		{
			count += hashtable[i];
			if ( count >= (n+1)/2 && count-hashtable[i]<(n+1)/2 )
			{
				cout << "The median: " << i << endl;
			}
		}
	}

	int mode = 0;
	int modeFreq = 0;
	for ( int i=0; i<m+1; i++ )
	{
		if ( hashtable[i] > modeFreq )
		{
			modeFreq = hashtable[i];
			mode = i;
		}
	}
	cout << "The mode: " << mode << ", frequency: " << modeFreq << endl;

	for ( int i=0; i<m+1; i++ )
	{
		if ( hashtable[i] )
		{
			cout << i << ", frequency=" << hashtable[i] << endl;
		}
	}
}

int main()
{
	const int n = 8;
	int A[n] = {5,2,5,7,6,1,12,15};
	printFreq( A, n );

	system("pause");
	return 0;
}