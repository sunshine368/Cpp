// Merge n sorted arrays.
// keywords: sorting, minheap

#include <iostream>
using namespace std;


// Time complexity: O(M*n) where M is the total number of elements and n is the number of arrays
// Space complexity: O(1)
void mergeNSortedArrays( int **A, int n, int *size, int *M  )
{
    int *pt = (int*)malloc( sizeof(int)*n );
    int sum = 0;
    for ( int i=0; i<n; i++ )
    {
        pt[i] = size[i]-1;
        sum += size[i];
    }
    
    int pos = sum-1;
    while ( pos>=0 )
    {
        int max = 0;
        int index = 0;
        for ( int i=0; i<n; i++ )
        {
            if ( pt[i]>=0 )
            {
                if ( A[i][pt[i]]>max )
                {
                    max = A[i][pt[i]];
                    index = i;
                }
            }
        }
        M[pos--] = A[index][pt[index]];
        pt[index]--;
    }
}


// minimum heap method
// http://www.careercup.com/question?id=14944921


int main()
{
    int n = 4;
    int *size = (int*)malloc( sizeof(int)*n );
    size[0] = 5; size[1] = 6; size[2] = 5; size[3] = 2;
    
    int sum = 0;
    for ( int i=0; i<n; i++ )
        sum += size[i];
    int *M = (int*)malloc( sizeof(int)*sum );
    
    int **A = (int**)malloc( sizeof(int*)*n );
    for ( int i=0; i<n; i++ )
    {
        A[i] = (int*)malloc( sizeof(int)*size[i] );
    }
    A[0][0] = 1, A[0][1] = 2, A[0][2] = 5, A[0][3] = 74, A[0][4] = 344;
    A[1][0] = 1, A[1][1] = 8, A[1][2] = 12, A[1][3] = 33, A[1][4] = 90, A[1][5] = 95;
    A[2][0] = 9, A[2][1] = 12, A[2][2] = 17, A[2][3] = 20, A[2][4] = 91;
    A[3][0] = 1, A[3][1] = 3;
    
    mergeNSortedArrays( A, n, size, M );
    
    for ( int i=0; i<sum; i++ )
        cout << M[i] << " ";
    cout << endl;
    
    return 0;
}