// Given a sorted array which has been rotated, find the point of rotation, i.e., 
// the index of the minimum. 
// Time complexity: O(lg(n)).

#include <iostream>
using namespace std;

int findPointOfRotationAux( int *A, int n, int left, int right )
{
	if ( A[left]<A[right] )
		return left;

	if ( left==right )
		return left;

	int mid = (left+right)/2;
	if ( A[mid]>A[mid+1] )
		return mid+1;
	else if ( A[left]<A[mid] )
		return findPointOfRotationAux( A, n, mid+1, right );
	else if ( A[mid]<A[right] )
		return findPointOfRotationAux( A, n, left, mid );
}

int findPointOfRotation( int *A, int n )
{
    return findPointOfRotationAux( A, n, 0, n-1 );
}

int main()
{
    const int n = 11;
	int A[n] = {4,5,6,7,8,9,10,11,12,1,3};
	int begin = findPointOfRotation( A, n );
	cout << begin << endl;
	system("pause");
    return 0;
}