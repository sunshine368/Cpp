// Given an array of integers, find the index to the left of which the sum of the elements 
// is equal to that of the elements to the right.

#include <iostream>
using namespace std;

int findBalanceIndex( int *A, int n )
{
	int sum = 0;
	for ( int i=0; i<n; i++ )
	{
		sum += A[i];
	}

	int leftsum = 0;
	int index = 0;
	int rightsum = sum;
	while ( index < n )
	{
		rightsum = sum - A[index] - leftsum;
		if ( rightsum == leftsum )
		{
			break;
		}
		leftsum += A[index];
		index++;
	}

	return index;
}

int main()
{
	const int n = 8;
	int A[n] = {1,2,3,4,5,6,2,2};
	int index = findBalanceIndex( A, n );

	if ( index == n )
	{
		cout << "The array cannot be divided in balance.\n";
	}
	else
	{
		cout << "The array can be divided into two parts with equal sum at index: " << index << endl;
	}

	system("pause");
	return 0;
}