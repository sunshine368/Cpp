

#include <iostream>
using namespace std;

// Given an unsorted array of length n containing 1 to n except that one number is
// replaced by another, find the missing number and the repeating number.
// For example, in {1,9,3,4,5,6,7,8,9,10}, 2 is missing and 9 is repeating.
void findMissingNumber( int *A, int n )
{
    int sum = 0;
    int stdSum = 0;
    for ( int i=0; i<n; i++ )
    {
        sum += A[i];
        stdSum += (i+1);
    }
    
    int sumOfSquare = 0;
    int stdSumOfSquare = 0;
    for ( int i=0; i<n; i++ )
    {
        sumOfSquare += A[i]*A[i];
        stdSumOfSquare += (i+1)*(i+1);
    }
    
    int r = 0.5*( sum - stdSum + (sumOfSquare - stdSumOfSquare)/(sum - stdSum) );
    int m = r - sum + stdSum;
    
    cout << "The repeating number is " << r << endl;
    cout << "The missing number is " << m << endl;
}

// Given an unsorted array of length n containing 1 to n except that one number is
// replaced by another, find the missing number and the repeating number.
// For example, in {1,9,3,4,5,6,7,8,9,10}, 2 is missing and 9 is repeating.
void findMissingNumber2( int *A, int n )
{
    int *hashtable = (int*)malloc( sizeof(int)*n );
    for ( int i=0; i<n; i++ )
    {
        hashtable[i] = 0;
    }
    for ( int i=0; i<n; i++ )
    {
        if ( !hashtable[A[i]-1] )
            hashtable[A[i]-1]++;
        else
            cout << A[i] << " is repeating." << endl;
    }
}

// Given a sorted array of length n containing 1 to n except that one number is
// replaced by another, find the missing number and the repeating number.
void findMissingNumber3( int *A, int n )
{
    for ( int i=0; i<n; i++ )
    {
        if ( A[i]!=i+1 )
        {
            cout << i+1 << " is missing." << endl;
            cout << A[i] << " is repeating." << endl;
        }
    }
}

// Given an unsorted array of size n-1 containing elements from the set {1,...,n},
// find the missing number.
int findMissingNumber4( int *A, int n )
{
    int result = 0;
    for ( int i=0; i<n-1; i++ )
    {
        result ^= (i+1);
        result ^= A[i];
    }
    result ^= n;
    return result;
}

// Given an unsorted array of size n-1 containing elements from the set {1,...,n},
// find the missing number. You can read only one bit in one operation.
int findMissingNumber5( int *A, int n )
{
    int result = 0;
    int mask = 1;
    for ( int j=0; j<sizeof(int)*CHAR_BIT; j++ )
    {
        for ( int i=0; i<n-1; i++ )
        {
            result ^= mask&(i+1);
            result ^= mask&A[i];
        }
        result ^= mask&n;
        mask <<= 1;
    }
    return result;
}

int main()
{
    const int n = 10;
    int A[n] = {1,9,3,4,5,6,7,8,9,10};
    
    findMissingNumber( A, n );
    
    findMissingNumber2( A, n );
    
    findMissingNumber3( A, n );
    
    const int n2 = 10;
    int A2[n2] = {1,2,3,4,6,7,8,9,10};
    int result = findMissingNumber4( A2, n2-1 );
    cout << result << " is missing." << endl;
    
    int result2 = findMissingNumber5( A2, n2-1 );
    cout << result2 << " is missing." << endl;
    
    return 0;
}