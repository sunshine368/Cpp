// Given an array of integers which is first strictly increasing and then strictly decreasing,
// search the array for a given number.

#include <iostream>
using namespace std;

// Given an array which is first strictly increasing and then strictly decreasing, find 
// the peak of the array, i.e., the maximum number. Assume that there are at least three
// elements.
int findPeakAux( int *A, int i, int j ) 
{
	if ( i==j )
		return -1;

	int mid = (i+j)/2;
	if ( A[mid]>A[mid-1] && A[mid]>A[mid+1] )
	{
		return mid;
	}

	int n1 = findPeakAux( A, i, mid );
	if ( n1 != -1 )
		return n1;

	int n2 = findPeakAux( A, mid+1, j );
	if ( n2 != -1 )
		return n2;

	return -1;
}

int findPeak( int *A, int size )
{
	return findPeakAux( A, 0, size-1 );
}


// search for a given key in a strictly increasing array
int BinarySearchInc( int *A, int i, int j, int key )
{
	if ( key < A[i] || key > A[j] )
		return -1;

	if ( i==j )
	{
		if ( A[i]==key )
			return i;
		else
			return -1;
	}

	int mid = (i+j)/2;
	int index = -1;
	if ( A[mid] == key )
	{
		index = mid;
	}
	else if ( A[mid] > key )
	{
		index = BinarySearchInc( A, i, mid, key );
	}
	else
	{
		index = BinarySearchInc( A, mid+1, j, key );
	}

	return index;
}


// search for a given key in a strictly decreasing array
int BinarySearchDec( int *A, int i, int j, int key )
{
	if ( key > A[i] || key < A[j] )
		return -1;

	if ( i==j )
	{
		if ( A[i]==key )
			return i;
		else
			return -1;
	}

	int mid = (i+j)/2;
	int index = -1;
	if ( A[mid] == key )
	{
		index = mid;
	}
	else if ( A[mid] < key )
	{
		index = BinarySearchDec( A, i, mid, key );
	}
	else
	{
		index = BinarySearchDec( A, mid+1, j, key );
	}

	return index;
}

void searchInHill( int *A, int n, int key )
{
	int peak = findPeak( A, n );
	if ( peak==-1 )
		cout << "Array not as described\n";

	int ind1 = BinarySearchInc( A, 0, peak, key );
	int ind2 = BinarySearchDec( A, peak, n-1, key );
	if ( ind1==-1 && ind2==-1 )
		cout << "Not found!\n";
	else if ( ind1!=-1 && ind2!=-1 )
		cout << "Found at index: " << ind1 << " and " << ind2 << endl;
	else if ( ind1!=-1 && ind2==-1 )
		cout << "Found at index: " << ind1 << endl;
	else
		cout << "Found at index: " << ind2 << endl;
}

int main()
{
	const int n = 15;
	int A[n] = {1,3,5,7,19,221,132,56,8,6,4,2,1,-3,-17};
	int peak = findPeak( A, n );
	cout << peak << endl;

	const int m = 3;
	int B[m] = {1,3,2};
	int peak2 = findPeak( B, m );
	cout << peak2 << endl;

	int index1 = BinarySearchInc( A, 0, peak, 5 );
	cout << index1 << endl;

	int index2 = BinarySearchDec( A, 5, n-1, 56 );
	cout << index2 << endl;
	
	searchInHill( A, n, 56 );
	
	system("pause");
	return 0;
}