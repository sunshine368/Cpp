#include <iostream>
using namespace std;

void groupWords( char *A, int n )
{
	int alpha = 0;
	int special = 
}

int main()
{

}