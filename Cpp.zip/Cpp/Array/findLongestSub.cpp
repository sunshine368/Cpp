// Given an array of integers which may contain duplicates, find the largest subset of
// it which forms a continuous sequence.

#include <iostream>
using namespace std;

void findLongestSub( int *A, int n )
{
    int max = 0;
    for ( int i=0; i<n; i++ )
    {
        if ( A[i] > max )
        {
            max = A[i];
        }
    }
    
    int *hashtable = (int*)malloc( sizeof(int)*(max+1) );
    for ( int i=0; i<=max; i++ )
    {
        hashtable[i] = 0;
    }
    for ( int i=0; i<n; i++ )
    {
        hashtable[A[i]]++;
    }
    
    int max_sum = 0;
    int max_index = 0;
    int sum = 0;
    int index = 0;
    while ( index<=max )
    {
        while ( index<=max && hashtable[index]>=1 )
        {
            index++;
            sum++;
        }
        
        if ( sum > max_sum )
        {
            max_index = index-1;
            max_sum = sum;
        }
        sum = 0;
        
        while ( index<=max && hashtable[index]==0 )
        {
            index++;
        }
    }
    
    cout << "The longest subsequence is:\n";
    for ( int i=max_index - max_sum+1; i<=max_index; i++ )
    {
        cout << i << endl;
    }
}

int main()
{
    const int n = 7;
    int A[n] = {1,6,10,4,7,9,5};
    findLongestSub( A, n );
    
    return 0;
}