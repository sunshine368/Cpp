// Given two sorted arrays, A and B, B is shorter than A, and A has space for 
// all elements for B. Merger the two arrays so that all elements are sorted 
// and stored in A. No extra space allowed.

#include <iostream>
using namespace std;

void mergeTwoSortedArrays( int *A, int *B, int m, int n )
{
	int pos = m-1;
	int ptb = n-1;
	int pta = m-n-1;
	while ( ptb >= 0 )
	{
		if ( A[pta] > B[ptb] )
		{
			A[pos] = A[pta];
			pos--;
			pta--;
		}
		else
		{
			A[pos] = B[ptb];
			pos--;
			ptb--;
		}
	}
}

int main()
{
	const int m = 8;
	const int n = 4;
	int A[m] = {1,3,5,7};
	int B[n] = {2,4,6,8};
	mergeTwoSortedArrays( A, B, m, n );

	for ( int i=0; i<m; i++ )
		cout << A[i] << endl;

	system("pause");
	return 0;
}