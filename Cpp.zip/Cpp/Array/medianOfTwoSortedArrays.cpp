// Find the median of two sorted arrays.

#include <iostream>
using namespace std;

int medianOfTwoSortedArrays( int *A, int *B, int na, int nb )
{
    int last = (na+nb)/2;
    int pa = 0;
    int pb = 0;
    for ( int i=0; i<=last; i++ )
    {
        if ( A[pa]>B[pb] )
            pb++;
        else
            pa++;
    }
    
    int median = 0;
    if ( (na+nb)%2==0 )
    {
        if ( A[pa-1]>=B[pb-1] && A[pa-2]>=B[pb-1] )
            median = (A[pa-1]+A[pa-2])/2;
        else if ( A[pa-1]>=B[pb-1] && B[pb-1]>=A[pa-2] )
            median = (A[pa-1]+B[pb-1])/2;
        else if ( B[pb-1]>=A[pa-1] && B[pb-2]>=A[pa-1] )
            median = (B[pb-1]+B[pb-2])/2;
        else if ( B[pb-1]>=A[pa-1] && A[pb-1]>=B[pb-2] )
            median = (B[pb-1]+A[pb-1])/2;
    }
    else
    {
        if ( A[pa-1]>B[pb-1] )
            median = A[pa-1];
        else
            median = B[pb-1];
    }
    
    return median;
}

int main()
{
    const int na = 3, nb = 4;
    int A[na] = {1,5,10};
    int B[nb] = {2,3,8,12};
    int result = medianOfTwoSortedArrays(A, B, na, nb);
    cout << result << endl;
    
    const int na2 = 4, nb2 = 4;
    int A2[na2] = {1,5,7,10};
    int B2[nb2] = {2,3,8,12};
    int result2 = medianOfTwoSortedArrays(A2, B2, na2, nb2);
    cout << result2 << endl;
    
    return 0;
}