// Given an array which contains only 0 and 1, sort the array such that all 0's 
// are before all 1's.

#include <iostream>
using namespace std;


// Time complexity: O(n)
// Space complexity: O(1)
void sortArrayOfZeroOne( int *A, int n )
{
	int first = 0;
	int second = n-1;
	while ( first < second )
	{
		if ( A[first] == 0 )
		{
			first++;
		}
		else
		{
			if ( A[second] == 0 )
			{
				A[first] = 0;
				A[second] = 1;
				first++;
				second--;
			}
			else
			{
				second--;
			}
		}
	}
}


// Time complexity: O(n^2)
// Space complexity: O(1)
// constraint: You can swap only the adjacent elements in the array.
// Find the minimum number of swaps required to sort the array.
// Minimum number of swaps = the sum of the number of 0's to the right of each 1
void sortArrayOfZeroOne2( int *A, int n )
{
	int first = n-1; // the first 1 before the first 0 from the right
	int second = n-1; // the first 0 from the right
	while ( A[second]==1 )
	{
		second--;
	}
	if ( second<=0 )
		return;

	first = second;
	while ( first>=0 )
	{		
		while ( A[first]==0 )
		{
			first--;
			if ( first<0 )
				return;
		}
		for ( int i=first; i<=second-1; i++ )
		{
			swap( A[i], A[i+1] );
		}
		second--;
	}
}


int main()
{
	const int n = 8;
	int A[n] = {1,0,1,0,1,0,0,1};
	sortArrayOfZeroOne( A, n );

	for ( int i=0; i<n; i++ )
	{
		cout << A[i] << " ";
	}
	cout << endl;

	const int n2 = 8;
	int A2[n2] = {1,0,1,0,1,0,0,1};
	sortArrayOfZeroOne2( A2, n2 );

	for ( int i=0; i<n2; i++ )
	{
		cout << A2[i] << " ";
	}
	cout << endl;

	const int n3 = 9;
	int A3[n3] = {0,1,0,1,0,1,0,0,1};
	sortArrayOfZeroOne2( A3, n3 );

	for ( int i=0; i<n3; i++ )
	{
		cout << A3[i] << " ";
	}
	cout << endl;

	const int n4 = 9;
	int A4[n4] = {0,1,0,1,0,1,0,0,0};
	sortArrayOfZeroOne2( A4, n4 );

	for ( int i=0; i<n4; i++ )
	{
		cout << A4[i] << " ";
	}
	cout << endl;

	system("pause");
	return 0;
}