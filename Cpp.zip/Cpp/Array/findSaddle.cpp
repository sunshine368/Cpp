// Given a matrix, find all the numbers such that each one is the maximum in the same row
// and the minimum in the same column.

#include <iostream>
using namespace std;

const int row = 4, col = 6;

void findSaddle( int A[row][col] )
{
	int max[row] = {0};
	int maxElem;
	int index = 0;
	for ( int i=0; i<row; i++ )
	{
		maxElem = A[i][0];
		for ( int j=0; j<col; j++ )
		{
			if ( A[i][j]>maxElem ) 
			{
				index = j;
				maxElem = A[i][j];
			}
		}
		max[i] = index;
	}

	int min[col] = {0};
	int minElem;
	index = 0;
	for ( int j=0; j<col; j++ )
	{
		minElem = A[0][j];
		for ( int i=0; i<row; i++ )
		{
			if ( A[i][j]<minElem )
			{
				index = i;
				minElem = A[i][j];
			}
		}
		min[j] = index;
		if ( max[index]==j )
			cout << "A[" << index << "][" << j << "] is a saddle point.\n";
	}
}

int main()
{
	int A[row][col] = {{18,1,5,6,3,12},{25,3,11,8,15,7},{36,10,22,2,21,20},{40,19,17,16,42,45}};
	findSaddle( A );

	system("pause");
	return 0;
}