/*
Find the minimum element in a stack in O(1) time complexity and O(n) 
space complexity.
Method: add a component "min" to the Node structure.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node 
{
	int value;
	Node *next;
	int min;
};

Node *BuildStack()
{
	Node *stack = 0;
	return stack;
}

bool Push( Node **stack, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	if ( *stack==0 )
	{
		new_head->value = data;
		new_head->next = 0;
		new_head->min = data;
	}
	else
	{
		new_head->value = data;
		new_head->next = *stack;
		if ( data < (*stack)->min )
			new_head->min = data;
		else
			new_head->min = (*stack)->min;
	}
	*stack = new_head;
	return true;
}

int Pop( Node **stack )
{
	int data = (*stack)->value;
	Node *temp = *stack;
	*stack = (*stack)->next;
	delete temp;
	return data;
}

int Top( Node *stack )
{
	return stack->value;
}

bool isEmpty( Node *stack )
{
	if ( stack==0 )
		return true;
	else
		return false;
}

int FindMin( Node *stack )
{
	return stack->min;
}

int PopMin( Node **stack )
{
	int temp = (*stack)->min;
	Node *tobedeleted = *stack;
	*stack = (*stack)->next;
	delete tobedeleted;
	return temp;
}

void Display( Node **stack )
{
	if ( isEmpty(*stack) )
	{
		cout << endl;
		return;
	}
	int temp = Pop( stack );	
	cout << temp << " ";
	Display( stack );
	Push( stack, temp );
}

int main()
{
	Node *stack = BuildStack();
	int n;
	cout << "Enter n:\n";
	cin >> n;
	for ( int i=0; i<n; ++i )
		Push( &stack, rand()%100 );

	cout << "The list:\n";
	Display( &stack );

	int result = FindMin( stack );
	cout << "The minimum:\n";
	cout << result << endl;

	system("pause");
	return 0;
}