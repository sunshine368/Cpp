// Implement enqueue and dequeue operations using stack(s).

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

Node *BuildStack()
{
	Node *stack = 0;
	return stack;
}

bool isEmpty( Node *stack )
{
	return stack==0;
}

bool Push( Node **stack, int data )
{
	Node *new_head = new Node;
	if ( !new_head )
		return false;

	new_head->value = data;
	new_head->next = *stack;
	*stack = new_head;
	return true;
}

int Pop( Node **stack )
{
	int data = (*stack)->value;
	Node *temp = *stack;
	*stack = (*stack)->next;
	delete temp;
	return data;
}

int Top( Node *stack )
{
	return stack->value;
}

void Display( Node **stack )
{
	if ( isEmpty(*stack) )
	{
		cout << endl;
		return;
	}
	int temp = Pop( stack );
	cout << temp << " ";
	Display( stack );
	Push( stack, temp );
}

Node **BuildQueue()
{
	Node **queue = (Node**)malloc( sizeof(Node*)*2 );
	queue[0] = 0;
	queue[1] = 0;
	return queue;
}

bool Enqueue( Node **queue, int data )
{
	return Push( &queue[0], data );
}

int Dequeue( Node **queue )
{
	if ( queue[1]==0 )
	{
		while ( queue[0]!=0 )
		{
			int temp = Pop( &queue[0] );
			Push( &queue[1], temp );
		}
		return Pop( &queue[1] );
	}
	else
	{
		return Pop( &queue[1] );
	}
}

int main()
{
	Node *stack = BuildStack();
	int n;
	cout << "Enter n:\n";
	cin >> n;
	srand(time(NULL));
	for ( int i=0; i<n; ++i )
		Push( &stack, rand()%100 );

	cout << "The stack:\n";
	Display( &stack );

	Node **queue = BuildQueue();
	int n2;
	cout << "Enter n:\n";
	cin >> n2;
	for ( int i=0; i<n2; ++i )
	{
		int temp = rand()%100;
		cout << temp << endl;
		Enqueue( queue, temp );
	}

	cout << "Dequeue one element:\n";
	int result = Dequeue( queue );
	cout << result << endl;

	int n3;
	cout << "Enter n:\n";
	cin >> n3;
	for ( int i=0; i<n3; ++i )
	{
		int temp = rand()%100;
		cout << temp << endl;
		Enqueue( queue, temp );
	}

	cout << "Dequeue one more element:\n";
	int result2 = Dequeue( queue );
	cout << result2 << endl;

	int n4;
	cout << "Enter n:\n";
	cin >> n4;
	cout << "Dequeue " << n4 << " more elements:\n";
	for ( int i=0; i<n4; ++i )
	{
		int temp = Dequeue( queue );
		cout << temp << endl;
	}

	system("pause");
	return 0;
}