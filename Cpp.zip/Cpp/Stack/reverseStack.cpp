#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *next;
};

// create an empty stack
Node *BuildStack()
{
	Node *stack = 0;
	return stack;
}

// insert a new element into the stack
bool Push( Node **stack, int data )
{
	Node *new_elem = new Node;
	if ( !new_elem )
		return false;

	new_elem->value = data;
	new_elem->next = *stack;
	*stack = new_elem;
	return true;
}

// check if a stack is empty
bool isEmpty( Node *stack )
{
	return stack==0;
}

// return the top element and then delete it from the stack
int Pop( Node **stack )
{
	int data = (*stack)->value;
	Node *temp = *stack;
	*stack = (*stack)->next;
	delete temp;
	return data;
}

// return the top element of the stack
int Top( Node *stack )
{
	return stack->value;
}

void Display( Node *stack )
{
	while ( !isEmpty(stack) )
	{
		cout << stack->value << " ";
		stack = stack->next;
	}
	cout << endl;
}

// Reverse a stack without using extra stack.
void InsertAtBack( Node **stack, int data )
{
	if ( isEmpty(*stack) )
	{
		Push( stack, data );
		return;
	}
	int temp = Pop( stack );
	InsertAtBack( stack, data );
	Push( stack, temp );
}

void ReverseStack( Node **stack )
{
	if ( isEmpty(*stack) )
		return;

	int temp = Pop( stack );
	ReverseStack( stack );
	InsertAtBack( stack, temp );
}

int main()
{
	Node *stack = BuildStack();
	int n;
	cout << "Enter n:\n";
	cin >> n;
	srand(time(NULL));
	for ( int i=0; i<n; ++i )
		Push( &stack, rand()%100 );

	cout << "The stack:\n";
	Display( stack );

	ReverseStack( &stack );

	cout << "After reversing:\n";
	Display( stack );

	system("pause");
	return 0;
}