/*
Main idea:
The quicksort is based on divide-and-conquer technique.

Divide: Given an array A[p,...,r], we choose a key element k which is called 
the pivot or bound. Partition the array into two (possibly empty) subarrays 
A[p,...,q-1] and A[q+1,...,r] such that each element of A[p,...,q-1] is less 
than or equal to A[q]=k, and each element of A[q+1,...,r] is greater than or 
equal to A[q]=k. Compute the index q as part of this partitioning procedure. 

Conquer: Sort the two subarrays A[p,...,q-1] and A[q+1,...,r] by recursive 
calls to quicksort.

Combine: Because the subarrays are already sorted, no work is needed to combine 
them: the entire array A[p,...,r] is now sorted.

Note that it is inappropriate to use quicksort for small arrays. For arrays 
with fewer than ten items, insertion sort is more efficient than quicksort. 

Pseudo-code:
Quick-Sort-I( A[0,...,n-1], n )
	Quick-Sort-I-Helper( A[], 0, n-1 )

Quick-Sort-I-Helper( A[], start, end )
	if start < end
	    q = Partition-I( A[], start, end )
	    Quick-Sort-I-Helper( A[], start, q-1 )
	    Quick-Sort-I-Helper( A[], q+1, end )

Partition-I( A[], first, last )
	pivot = A[last] // use the last element as the pivot
	low = first-1
	for ( i=first; i<last; i++ )
	    if A[i]<pivot 
	        if i!=low+1
	            swap( A[i], A[++low] )
	        else
	            low++
	swap( A[low+1], A[last] )        
	return low+1

------------------------------------------------------------
Quick-Sort-II( A[0,��,n-1], n )
1	Quick-Sort-II-Helper( A[], 0, n-1 )

Quick-Sort-II-Helper( A[], start, end )
1	if start<end
2	    m = Partition-II( A[], start, end )
3	    Quick-Sort-II-Helper( A[], start, m-1 )
4	    Quick-Sort-II-Helper( A[], m+1, end )

Partition-II( A[], first, last )
1	swap A[first] with A[(first+last)/2]
2	pivot = A[first]
3	low = first+1
4	high = last
5	while low<=high
6	    while A[low]<pivot
7	        low++
8	    while A[high]>pivot
9	        high��
10	    if low<high
11	        swap A[low] and A[high]
12	swap A[high] and A[first]

Time complexity: O(n^2) (worst case); O(nlog(?n)) (average case).
*/

#include <iostream>
#include <ctime>
using namespace std;

// Use the last element as the pivot.
int PartitionI( int A[], int first, int last )
{
	int pivot = A[last];
	int low = first - 1;
	for ( int i=first; i<last; i++ )
	{
		if ( A[i]<pivot )
		{
			if ( i!=low+1 )
				swap( A[i], A[++low] );
			else
				low++;
		}
	}
	swap( A[low+1], A[last] );
	return low+1;
}

void QuickSortIAux( int A[], int start, int end )
{
	if ( start<end )
	{
		int q = PartitionI( A, start, end );
		QuickSortIAux( A, start, q-1 );
		QuickSortIAux( A, q+1, end );
	}
}

void QuickSortI( int A[], int n )
{
	QuickSortIAux( A, 0, n-1 );
}

// Use the middle element as the pivot.
int PartitionII( int A[], int first, int last )
{
	swap( A[first], A[(first+last)/2] );
	int pivot = A[first];
	int low = first + 1;
	int high = last;
	while ( low<=high )
	{
		while ( A[low]<=pivot )
		{
			low++;
		}
		while ( A[high]>pivot )
		{
			high--;
		}
		if ( low<high )
			swap( A[low], A[high] );
	}
	swap( A[high], A[first] );
	return high;
}

void QuickSortIIAux( int A[], int start, int end )
{
	if ( start<end )
	{
		int m = PartitionII( A, start, end );
		QuickSortIIAux( A, start, m-1 );
		QuickSortIIAux( A, m+1, end );
	}
}

void QuickSortII( int A[], int n )
{
	QuickSortIIAux( A, 0, n-1 );
}


int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));
	int *A = (int*)malloc( sizeof(int)*n );

	// QuickSortI
	for ( int i=0; i<n; i++ )
		A[i] = rand()%100;

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	QuickSortI( A, n );

	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl << endl;

	// QuickSortII
	for ( int i=0; i<n; i++ )
		A[i] = rand()%100;

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	QuickSortII( A, n );

	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}