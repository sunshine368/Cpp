/*
Main idea:
Merge sort is based on divide-and-conquer technique. The key process in 
merge sort is merging sorted halves of an array into one sorted array. 
These halves have to be sorted first, which is accomplished by merging 
the already sorted halves of these halves. The process of dividing arrays 
into two halves stops when the array has fewer than two elements. 

The implementation of merge sort is recursive in nature. The recursion 
step splits a vector of two or more elements into two equal-sized sub 
vectors (or one sub vector has one more element than the other), recursively 
sorts each sub vector, and then merges them into one larger, sorted vector. 
The base case is a vector with one element. A one-element vector is sorted, 
so merge sort immediately returns when it is called with a one-element vector. 

Improving merge sort:

1. Merge sort can be made more efficient by replacing recursion with 
iteration or by applying insertion sort to small portions of an array.

2. Merge sort has one serious drawback: the need for additional storage 
for merging arrays, which could be an insurmountable obstacle for large 
amounts of data. One solution to this drawback is to use a linked list.

Pseudo-code:
Merge-Sort( A[0,��,n-1], first, last )
	let temp[0,��,n-1] be a new array
	if first<last
	    mid = (first+last)/2
	    Merge-Sort( A[], first, mid )
	    Merge-Sort( A[], mid+1, last )
	    Merge( A[], first, last, temp[] )

Merge( A[], first, last, temp[] )
	mid = (first+last)/2
	index = first, left = first, right = mid+1
	while left<=mid and right<=last
	    if A[left]<A[right]
	        temp[index++] = A[left++]
	    else
	        temp[index++] = A[right++]
	if left==mid+1
	    while ( right<=last )
	        temp[index++] = A[right++]
	else
	    while ( left<=mid )
	        temp[index++] = A[left++]
	for i=first to last
	    A[i] = temp[i]

Time complexity: O(n log?n) for all cases.
*/

#include <iostream>
using namespace std;

void merge( int *A, int n, int first, int last, int *temp )
{
	int i = first;
	int left = first;
	int mid = (first+last)/2;
	int right = mid + 1;

	while ( left<=mid && right<=last )
	{
		if ( A[left]<=A[right] )
			temp[i++] = A[left++];
		else
			temp[i++] = A[right++];
	}

	if ( left==mid+1 )
	{
		while ( right<=last )
			temp[i++] = A[right++];
	}
	else
	{
		while ( left<=mid )
			temp[i++] = A[left++];
	}

	for ( int i=first; i<=last; i++ )
		A[i] = temp[i];
}

void mergeSortAux( int *A, int n, int first, int last, int *temp )
{
	if ( first==last )
		return;
	int mid = (first+last)/2;
	mergeSortAux( A, n, first, mid, temp );
	mergeSortAux( A, n, mid+1, last, temp );
	merge( A, n, first, last, temp );
}

void mergeSort( int *A, int n )
{
	int *temp = (int*)malloc( sizeof(int)*n );
	mergeSortAux( A, n, 0, n-1, temp );
}

int main()
{
	const int n = 10;
	int A[n] = {30,47,22,67,79,18,60,78,26,54};
	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;
	mergeSort( A, n );
	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;
	system("pause");
	return 0;
}