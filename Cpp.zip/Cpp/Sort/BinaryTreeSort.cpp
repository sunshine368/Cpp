/*
Binary Search Tree Sort:
Time complexity: O(nlog(n)) for the worst case.
*/

#include <iostream>
#include <ctime>
using namespace std;

struct Node
{
	int value;
	Node *leftChild; // (1) cannot be initialized to any value
	Node *rightChild;
};

void InsertNode( Node **ptr, int data )
{
	if ( (*ptr)==0 )
	{
		*ptr = (Node*)malloc( sizeof(Node) );
		(*ptr)->value = data;
		(*ptr)->leftChild = 0;
		(*ptr)->rightChild = 0;
	}
	else
	{
		if ( data <= (*ptr)->value )
		{
			InsertNode( &((*ptr)->leftChild), data );
		}
		else
		{
			InsertNode( &((*ptr)->rightChild), data );
		}
	}
}

void InOrderTraverse( Node *ptr, int A[], int *count )
{
	if ( ptr!=0 )
	{
		InOrderTraverse( ptr->leftChild, A, count );
		++(*count);
		A[(*count)] = ptr->value;
		InOrderTraverse( ptr->rightChild, A, count );
	}
}

void BSTSort( int A[], int n )
{
	Node *root = 0;
	for ( int i=0; i<n; i++ )
	{
		InsertNode( &root, A[i] );
	}

	int temp = -1;
	int *count = &temp;
	InOrderTraverse( root, A, count );
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));
	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; i++ )
		A[i] = rand()%100;

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	BSTSort( A, n );

	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}