/*
Main idea:
The first iteration of the algorithm selects the smallest element in the array 
and swaps it with the first element. The second iteration selects the second 
smallest element (which is the smallest element of the remaining elements) and 
swaps it with the second element. The algorithm continues until the last iteration 
which selects the second greatest element and swaps it with the second-to-last 
element, leaving the greatest element at the end of the array. After the ith 
iteration, the first i smallest items of the array will be sorted in increasing 
order in the first i positions of the array.

Pseudo-code:
Selection-Sort( A[0,��,n-1], n )
	for i=0 to n-1
	    temp = i
	    for ( j=i+1; j<n; j++ )
	        if A[j]<A[temp]
	            temp = j
	    swap A[i] and A[temp] if they are not equal

Time complexity: O(n^2) for all cases.
*/

#include <iostream>
#include <ctime>
using namespace std;

void SelectionSort( int A[], int n )
{
	int min;
	int j;
	for ( int i=0; i<n; i++ )
	{
		min = i;
		for ( j=i+1; j<n; j++ )
		{
			if ( A[min]>A[j] )
				min = j;
		}
		if ( min != i )
			swap( A[min], A[i] );
	}
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));

	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; i++ )
		A[i] = rand()%100;

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	SelectionSort( A, n );

	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}