/*
Main idea:
Given an array a[] of n elements, we want to sort the elements in increasing order.
First, divide the array into h[t] subarrays such that
1st subarray contains: a[0],a[h[t]],...,a[h[t]*i],...,i=0,1,...
2nd subarray contains: a[1],a[h[t]+1],...,a[h[t]*i+1],...,i=0,1,...
...
h[t]th subarray contains: a[h[t]-1],a[2h[t]-1],...,a[h[t]*i+h[t]-1],...,i=0,1,...
Sort each subarray separately. 
Then, divide the array into h[t-1] subarrays where h[t-1]<h[t] and again sort each 
subarray. The procedure is conducted until h[1]=1 where we sort the whole array.

Three features of this algorithm that may vary from one implementation to another:
1. The sequence of increments, h[1], h[2], ..., h[t]. Empirical studies along with 
some theoretical considerations suggest that h[i+1]=3*h[i]+1 where h[1]=1.
2. A simple sorting algorithm applied in all passes except the last one.
3. A simple sorting algorithm applied only in the last pass, for h[1]=1.

Pseudo-code:
Shell-Sort( A[0,...,n-1], n )
	determine the sequence of increments, h[1], ..., h[count-1]
	for ( i=count-1; i>=0; i-- )	
	divide A[] into h[i] subarrays
	for ( j=1; j<=h[i]; j++ )
	    Sort the j-th subarray

Shell-Sort( A[0,...,n-1], n )
	count = 0
	h = 1
	while h<n
	    h = 3*h + 1
	    count++
	let H[0,...,count-1] be a new array
	H[0] = 1
	for i=1 to count-1
	    H[i] = 3*H[i-1] + 1
	for i=count-1 to 0
	    h = H[i]
	    for j=0 to h-1
	        for (k=j+h; k<n; k+=h)
	            temp = A[k]
	            cur = k
	            while ( cur>=h && A[cur-h]>temp )
	                A[cur] = A[cur-h]
	                cur -= h
	            A[cur] = temp

Time complexity: between O(n lg?n) and O(n^2).
*/

#include <iostream>
#include <ctime>
using namespace std;

void ShellSort( int A[], int n )
{
	int h=1;
	int count = 0;
	while ( h<n )
	{
		h = 3*h + 1;
		count++;
	}

	int *H = (int*)malloc( sizeof(int)*count );
	H[0] = 1;
	for ( int i=1; i<count; i++ )
	{
		H[i] = 3*H[i-1] + 1;
	}

	for ( int i=count-1; i>=0; i-- )
	{
		h = H[i];
		for ( int j=0; j<h; j++ )
		{
			for ( int k=j+h; k<n; k+=h )
			{
				int temp = A[k];
				int cur = k;
				while ( cur>=h && A[cur-h]>temp )
				{
					A[cur] = A[cur-h];
					cur -= h;
				}
				A[cur] = temp;
			}
		}
	}
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));

	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; i++ )
		A[i] = rand()%100;

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	ShellSort( A, n );

	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}