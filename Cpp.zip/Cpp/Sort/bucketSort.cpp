/*
Main idea:
Given an array of n positive integers to be sorted, construct a two-dimensional 
array of integers with rows subscripted from 0 to 9 and columns subscripted from 
0 to n-1, which is called bucket. Each row of the array and the array size as 
arguments and performs as follows:

(1). Place each element of the one-dimensional array into a row of the bucket 
array based on the value��s ones digit. For example, 97 is placed in row 7, 3 
is placed in row 3 and 100 is placed in row 0. This is called a ��distribution pass��.

(2). Loop through the bucket array row by row, and copy the values back to the 
original array. This is called a ��gathering pass��. The new order of the preceding 
values in the one-dimensional array is 100, 3, and 97.

(3). Repeat the process for each subsequent digit position (tens, hundreds, 
thousands, etc). For example, on the second pass, 100 is placed in row 0, 3 is 
placed in row 0, and 97 is placed in row 9. After the gathering pass, the order 
of the values in the one-dimensional array is 100, 3, and 97. One the third pass, 
100 is placed in row 1, 3 is placed in row zero, and 97 is placed in row zero. 
After the last gathering pass, the original array is now in sorted order.

Note that the two-dimensional array of buckets is 10 times the size of the integer 
array being sorted. This sorting technique provides better performance than an 
insertion sort, but requires much more memory. The insertion sort requires space 
for only one additional element of data. This is an example of the space-time 
trade-off: The bucket sort uses more memory than the insertion sort, but performs 
better. This version of the bucket sort requires copying all the data back to the 
original array on each pass. Another possibility is to create a second two-dimensional 
bucket array and repeatedly swap the data between the two bucket arrays.

Pseudo-code:
Bucket-Sort( A[], n ):
width = number of digits of the greatest element 
let bucket[0...9,0...n-1] be a new matrix
let count[0...n-1] be a new array
for i=1 to width
    for j=0 to n-1
        distribute A[j] to bucket[] based on the ith-digit-from-the-right
    collect the elements from bucket[] to A[j]
    clear bucket[]

Bucket-Sort( A[0,��,n-1], n )
1	max = A[0]
2	for i=1 to n-1
3	    if A[i]>max
4	        max = A[i]
5	width = 0
6	while max!=0
7	    width++
8	    max=max/10
9	let bucket[0,��,9;0,��,n-1] be a new matrix with all elements initialized to 0
10	let count[0,��,9] be a new array with all elements initialized to 0
11	tens = 10
12	for i=1 to width
13	    for j=0 to n-1
14	        bucket[A[j]%tens/(tens/10)][(count[A[j]%tens/(tens/10)])++] = A[j]
15	    num = 0
16	    for j=0 to 9
17	        for k=0 to count[j]-1
18	            A[num++] = bucket[j][k]
19	    for j=0 to 9
20	        count[j] = 0
21	    tens *= 10

Time complexity: O(mn) for all cases where n is the number of elements and m is 
the number of digits of the greatest element.
*/

#include <iostream>
#include <ctime>
using namespace std;

void BucketSort( int A[], int n )
{
	int max = A[0];
	for ( int i=1; i<n; i++ )
	{
		if ( A[i]>max )
			max = A[i];
	}

	int width = 0;
	while ( max!=0 )
	{
		width++;
		max /= 10;
	}

	int **bucket = (int**)malloc( sizeof(int*)*10 );
	for ( int i=0; i<10; i++ )
	{
		bucket[i] = (int*)malloc( sizeof(int)*n );
		for ( int j=0; j<n; j++ )
			bucket[i][j] = 0;
	}

	int *count = (int*)malloc( sizeof(int)*10 );
	for ( int i=0; i<10; i++ )
		count[i] = 0;
	
	int tens = 10;
	for ( int i=0; i<width; i++ )
	{
		for ( int j=0; j<n; j++ )
		{
			bucket[A[j]%tens/(tens/10)][ ( count[ A[j]%tens / (tens/10) ] )++ ] = A[j];
		}
		int num = 0;
		for ( int j=0; j<10; j++ )
		{
			for ( int k=0; k<count[j]; k++ )
			{
				A[num++] = bucket[j][k];
			}
		}
		for ( int j=0; j<10; j++ )
			count[j] = 0;
		tens *= 10;
	}
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));

	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; i++ )
	{
		A[i] = rand()%100;
	}

	cout << "Before sorting;\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl << endl;

	BucketSort( A, n );

	cout << "After sorting;\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl << endl;

	system("pause");
	return 0;
}