/*
Main idea: 
Given an array of n data, we want to sort it in increasing order. 

First, compare data[n-1] with data[n-2] , and swap them if they are out of 
order (i.e., data[n-1]<data[n-2]). Next, compare data[n-2] and data[n-3], 
and swap them if they are out of order. Keep on doing this up to data[0] 
and data[1]. In this way, data[0] is the smallest element. This is the first 
pass through the array. 

For the second pass through the array, we first compare data[n-1] and data[n-2], 
then data[n-2] and data[n-3], and so on up to data[1] and data[2]. After the 
second pass, data[0] is the smallest and data[1] is the second smallest.

Keep on scanning the array, comparing consecutive elements and swapping them 
if necessary. The procedure continues until the last pass which involves only 
one comparison, data[n-1] and data[n-2], and possibly one swap.

Pseudo-code:
Bubble-Sort( A[0,...,n-1], n )
	for i=0 to n-2
	    for j=n-1 to i+1
	        if A[j]<A[j-1]
	            swap A[j] and A[j-1]

Time complexity: O(n^2) in all cases. 3/2 n(n-1) swaps for worst case; 
3/4 n(n-1) swaps for average case; no swap for best case.
*/

#include <iostream>
#include <ctime>
using namespace std;

void BubbleSort( int A[], int n )
{
	for ( int i=0; i<n-1; i++ )
	{
		for ( int j=n-1; j>i; j-- )
		{
			if ( A[j]<A[j-1] )
				swap( A[j], A[j-1] );
		}
	}
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));
	int *A = (int*)malloc( sizeof(int)*n );
	for ( int i=0; i<n; i++ )
		A[i] = rand()%100;

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	BubbleSort( A, n );

	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}