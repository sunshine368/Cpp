/*
Main idea:
The first iteration of this algorithm takes the second element and, if it is 
less than the first element, swaps it with the first element (i.e., the program 
inserts the second element in front of the first element). The second iteration 
looks at the third element and inserts it into the correct position with respect 
to the first two elements, so all three elements are in order. Right before the 
ith iteration, the first i-1 elements are already sorted in increasing order. 
During the ith iteration, the ith element is compared to the elements ahead of 
it and is swapped with the element if it is greater than the ith element. The 
iteration works backwards.

Pseudo-code:
Insertion-Sort( A[0,��,n-1], n )
1	for i=1 to n-1
2	    temp = A[i]
3	    j = i-1
4	    while ( j>=0 && A[j]>temp )
5	        A[j+1] = A[j]
6	        j--
7	    A[j+1] = temp

Time complexity: O(n^2) for the worst and average cases; O(n) for the best case.
*/

#include <iostream>
#include <ctime>
using namespace std;

void InsertSort1( int A[], int n )
{
	int temp;
	int j;
	for ( int i=1; i<n; i++ )
	{
		temp = A[i];
		j = i-1;
		while ( j>=0 && A[j]>=temp )
		{
			A[j+1] = A[j];
			j--;
		}
		A[j+1] = temp;
	}
}

void InsertSort2( int A[], int n )
{
	int temp;
	int j;
	for ( int i=1; i<n; i++ )
	{
		temp = A[i];
		for ( j=i; j>0 && A[j-1]>temp; j-- )
		{
			A[j] = A[j-1];
		}
		A[j] = temp;
	}
}

int main()
{
	int n;
	cout << "Please enter n:\n";
	cin >> n;

	srand(time(NULL));

	int *A = (int*)malloc( sizeof(int)*n);
	for ( int i=0; i<n; i++ )
	{
		A[i] = rand()%100;
	}

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	InsertSort1( A, n );
	
	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl << endl;

	for ( int i=0; i<n; i++ )
	{
		A[i] = rand()%100;
	}

	cout << "Before sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	InsertSort2( A, n );
	
	cout << "After sorting:\n";
	for ( int i=0; i<n; i++ )
		cout << A[i] << " ";
	cout << endl;

	system("pause");
	return 0;
}