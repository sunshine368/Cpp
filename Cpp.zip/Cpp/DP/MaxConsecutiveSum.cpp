/*
Given a sequence of integers, A[i] (i=1,...,n), we want to find a contiguous subsequence 
of which the sum of the elements is the maximum. For example, given a sequence 
{-1,2,-5,3,2,-1,4,-6}, the subsequence {3,2,-1,4} has the maximum sum 8.
*/

#include <iostream>
using namespace std;

void PrintMaxSub( int *A, int n, int index, int max )
{
	if ( max==0 )
		return;
	PrintMaxSub( A, n, index-1, max-A[index] );
	cout << A[index] << endl;
}

void MaxContSub( int *A, int n )
{
	int *sum = (int*)malloc( sizeof(int)*n );
	sum[0] = A[0];
	int max = A[0];
	int index = 0;
	for ( int i=1; i<n; i++ )
	{
		int temp = sum[i-1]+A[i];
		if ( A[i] > temp )
			sum[i] = A[i];
		else
			sum[i] = temp;
		if ( sum[i] > max )
		{
			max = sum[i];
			index = i;
		}
	}
	
	PrintMaxSub( A, n, index, max );
}

int main()
{
	const int n = 8;
	int A[n] = {1,3,-5,15,1,11,-15,18};
	MaxContSub( A, n );

	system("pause");
	return 0;
}