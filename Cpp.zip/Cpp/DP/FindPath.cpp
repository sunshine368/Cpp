// Given a two-dimensional grid containing "X", "O", "W" and " " (white space), 
// find a path from "O" to "X" through " " with no "W".
// http://www.careercup.com/question?id=13228699

#include <iostream>
using namespace std;

const int m = 5;
const int n = 5;
char grid[m][n] = {{' ', ' ', 'O', ' ', 'O'}, {' ', ' ', 'W', ' ', 'W'}, {' ', 'W', ' ', 'X', ' '}, {'X', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' '}};
bool visited[m][n] = {0};
int dx[] = {1, 1, 0, -1, -1, -1, 0, 1};
int dy[] = {0, 1, 1, 1, 0, -1, -1, 0};

bool findPathAux( int x, int y );

bool findPath( )
{
	int startX = 0, startY = 0;
	bool foundO = 0;
	for ( int i=0; i<m; i++ )
	{
		for ( int j=0; j<n; j++ )
		{
			if ( grid[i][j] == 'O' )
			{
				startX = i;
				startY = j;
				foundO = 1;
				break;
			}
		}
		if ( foundO )
			break;
	}

	return findPathAux( startX, startY );
}

bool findPathAux( int x, int y )
{
	if ( grid[x][y] == 'X' )
	{
		return true;
	}

	visited[x][y] = 1;
	bool found = 0;
	for ( int i=0; i<8; i++ )
	{
		int new_x = x + dx[i];
		int new_y = y + dy[i];
		if ( new_x >= 0 && new_y >=0 && new_x <m && new_y < n )
		{
			if ( visited[new_x][new_y] == 0 && grid[x][y] != 'W' )
				found |= findPathAux( new_x, new_y );
		}
	}

	return found;
}

int main()
{
	bool result = findPath();
	cout << result << endl;

	system("pause");
	return 0;
}