#include <iostream>
using namespace std;

/*
CupTower( M, C, L, index ) 
1	Let cup[1��M] and water[1��M] be arrays of int pointers
2	for i=1 to M
3	    Let cup[i] point to an array of length i
4	    Let water[i] point to an array of length i
5	for i=1 to M
6	    for j=1 to i
7	        water[i][j] = 0
8	        cup[i][j] = 0
9	cup[1][1] = L
10	count = 0
11	for i=1 to M
12	    for j=1 to i
13	        count = count + 1
14	        if cup[i][j]>C
15	            water[i][j] = C
16	            if i != M
17	                cup[i+1][j] += 0.5*(cup[i][j]-C)
18	                cup[i+1][j+1] += 0.5*(cup[i][j]-C)
19	        else
20	            water[i][j] = cup[i][j]
21	        if count == index
22	            return water[i][j]
*/

double CupTower( int M, double C, double L, int index )
{
	double **cup = (double**)malloc( sizeof(double*) * M );
	double **water = (double**)malloc( sizeof(double*) * M );
	for ( int i=0; i<M; i++ )
	{
		cup[i] = (double*)malloc( sizeof(double) * (i+1) );
		water[i] = (double*)malloc( sizeof(double) * (i+1) );
	}

	for ( int i=0; i<M; i++ )
	{
		for ( int j=0; j<=i; j++ )
		{
			water[i][j] = 0;
			cup[i][j] = 0;
		}
	}
	cup[0][0] = L;

	int count = 0;
	for ( int i=0; i<M; i++ )
	{
		for ( int j=0; j<=i; j++ )
		{
			count++;
			if ( cup[i][j] > C )
			{
				water[i][j] = C;
				if ( i != M-1 )
				{
					cup[i+1][j] += 0.5*( cup[i][j] - C );
					cup[i+1][j+1] += 0.5*( cup[i][j] - C );
				}
			}
			else
			{
				water[i][j] = cup[i][j];
			}
			cout << "cup" << count << " has " << water[i][j] << " water.\n";
			if ( count == index )
			{
				return water[i][j];
			}
		}
	}
}

int main()
{
	int M = 5, index = 5;
	double C = 2, L = 8;
	double result = CupTower( M, C, L, index );
	cout << result << endl;

	system("pause");
	return 0;
}