// Section 15.4 of Introduction to Algorithms 3rd Edition by Cormen
// Given two sequences X = <x1, x2, ..., xm> and Y = <y1, y2, ..., yn>, find a maximum length common subsequence of X and Y.
// A sequence Z is a common subsequence of X and Y if Z is a subsequence of both X and Y.
// A sequence Z is a subsequence of X if there exists a strictly increasing sequence <i1, i2, ..., ik> of indices of X such that for all j=1,2,...,k, we have x_{i_j} = z_j.

#include <iostream>
#include <string>
using namespace std;

// LCS-LENGTH( X, Y )
/*
1  m = X.length
2  n = Y.length
3  let b[1...m,1...n] and c[0...m,0...n] be new tables
4  for i=0 to m
5    c[i,0] = 0
6  for j=0 to n
7    c[0,j] = 0
7  for i=0 to m
8    for j=0 to n
8      b[i,j] = 0
8  for i=1 to m
9    for j=1 to n
10     if xi==yi
11       c[i,j] = c[i-1,j-1]+1
11       b[i,j] = 1 
12     else if c[i-1,j] >= c[i,j-1]
13       c[i,j] = c[i-1,j]
13       b[i,j] = 2
14     else
15       c[i,j] = c[i,j-1]
15       b[i,j] = 4
16 return c and b
*/

// PRINT-LCS( b, X, i, j )
/*
1  if i==0 or j==0
2    return
3  if b[i,j] == 1
4    PRINT-LCS( b, X, i-1, j-1 )
5    print x_i
6  else if b[i,j] == 2
7    PRINT-LCS( b, X, i-1, j )
8  else
9    PRINT-LCS( b, X, i, j-1 )
*/

void LongestComSubAux( string x, string y, int **c, int **b);

void printLCS( string x, int **b, int i, int j, string &lcs );

//void reverseString( string &s );

int LongestComSub( string x, string y, string &lcs )
{
	int m = x.length();
	int n = y.length();

	int **c = (int**)malloc( (m+1)*sizeof(int*) );
	int **b = (int**)malloc( (m+1)*sizeof(int*) );
	for ( int i=0; i<=m; i++ )
	{
		c[i] = (int*)malloc( (n+1)*sizeof(int) );
		b[i] = (int*)malloc( (n+1)*sizeof(int) );
	}
	for ( int i=0; i<=m; i++ )
		c[i][0] = 0;
	for ( int i=0; i<=n; i++ )
		c[0][i] = 0;
	for ( int i=0; i<=m; i++ )
	{
		for ( int j=0; j<=n; j++ )
			b[i][j] = 0;
	}

	LongestComSubAux( x, y, c, b);

	// print out the LCS and store it in lcs
	printLCS( x, b, m, n, lcs );

	return c[m][n];
}

void LongestComSubAux( string x, string y, int **c, int **b)
{
	int m = x.length();
	int n = y.length();

	for ( int i=1; i<=m; i++ )
	{
		for ( int j=1; j<=n; j++ )
		{
			if ( x[i-1] == y[j-1] )
			{
				c[i][j] = c[i-1][j-1] + 1;
				b[i][j] = 1; 
			}
			else if ( c[i-1][j] > c[i][j-1] )
			{
				c[i][j] = c[i-1][j];
				b[i][j] = 2;
			}
			else
			{
				c[i][j] = c[i][j-1];
				b[i][j] = 4;
			}
		}
	}
}


void printLCS( string x, int **b, int i, int j, string &lcs )
{
	if ( i==0 || j==0 )
		return;

	if ( b[i][j] == 1 )
	{
		printLCS( x, b, i-1, j-1, lcs );
		cout << x[i-1];
		lcs += x[i-1];
	}
	else if ( b[i][j] == 2 )
	{
		printLCS( x, b, i-1, j, lcs );
	}
	else
	{
		printLCS( x, b, i, j-1, lcs );
	}
}


int main()
{
	string x = "ABCBDAB";
	string y = "BDCABA";
	string lcs = "";
	LongestComSub( x, y, lcs );
	cout << endl;
	cout << lcs << endl;

	system("pause");
	return 0;
}