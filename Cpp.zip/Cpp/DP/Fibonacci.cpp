#include <iostream>
using namespace std;

// dynamic programming approach
int nthFibonacci( int n )
{
	if ( n==1 )
		return 1;
	if ( n==2 )
		return 1;

	int *f = (int*)malloc(sizeof(int)*(n+1));
	f[0] = 0;
	f[1] = 1;
	f[2] = 1;
	for ( int i=3; i<=n; i++ )
	{
		f[i] = f[i-1] + f[i-2];
	}
	return f[n];
}

// simplified
int nthFibonacci2( int n )
{
	if ( n==1 )
		return 1;
	if ( n==2 )
		return 1;

	int prev = 1;
	int prevprev = 1;
	int cur;
	for ( int i=3; i<=n; i++ )
	{
		cur = prev + prevprev;
		prevprev = prev;
		prev = cur;
	}
	return cur;
}

int main()
{
	int n = 5;
	cout << nthFibonacci( n ) << endl;
	cout << nthFibonacci2( n ) << endl;

	double temp;
	cin >> temp;
	return 0;
}