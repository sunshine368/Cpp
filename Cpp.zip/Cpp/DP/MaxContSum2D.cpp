// time complexity: O(n^4)

#include <iostream>
using namespace std;

int MaxContSum2DAux( int **A, int row, int col, int x0, int y0 )
{
    int **S = (int**)malloc( sizeof(int*)*(row-x0) );
    for ( int i=0; i<row-x0; i++ )
    {
        S[i] = (int*)malloc( sizeof(int)*(col-y0) );
        for ( int j=0; j<col-y0; j++ )
        {
            S[i][j] = 0;
        }
    }
    
    for ( int i=0; i<row-x0; i++ )
        S[i][0] = A[i+x0][y0];
    
    for ( int i=0; i<row-x0; i++ )
    {
        for ( int j=1; j<col-y0; j++ )
        {
            S[i][j] = S[i][j-1] + A[i+x0][j+y0];
        }
    }
 
    int **C = (int**)malloc( sizeof(int*)*(row-x0) );
    for ( int i=0; i<row-x0; i++ )
    {
        C[i] = (int*)malloc( sizeof(int)*(col-y0) );
        for ( int j=0; j<col-y0; j++ )
        {
            C[i][j] = 0;
        }
    }
    
    int max = A[x0][y0];
    for ( int j=0; j<col-y0; j++ )
    {
        C[0][j] = S[0][j];
        if ( C[0][j]>max )
            max = C[0][j];
    }
    
    for ( int j=0; j<col-y0; j++ )
    {
        for ( int i=1; i<row-x0; i++ )
        {
            C[i][j] = C[i-1][j] + S[i][j];
            if ( C[i][j]>max )
                max = C[i][j];
        }
    }
    
    return max;
}

void MaxContSum2D( int **A, int row, int col )
{
    int max = A[0][0];
    int **B = (int**)malloc( sizeof(int*)*row );
    
    for ( int startX=0; startX<row; startX++ )
    {
        B[startX] = (int*)malloc( sizeof(int)*col );
        for ( int startY=0; startY<col; startY++ )
        {
            B[startX][startY] = MaxContSum2DAux( A, row, col, startX, startY );
            if ( B[startX][startY]>max )
                max = B[startX][startY];
        }
    }
    
    cout << "The greatest sum is " << max << endl;
}

int main()
{
    const int m = 4, n = 5;
    int **A = (int**)malloc( sizeof(int*)*m );
    for ( int i=0; i<m; i++ )
    {
        A[i] = (int*)malloc( sizeof(int)*n );
    }
    A[0][0] = 1; A[0][1] = 2; A[0][2] = -1; A[0][3] = 4; A[0][4] = -20;
    A[1][0] = 8; A[1][1] = -3; A[1][2] = 4; A[1][3] = 2; A[1][4] = 1;
    A[2][0] = 3; A[2][1] = 8; A[2][2] = 10; A[2][3] = -8; A[2][4] = 3;
    A[3][0] = -4; A[3][1] = -1; A[3][2] = 1; A[3][3] = 7; A[3][4] = 6;
    MaxContSum2D( A, m, n );
    
    return 0;
}