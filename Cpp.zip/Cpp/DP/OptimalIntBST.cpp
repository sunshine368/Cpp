// Given a list of numbers A={5,9,12,16,25,30,45} and their fixed probability of occurrence
// P = {0.22, 0.18, 0.2, 0.05, 0.25, 0.02, 0.08}. The problem is to arrange the numbers in
// a binary search tree in a way that the expected cost for a search in the tree is minimized.
// Note: In a binary search tree, the number of comparisons needed to access element at depth 
// d is (1+d).

#include <iostream>
#include <string>
using namespace std;

void printIntBST( int **root, int i, int j, int n );

int optimalIntBST( double *p, int n )
{
	double **e = (double**)malloc( sizeof(double*)*n );
	for ( int i=0; i<n; i++ )
	{
		e[i] = (double*)malloc( sizeof(double)*n );
	}

	double **w = (double**)malloc( sizeof(double*)*n );
	for ( int i=0; i<n; i++ )
	{
		w[i] = (double*)malloc( sizeof(double)*n );
	}

	int **root = (int**)malloc( sizeof(int*)*n );
	for ( int i=0; i<n; i++ )
	{
		root[i] = (int*)malloc( sizeof(int)*n );
	}

	for ( int i=0; i<n; i++ )
	{
		e[i][i] = p[i];
		w[i][i] = p[i];
		root[i][i] = i;
	}

	for ( int l=2; l<=n; l++ )
	{
		for ( int i=0; i<=n-l; i++ )
		{
			int j = i+l-1;
			e[i][j] = INT_MAX;
			w[i][j] = w[i][j-1] + p[j];
			for ( int r=i; r<=j; r++ )
			{
				double temp;
				if ( r==i )
				{
					temp = e[r+1][j] + w[i][j];
				}
				else if ( r==j )
				{
					temp = e[i][r-1] + w[i][j];
				}
				else
				{
					if ( r==0 )
						temp = e[1][j] + w[0][j];
					else if ( r==n-1 )
						temp = e[i][n-2] + w[i][n-1];
					else
						temp = e[i][r-1] + e[r+1][j] + w[i][j];
				}
				if ( temp < e[i][j] )
				{
					e[i][j] = temp;
					root[i][j] = r;
				}
			}
		}
	}

	printIntBST( root, 0, n-1, n );

	cout << "The expected cost is: " << e[0][n-1] << endl;

	return root[0][n-1];
}


void printIntBST( int **root, int i, int j, int n )
{
	if ( i==0 && j==n-1 )
	{
		cout << "k" << root[0][n-1] << " is the root.\n";
	}

	if ( i==j )
	{
		return;
	}

	int top = root[i][j];

	if ( i==top )
	{		
		int rightChild = root[top+1][j];
		cout << "k" << rightChild << " is the right child of k" << top << endl;
		printIntBST( root, top+1, j, n );
	}
	else if ( j==top )
	{
		int leftChild = root[i][top-1];
		cout << "k" << leftChild << " is the left child of k" << top << endl;
		printIntBST( root, i, top-1, n );
	}
	else
	{
		int leftChild = root[i][top-1];
		cout << "k" << leftChild << " is the left child of k" << top << endl;
		printIntBST( root, i, top-1, n );
		int rightChild = root[top+1][j];		
		cout << "k" << rightChild << " is the right child of k" << top << endl;
		printIntBST( root, top+1, j, n );
	}
}

int main()
{
	double p[] = {0.22, 0.18, 0.2, 0.05, 0.25, 0.02, 0.08};
	int n = 7;
	int root = optimalIntBST( p, n );

	system("pause");
	return 0;
}