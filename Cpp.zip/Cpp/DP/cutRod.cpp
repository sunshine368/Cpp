// Section 15.1 of Introduction to Algorithms, 3rd Edition by Cormen
// Problem:
// Given a rod of length n inches and a table of prices p_i for i-1,2,...,n,
// determine the maximum revenue r_n obtainable by cutting up the rod and selling
// the pieces.
// For example,
// i    | 1  2  3  4  5  6  7  8  9 10
//---------------------------------------
// p_i  | 1  5  8  9 10 17 17 20 24 30

#include <iostream>
using namespace std;

// Recursive top-down implementation
/* 
Pseudo-code:
CutRod( p, n )
1   if n == 0
2     return 0
3   q = -infinity
4   for i=1 to n
5     q = max( q, p[i] + CutRod( p, n-i ) )
6   return q
*/
int cutRodRecur( int *p, int n )
{
	if ( n == 0 )
		return 0;
    int q = -1;
	for ( int i=1; i<=n; i++ )
	{
		q = max( q, p[i-1]+cutRodRecur( p, n-i ) );
	}
	return q;
}

// Top-down implementation
/*
memoizedCutRod( p, n )
1 let r[0,...n] be a new array
2 for i=0 to n
3   r[i] = -infinity
4 return memoizedCutRodAux( p, n, r )

memoizedCutRodAux( p, n, r )
1 if r[n] >= 0
2   return r[n]
3 if n==0
4   q = 0
5 else
6   q = -infinity
7   for i=1 to n
8     q = max( q, p[i]+memoizedCutRodAux( p, n-i, r ) )
9 r[n] = q
10 return q
*/
int memoizedCutRodAux( int *p, int n, int *r );

int memoizedCutRod( int *p, int n )
{
	int *r = (int *)malloc(sizeof(int)*(n+1));
	for ( int i=0; i<=n; i++ )
		r[i] = -1;
	return memoizedCutRodAux( p, n, r );
}

int memoizedCutRodAux( int *p, int n, int *r )
{
	if ( r[n] >= 0 )
		return r[n];

	int q = 0;
	if ( n>0 )
	{
		for ( int i=1; i<=n; i++ )
			q = max( q, p[i-1]+memoizedCutRodAux( p, n-i, r ) );
	}
	r[n] = q;
	return q;
}


// Top-down implementation, which also returns the actual solution
/*
memoizedCutRod( p, n )
1 let r[0,...n] and s[0...n] be a new array
2 for i=0 to n
3   r[i] = -infinity
4   s[i] = -infinity
4 return memoizedCutRodAux( p, n, r[], s[] )

memoizedCutRodAux( p, n, r[], s[] )
1 if r[n] >= 0
2   return r[n]
3 if n==0
4   q = 0
5 else
6   q = -infinity
7   for i=1 to n
7     temp = memoizedCutRodAux( p, n-i, r ) 
8     if q < p[i] + temp
8		q = p[i] + temp
8       s[n] = i
9 r[n] = q
10 return q
*/
int memoizedCutRodWithChoiceAux( int *p, int n, int *r, int *s );

int memoizedCutRodWithChoice( int *p, int n )
{
	int *r = (int *)malloc(sizeof(int)*(n+1));
	int *s = (int *)malloc(sizeof(int)*(n+1));
	for ( int i=0; i<=n; i++ )
	{
		r[i] = -1;
		s[i] = 0;
	}
	
	int q = memoizedCutRodWithChoiceAux( p, n, r, s );

	// display the results
	for ( int i=0; i<=10; i++ )
	{
		cout << r[i] << " ";
	}
	cout << endl;

	for ( int i=0; i<=10; i++ )
	{
		cout << s[i] << " ";
	}
	cout << endl;

	return q;
}

int memoizedCutRodWithChoiceAux( int *p, int n, int *r, int *s )
{
	if ( r[n] >= 0 )
		return r[n];

	int q = 0;
	if ( n>0 )
	{
		for ( int i=1; i<=n; i++ )
		{
			int temp = memoizedCutRodWithChoiceAux( p, n-i, r, s );
			if ( q < p[i-1] + temp )
			{
				q = p[i-1] + temp;
				s[n] = i;
			}
		}
	}
	r[n] = q;
	return q;
}


// Bottom-up implementation
/*
bottomUpCutRod( p, n )
1 let r[0,...,n] be a new array
2 r[0] = 0
3 for j=1 to n
4   q = -infinity
5   for i=1 to j
6     q = max( q, p[i]+r[j-i] )
7   r[j] = q
8 return r[n]
*/
int bottomUpCutRod( int *p, int n )
{
	int *r = (int*)malloc(sizeof(int)*(n+1));
	r[0] = 0;
	for ( int j=1; j<=n; j++ )
	{
		int q = -1;
		for ( int i=1; i<=j; i++ )
		{
			q = max( q, p[i-1]+r[j-i] );
		}
		r[j] = q;
	}
	return r[n];
}

// Bottom-up implementation which also returns the actual solution (optimal choices, i.e., the first piece to cut)
/*
bottomUpCutRodWithChoice( p, n )
1 let r[0...n] and s[0...n] be new arrays
2 r[0] = 0, s[0] = 0
3 for j=1 to n
4   q = -infinity
5   for i=1 to j
6     if q < p[i] + r[j-i]
7       q = p[i] + r[j-i]
8       s[j] = i
9     r[j] = q
10 display r[] and s[]
*/
int bottomUpCutRodWithChoice( int *p, int n ) // returns a two-dimensional array, with the first row representing the optimal values and the second row representing the optimal choices
{
	int *r = (int*)malloc(sizeof(int)*(n+1));
	int *s = (int*)malloc(sizeof(int)*(n+1));
	r[0] = 0;
	s[0] = 0;

	for ( int j=1; j<=n; j++ )
	{
		int q = -1;
		for ( int i=1; i<=j; i++ )
		{
			if ( q < p[i-1]+r[j-i] )
			{
				q = p[i-1] + r[j-i];
				s[j] = i;
			}
		}
		r[j] = q;
	}

	// display the results
	for ( int i=0; i<=10; i++ )
	{
		cout << r[i] << " ";
	}
	cout << endl;

	for ( int i=0; i<=10; i++ )
	{
		cout << s[i] << " ";
	}
	cout << endl;

	return r[n];
}


// Bottom-up implementation which also returns the optimal choice; cutting cost included
/*
bottomUpCutRodWithChoice( p, n, cost )
1  let r[0...n], s[0...n], c[0...n] be new arrays
2  r[0] = 0, s[0] = 0, c[0] = 0
3  for j=1 to n
4    q = -infinity
5    for i=1 to j
6      if i != j
6        temp = p[i] + r[j-i] - c[j-i] - cost
6      else
6        temp = p[i] + r[j-i]
6      if q < temp
7        q = temp
8        s[j] = i
9    r[j] = q
10   if s[j]==j
11     c[j] = 0;
12   else
13     c[j] = cost + c[j-s[j]]
10 display r[], s[] and c[]
*/
int bottomUpCutRodWithCost( int *p, int n, int cost ) // returns a two-dimensional array, with the first row representing the optimal values and the second row representing the optimal choices
{
	int *r = (int*)malloc(sizeof(int)*(n+1));
	int *s = (int*)malloc(sizeof(int)*(n+1));
	int *c = (int*)malloc(sizeof(int)*(n+1));
	r[0] = 0;
	s[0] = 0;
	c[0] = 0;

	for ( int j=1; j<=n; j++ )
	{
		int q = -1;

		for ( int i=1; i<=j; i++ )
		{
			int temp;
			if ( i != j )
				temp = p[i-1] + r[j-i] - c[j-i] - cost;
			else
				temp = p[i-1] + r[j-i];

			if ( q < temp )
			{
				q = temp;
				s[j] = i;
			}
		}

		r[j] = q;

		if ( s[j] == j )
			c[j] = 0;
		else
			c[j] = cost + c[j-s[j]];
	}

	for ( int i=0; i<=10; i++ )
	{
		cout << r[i] << " ";
	}
	cout << endl;

	for ( int i=0; i<=10; i++ )
	{
		cout << s[i] << " ";
	}
	cout << endl;

	for ( int i=0; i<=10; i++ )
	{
		cout << c[i] << " ";
	}
	cout << endl;

	return r[n];
}


int main()
{
	const int n = 10;
	int p[n] = {1, 5, 8, 9, 10, 17, 17, 20, 24, 30};

	int q;
	q = cutRodRecur( p, n );
	cout << q << endl;

	q = memoizedCutRod( p, n );
	cout << q << endl;

	q = bottomUpCutRod( p, n );
	cout << q << endl;

	bottomUpCutRodWithChoice( p, n );

	int cost = 1;
	bottomUpCutRodWithCost( p, n, cost );

	q = memoizedCutRodWithChoice( p, n );
	cout << q << endl;

	double temp;
	cin >> temp;
	return 0;
}