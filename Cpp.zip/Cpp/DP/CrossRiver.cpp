double revDouble2(double d)
{
    double precision = 0.0000001;
    int left = 0;
    int right = 0;
    int rightdigit = 0;
    double reverse;
    
    // get the integral part and reverse it
    int integral = (int)d;
    double fractional = d - integral;
    while ( integral > 0 )
    {
        int temp = integral % 10;
        left = left * 10 + temp;
        integral = integral / 10;
    }
    
    // get the fractional part
    while ( (fractional - (int)fractional) > precision )
    {
        fractional *= 10;
        rightdigit++;
    }
    
    int r = (int)fractional;
    while ( r > 0 )
    {
        int temp = r % 10;
        right = right * 10 + temp;
        r = r/10;
    }
    
    reverse = left + (double)right / pow((double)right, rightdigit);
    return reverse;
}