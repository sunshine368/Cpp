// Section 15.2 of Introduction to Algorithms, 3rd Edition by Cormen
// Given a sequence of n matrices to be multiplied, compute the product and minimize 
// the cost of multiplication by parenthesizing the chain of matrices.
// Note that different parenthesization results in different multiplication cost. 
// For example, given three matrices A1 (r1 by c1), A2 (r2 by c2), A3 (r3 by c3),
// where r1 = 1, c1 = r2 = 1000, c2 = r3 = 1, c3 = 10, 
// A1(A2 A3) involves 1*1000*10 + 1000*1*10 = 20000 scalar multiplications while
// (A1 A2)A3 involves 1*1000*1 + 1*1*10 = 1010 scalar multiplications.

#include <iostream>
#include <vector>
using namespace std;

const int n = 6;

void PrintOptimalParens( int s[][n], int i, int j );

// MatrixChainOrder( p ) // p is an array of the row size of each matrix
/*
1  n = p.length - 1
2  let m[1...n,1...n] and s[1...n-1,2...n] be new tables
3  for i=1 to n
4    m[i,i] = 0
5  for l=2 to n
6    for i=1 to n-l+1
7      j = i+l-1
8      m[i,j] = infinity
9      for k=i to j-1
10       q = m[i,k] + m[k+1,j] + p_(i-1) p_k p_j
11       if q < m[i,j]
12         m[i,j] = q
13         s[i,j] = k
14  return m and s
*/
void MatrixChainOrder( int p[], int m[][n], int s[][n] )
{
	for ( int i=1; i<=n; i++ )
	{
		m[i-1][i-1] = 0;
		s[i-1][i-1] = i;
	}
	for ( int r=2; r<=n; r++ )
	{
		for ( int i=1; i<=n-r+1; i++ )
		{
			int j = i + r -1;
			m[i-1][j-1] = INT_MAX;
			for ( int k=i; k<=j-1; k++ )
			{
				int q = m[i-1][k-1] + m[k][j-1] + p[i-1]*p[k]*p[j];
				if ( q < m[i-1][j-1] )
				{
					m[i-1][j-1] = q;
					s[i-1][j-1] = k;
				}
			}
		}
	}
	PrintOptimalParens( s, 1, n );
	cout << endl;
}


// PrintOptimalParens( s, i, j )
/*
1  if i==j
2    print "A_i"
3  else print "("
4    PrintOptimalParens( s, i, s[i,j] )
5    PrintOptimalParens( s, s[i,j]+1, j )
6    print ")"
*/
void PrintOptimalParens( int s[][n], int i, int j )
{
	if ( i==j )
	{
		cout << "A" << i;
		return;
	}
	else
	{
		cout << "(";
		PrintOptimalParens( s, i, s[i-1][j-1] );
		PrintOptimalParens( s, s[i-1][j-1]+1, j );
		cout << ")";
	}
}


// Multiply two matrices
void MatrixMultiply( int **A1, int row1, int col1, int **A2, int row2, int col2, int **A ) // A = A1 * A2
{
	if ( col1 != row2 )
	{
		cout << "Matrix dimensions do not match!\n";
		return;
	}

	for ( int i=0; i<row1; i++ )
	{
		for ( int j=0; j<col2; j++ )
		{
			A[i][j] = 0;
			for ( int k=0; k<col1; k++ )
				A[i][j] += A1[i][k]*A2[k][j];
		}
	}
}

// Matrix Chain Multiply
void MatrixChainMultiply( int ***A, int *row, int *col, int n, int ***Product ) // (*Product) = A1 * A2 * ... * An
{
	int ***P = (int***)malloc( n*sizeof(int**) );
	
	for ( int i=0; i<n; i++ )
	{
		P[i] = (int**)malloc( row[0]*sizeof(int*) );
		for ( int j=0; j<row[0]; j++ )
		{
			P[i][j] = (int*)malloc( col[i]*sizeof(int) );
		}
	}

	P[0] = A[0];
	for ( int i=0; i<n-1; i++ )
	{
		MatrixMultiply( P[i], row[0], col[i], A[i+1], row[i+1], col[i+1], P[i+1] );
	}

	*Product = P[n-1];
}


// diplay a matrix
void display( int **A, int row, int col )
{
	for ( int i=0; i<row; i++ )
	{
		for ( int j=0; j<col; j++ )
		{
			cout << A[i][j] << " ";
		}
		cout << endl;
	}
}

/* 
The following function actually performs the optimal matrix-chain multiplication, given the sequence of matrices <A1, A2, ..., An>.
See Exercise 15.2-2 of Introduction to Algorithm 3rd Edition
*/
// Matrix chain multiply with the smallest number of multiplication
void MatrixChainMultiplyOptimaAux( int ***A, int *row, int *col, int i, int j, int **s, int ****P ); // to actually calculate the product of the matrices Ai to Aj

void PrintOptimalParens2( int **s, int i, int j ); // display the association precedence of the multiplication of Ai to Aj

void MatrixChainOrder2( int *dim, int **m, int **s ); // "dim" is an array storing the dimensions of 
// the n matrices, i.e., the number of rows of matrice A1 to An plus the number of columns of An; "m" 
// is a matrix, with each element m[i,j] storing the number of multiplications used to get the product 
// of Ai to Aj; "s" is a matrix, with each element s[i,j] storing the place to first split the matrices Ai to Aj.

void MatrixChainMultiplyOptima( int ***A, int *row, int *col, int n, int ***Product )
{
	int *dim = (int*)malloc( (n+1)*sizeof(int) );
	for ( int i=0; i<n; i++ )
	{
		dim[i] = row[i];
	}
	dim[n] = col[n-1];

	// initialize m, s for the function call "MatrixChainOrder2()"
	int **m = (int**)malloc( sizeof(int*)*n );
	int **s = (int**)malloc( sizeof(int*)*n );
	for ( int i=0; i<n; i++ )
	{
		m[i] = (int*)malloc( sizeof(int)*n );
		s[i] = (int*)malloc( sizeof(int)*n );
	}

	MatrixChainOrder2( dim, m, s );

	// initialize P for the function call "MatrixChainMultiplyOptimaAux()"
	int ****P = (int****)malloc( sizeof(int***) * n );
	for ( int i=0; i<n; i++ )
	{
		P[i] = (int***)malloc( sizeof(int**) * n );
		for ( int j=0; j<n; j++ )
		{
			P[i][j] = (int**)malloc( sizeof(int*) * row[i] );
			for ( int k=0; k<row[i]; k++ )
			{
				P[i][j][k] = (int*)malloc( sizeof(int) * col[j] );
			}
		}
	}
	for ( int i=0; i<n; i++ )  
	{
		P[i][i] = A[i];
	}

	MatrixChainMultiplyOptimaAux( A, row, col, 0, n-1, s, P );

	// store and display the final result, i.e., the product of the array of matrices
	(*Product) = P[0][n-1];
	display( P[0][n-1], row[0], col[n-1] );
}

void MatrixChainOrder2( int *dim, int **m, int **s )
{
	for ( int i=0; i<n; i++ )
	{
		m[i][i] = 0;
		s[i][i] = i;
	}

	for ( int r=2; r<=n; r++ )
	{
		for ( int i=0; i<n-r+1; i++ )
		{
			int j = i + r -1;
			m[i][j] = INT_MAX;
			for ( int k=i; k<=j-1; k++ )
			{
				int q = m[i][k] + m[k+1][j] + dim[i]*dim[k+1]*dim[j+1];
				if ( q < m[i][j] )
				{
					m[i][j] = q;
					s[i][j] = k;
				}
			}
		}
	}

	PrintOptimalParens2( s, 0, n-1 );
	cout << " = " << endl;
}


void PrintOptimalParens2( int **s, int i, int j )
{
	if ( i==j )
	{
		cout << "A" << i+1;
		return;
	}
	else
	{
		cout << "(";
		PrintOptimalParens2( s, i, s[i][j] );
		PrintOptimalParens2( s, s[i][j]+1, j );
		cout << ")";
	}
}


void MatrixChainMultiplyOptimaAux( int ***A, int *row, int *col, int i, int j, int **s, int ****P )
{
	if ( i==j )
	{
		return;
	}
	else
	{
		MatrixChainMultiplyOptimaAux( A, row, col, i, s[i][j], s, P );
		MatrixChainMultiplyOptimaAux( A, row, col, s[i][j]+1, j, s, P );
		MatrixMultiply( P[i][s[i][j]], row[i], col[s[i][j]], P[s[i][j]+1][j], row[s[i][j]+1], col[j], P[i][j] );
	}
}


int main()
{
	int p[n+1] = {30, 35, 15, 5, 10, 20, 25};
	int s[n][n] = {0};
	int m[n][n] = {0};
	MatrixChainOrder( p, m, s );

	int p2[n+1] = {5, 10, 3, 12, 5, 50, 6};
	MatrixChainOrder( p2, m, s );

	// In the following, we show matrix chain multiplication.
	int p3[n+1] = {1,2,4,2,3,1,3};
	MatrixChainOrder( p3, m, s );

	int row[n];
	int col[n];
	row[0] = 1; row[1] = 2; row[2] = 4; row[3] = 2; row[4] = 3; row[5] = 1; 
	col[0] = 2; col[1] = 4; col[2] = 2; col[3] = 3; col[4] = 1; col[5] = 3;

	// A1 = [1 2]
	int **A1 = (int**)malloc(row[0] * sizeof(int*));
	for ( int i=0; i<row[0]; i++ )
		A1[i] = (int*)malloc(col[0] * sizeof(int));
	A1[0][0] = 1; A1[0][1] = 2;

	// A2 = [1 2 3 4; 5 6 7 8]
	int **A2 = (int**)malloc(row[1] * sizeof(int*));
	for (int i=0; i<row[1]; i++)
		A2[i] = (int*)malloc(col[1] * sizeof(int));
	A2[0][0] = 1; A2[0][1] = 2; A2[0][2] = 3; A2[0][3] = 4;
	A2[1][0] = 5; A2[1][1] = 6; A2[1][2] = 7; A2[1][3] = 8;

	// A3 = [1 2; 3 4; 5 6; 7 8]
	int **A3 = (int**)malloc(row[2] * sizeof(int*));
	for (int i=0; i<row[2]; i++)
		A3[i] = (int*)malloc(col[2] * sizeof(int));
	A3[0][0] = 1; A3[0][1] = 2;
	A3[1][0] = 3; A3[1][1] = 4;
	A3[2][0] = 5; A3[2][1] = 6;
	A3[3][0] = 7; A3[3][1] = 8;

	// A4 = [1 2 3; 4 5 6]
	int **A4 = (int**)malloc(row[3] * sizeof(int*));
	for (int i=0; i<row[3]; i++)
		A4[i] = (int*)malloc(col[3] * sizeof(int*));
	A4[0][0] = 1; A4[0][1] = 2; A4[0][2] = 3;
	A4[1][0] = 4; A4[1][1] = 5; A4[1][2] = 6;

	// A5 = [1; 2; 3]
	int **A5 = (int**)malloc(row[4] * sizeof(int*));
	for (int i=0; i<row[4]; i++)
		A5[i] = (int*)malloc(col[4] * sizeof(int));
	A5[0][0] = 1; 
	A5[1][0] = 2;
	A5[2][0] = 3;

	// A6 = [1 2 3]
	int **A6 = (int**)malloc(row[5] * sizeof(int*));
	for (int i=0; i<row[5]; i++)
		A6[i] = (int*)malloc(col[5] * sizeof(int));
	A6[0][0] = 1; A6[0][1] = 2; A6[0][2] = 3;


	// A = [A1; A2; A3; A4; A5; A6], A is an array of matrices
	int ***A = (int***)malloc(n*sizeof(int**));
	A[0] = A1; A[1] = A2; A[2] = A3; A[3] = A4; A[4] = A5; A[5] = A6;


	// display A1 to A6, illustration of the function display()
	for ( int i=0; i<n; i++ )
	{
		cout << "A[" << i << "] = \n";
		display( A[i], row[i], col[i] );
		cout << endl;
	}
	

	// A12 = A1 * A2, illustration of the function MatrixMultiply()
	int **A12 = (int**)malloc(row[0] * sizeof(int*));
	for ( int i=0; i<row[0]; i++ )
		A12[i] = (int*)malloc(col[1] * sizeof(int));
	MatrixMultiply( A1, row[0], col[0], A2, row[1], col[1], A12 );
	cout << "A1 * A2 =\n";
	display( A12, row[0], col[1] );
	cout << endl;


	// matrix chain multiplication using the function MatrixMultiply()
	/* -- BEGIN -- */
	// P = [P[0], P[1], P[2], P[3], P[4], P[5]]
	int ***P = (int***)malloc( n*sizeof(int**) );
	for ( int i=0; i<n; i++ )
	{
		P[i] = (int**)malloc( row[0]*sizeof(int*) );
		for ( int j=0; j<row[0]; j++ )
		{
			P[i][j] = (int*)malloc( col[i]*sizeof(int) );
		}
	}

	P[0] = A[0];
	for ( int i=0; i<n-1; i++ )
	{
		MatrixMultiply( P[i], row[0], col[i], A[i+1], row[i+1], col[i+1], P[i+1] ); // P[i+1] = P[i] * A[i+1], P[0] = A[0]
	}
	cout << "Product using MatrixMultiply:\n";
	display( P[5], row[0], col[5] ); // P[5] = A[0]*A[1]*...*A[5] = A1*A2*...*A6
	cout << endl;
	/* -- END -- */


	// matrix chain multiplication using the function MatrixChainMultiply()
	/* -- BEGIN -- */
	int ***Product = (int***)malloc( sizeof(int**) );
	*Product = (int**)malloc( sizeof(int*)*n );
	for ( int i=0; i<row[0]; i++ )
	{
		Product[0][i] = (int*)malloc( col[n-1]*sizeof(int) );
	}
	MatrixChainMultiply( A, row, col, n, Product );

	cout << "Product using MatrixChainMultiply:\n";
	display( *Product, row[0], col[n-1] );
	cout << endl;
	/* -- END -- */


	// matrix chain multiplication using the function MatrixChainMultiplyOptima()
	/* -- BEGIN -- */
	int ***Product2 = (int***)malloc( sizeof(int**) );
	*Product2 = (int**)malloc( sizeof(int*)*n );
	for ( int i=0; i<row[0]; i++ )
	{
		Product2[0][i] = (int*)malloc( col[n-1]*sizeof(int) );
	}
	MatrixChainMultiplyOptima( A, row, col, n, Product2 );
	cout << endl;

	cout << "Product using MatrixChainMultiplyOptima:\n";
	display( *Product2, row[0], col[n-1] );
	cout << endl;
	/* -- END -- */

	system("pause");
	return 0;
}

