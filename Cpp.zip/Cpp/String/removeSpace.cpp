#include <iostream>
#include <string>
using namespace std;

// This C-based function removes all spaces from a string.
// complexity: O(n), in-place
void removeSpace( char *text )
{
	char *newtext = text;
	int j = 0;
	for ( int i=0; i<strlen(text); i++ )
	{
		if ( text[i] != ' ' )
		{
			newtext[j++] = text[i];
		}
	}
	newtext[j] = '\0';
}

int main()
{
	char str[] = "This is a test string";
	removeSpace( str );
	cout << str << endl;

	double temp;
	cin >> temp;
	return 0;
}