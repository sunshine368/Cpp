// Given two strings, print all the interleavings of the two strings, with the characters 
// coming from the same string keeping the same order as in the original string.
// For example, given "AB" and "CD", print
// "ABCD", "ACBD", "ACDB", "CABD", "CADB", "CDAB".
// Theoretically, suppose the length of the first string is n1 and the length of the 
// second string is n2, the number of interleavings of the two strings is n1!n2!/(n1+n2)!


#include <iostream>
#include <string>
using namespace std;

void printInterleavingHelper1( string s1, string s2, string soFar )
{
	if ( s1.length() == 0 && s2.length() == 0 )
		return;
	if ( s1.length() == 0 && s2.length() != 0 )
		cout << soFar << s2 << endl;
	else if ( s2.length() == 0 && s1.length() != 0 )
		cout << soFar << s1 << endl;
	else
	{
		printInterleavingHelper1( s1.substr(1), s2, soFar + s1.at(0) );
		printInterleavingHelper1( s1, s2.substr(1), soFar + s2.at(0) );
	}
}

void printInterleaving1( string s1, string s2 )
{
	printInterleavingHelper1( s1, s2, "");
}


void printInterleavingHelper2( string s1, string s2, string soFar )
{
	if ( s1.length() == 0 && s2.length() == 0 )
		return;
	if ( s1.length() == 0 && s2.length() != 0 )
		cout << soFar << s2 << endl;
	else if ( s2.length() == 0 && s1.length() != 0 )
		cout << soFar << s1 << endl;
	else
	{
		printInterleavingHelper2( s1.substr(1), s2, soFar + s1.at(0) );
		printInterleavingHelper2( s2.substr(1), s1, soFar + s2.at(0) );
	}
}

void printInterleaving2( string s1, string s2 )
{
	printInterleavingHelper2( s1, s2, "");
}

int main()
{
	string s1 = "ABC";
	string s2 = "DEF";
	printInterleaving1( s1, s2 );
	cout << endl;
	printInterleaving2( s1, s2 );
	//printOrderedCombination( s1, s2, "" );

	double temp;
	cin >> temp;
	return 0;
}