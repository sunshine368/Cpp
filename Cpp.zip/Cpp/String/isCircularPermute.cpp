// Given two strings, determine if one is a circular permutation of the other.

#include <iostream>
#include <string>
using namespace std;

bool isCircularPermute( string s1, string s2 )
{
	string s3 = s1 + s1;
	if ( s3.find( s2 ) != string::npos )
		return true;
	else
		return false;
}

int main()
{
	string s1 = "adeahmgifh";
	string s2 = "eahmgifadd";
	bool isCircular1 = isCircularPermute( s1, s2 );
	if ( isCircular1 )
		cout << "s1 and s2 are circular permutations of each other.\n";
	else
		cout << "s1 and s2 are not circular permutations of each other.\n";

	string s3 = "adeahmgif";
	string s4 = "eahmgifad";
	bool isCircular2 = isCircularPermute( s3, s4 );
	if ( isCircular2 )
		cout << "s3 and s4 are circular permutations of each other.\n";
	else
		cout << "s3 and s4 are not circular permutations of each other.\n";

	double temp;
	cin >> temp;
	return 0;
}