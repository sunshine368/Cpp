#include <cstring>
#include <iostream>
using namespace std;

int main()
{
	char str[] = "/root//foo/bar";
	char *str = "/root//foo/bar";

	int i1 = 0;
	int i2 = 0;

	str[i1] = str[i2];

	double temp;
	cin >> temp;
	return 0;
}