// Exercise 18.20 of How to Program C++ by Paul Deitel
// This program uses the C-style library functions strtok to tokenize a given string into individual words.

// #include <cstdio> 
// #include <cstring>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

vector<string> parseSentence1( char * s )
{
	vector<string> words;

	char *ptr = strtok( s, " -.,;:?!(){}[]" );
	while( ptr != NULL )
	{
		words.push_back( ptr );
		ptr = strtok( NULL, " -.,;:?!(){}[]" );
	}

	return words;
}

vector<char *> parseSentence2( char * s )
{
	vector<char *> words;

	char *ptr = strtok( s, " -.,;:?!(){}[]" );
	while( ptr != NULL )
	{
		words.push_back( ptr );
		ptr = strtok( NULL, " -.,;:?!(){}[]" );
	}

	return words;
}

int main()
{
	// illustration of the use of strtok
	char str[] = "- This, a sample string.";
	char *pch;
	printf( "Splitting string \"%s\" into tokens:\n", str );
	pch = strtok(str, " ,.-");
	while( pch != NULL )
	{
		printf("%s\n",pch);
		pch = strtok(NULL, " ,.-");
	}

	string s1;
	cout << "Please enter a string:\n";
	getline( cin, s1 );
	vector<string> word1 = parseSentence1( &s1[0] );
	for ( int i=0; i<word1.size(); i++ )
	{
		cout << word1[i] << endl;
	}

	string s2;
	cout << "Please enter a string:\n";
	getline( cin, s2 );
	vector<char *> word2 = parseSentence2( &s2[0] );
	for ( int i=0; i<word2.size(); i++ )
	{
		cout << word2[i] << endl;
	}

	double temp;
	cin >> temp;
	return 0;
}