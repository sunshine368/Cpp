#include <iostream>
#include <string>
using namespace std;

void searchReplace1( string &s, string oldtext, string newtext )
{
	int position = s.find( oldtext, 0 );
	while ( position != string::npos )
	{
		s.erase( position, oldtext.length() );
		s.insert( position, newtext );
		position = s.find( oldtext, position + newtext.length() );
	}
}

void searchReplace2( string &s, string oldtext, string newtext )
{
	int position = s.find( oldtext, 0 );
	while ( position != string::npos )
	{
		s.replace( position, oldtext.length(), newtext );
		position = s.find( oldtext, position + newtext.length() );
	}
}


int main()
{
	string string1 = "I like apple";
	string string2 = "apple";
	string string3 = "banana";

	cout << "The origial string:\n";
	cout << string1 << endl;

	searchReplace1( string1, string2, string3 );
	cout << "After replacing " << string2 << " with " << string3 << ":\n";
	cout << string1 << endl;

	searchReplace2( string1, string3, string2 );
	cout << "After replacing " << string3 << " with " << string2 << ":\n";
	cout << string1 << endl;

	double temp;
	cin >> temp;
	return 0;
}