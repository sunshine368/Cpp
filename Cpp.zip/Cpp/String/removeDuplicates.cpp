// Remove duplicates from a string. 
// For example, "banana" becomes "ban"

#include <iostream>
#include <string>
using namespace std;

// C++ string library; hashtable used; 
// Complexity: O(n)
void removeDuplicates1( string &str )
{
	bool hashtable[256] = {false};
	int copy_from = 0;
	int copy_to = 0;
	for ( int i=0; i<str.length(); i++ )
	{
		if ( !hashtable[str[i]] )
		{
			hashtable[str[i]] = true;
			str[copy_to] = str[copy_from];
			copy_to++;
			copy_from++;
		}
		else
		{
			copy_from++;
		}
	}
	str.resize(copy_to);
}

// C-style string; hashtable used.
// Complexity: O(n)
void removeDuplicates2( char *str )
{
	bool hashtable[256] = {false};
	int copy_from = 0;
	int copy_to = 0;
	for ( int i=0; i<strlen(str); i++ )
	{
		if ( !hashtable[str[i]] )
		{
			hashtable[str[i]] = true;
			str[copy_to] = str[copy_from];
			copy_to++;
			copy_from++;
		}
		else
		{
			copy_from++;
		}
	}
	str[copy_to] = '\0';
}

// C++ string library
// complexity: O(n^2)
void removeDuplicates3( string &str )
{
	int n = str.length();
	int pos = 0;
	int deleted;
	int count = 0;
	while ( true )
	{
		deleted = pos;
		deleted = str.find( str[pos], deleted+1 );
		while ( deleted != string::npos )
		{
			str.erase( deleted, 1 );
			count++;
			if ( count == n )
				return;
			deleted = str.find( str[pos], deleted+1 );
		}
		pos++;
		count++;
		if ( count == n )
			return;
	}
}


int main()
{
	string s = "";
	cout << "Please enter a string:\n";
	getline( cin, s );
	removeDuplicates3( s );
	cout << "After removing duplicates:\n";
	cout << s << endl;

	//char s[100] = "";
	//cout << "Please enter a string:\n";
	//cin >> s;
	//removeDuplicates2( s );
	//cout << "After removing duplicates:\n";
	//cout << s << endl;

	double temp;
	cin >> temp;
	return 0;
}