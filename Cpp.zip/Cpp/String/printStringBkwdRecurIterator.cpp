// Exercise 18.22, 18.18 of How to Program C++ by Paul Deitel
// Exercise 18.22: This program prints a string using iterators recursively.
// Exercise 18.18; This program inserts the characters "******" in the exact middle of a string.

#include <iostream>
#include <string>
using namespace std;

void printStringBkwdRecurHelper( string &str, string::iterator itr )
{
	if ( itr == str.end() )
		return;
	printStringBkwdRecurHelper( str, ++itr );
	--itr;
	cout << *itr;
}

void printStringBkwdRecur( string str )
{
	printStringBkwdRecurHelper( str, str.begin() );
}

int main()
{
	string s;
	cout << "Please enter a string:\n";
	getline( cin, s );

	s.insert( s.length()/2, "******" );
	cout << "After insertion: " << s << endl;

	string s2;
	cout << "Please enter another string:\n";
	getline( cin, s2 );

	printStringBkwdRecur( s2 );
	cout << endl;

	double temp;
	cin >> temp;
	return 0;
}