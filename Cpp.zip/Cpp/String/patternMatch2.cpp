// Given a string and a pattern, determine whether the string matches the patten.
// Rule: "*" represents zero or more characters (not necessarily the same).
// For example, "hello" matches "h*o*", "hello" matches "hel*lo", 
// but "hello" does not match "h*w".

#include <iostream>
#include <string>
using namespace std;

bool isMatch( char * s, char * p )
{
	if ( *s == '\0' && *p == '\0' )
		return true;
	if ( *s == '\0' && *p == '*' && *(p+1) == '\0' )
		return true;
	if ( *s == '\0' || *p == '\0' )
		return false;
	if ( *s == *p )
		return isMatch( s+1, p+1 );
	else
	{
		if ( *p == '*' )
			return ( isMatch( s+1, p ) || isMatch( s+1, p+1 ) || isMatch( s, p+1 ) );
		else
			return false;
	}
}

int main()
{
	char s1[] = "hello";
	char p1[] = "h*o*";
	cout << isMatch( s1, p1 ) << endl;

	char s2[] = "hello";
	char p2[] = "hel*lo";
	cout << isMatch( s2, p2 ) << endl;

	char *s3 = "hello";
	char *p3 = "h*w";
	cout << isMatch( s3, p3 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}