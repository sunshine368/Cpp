// Given a string in base 2, e.g., "1010101010", convert it into a string in base 4.

#include <iostream>
#include <string>
using namespace std;


// extra space used to return a string
string baseConvert1( string basetwo )
{
	string basefour = "";
	int i = 0;

	if ( basetwo.length()%2 != 0 )
	{
		basefour += basetwo[0];
		i++;
	}

	for ( int j=i; j<basetwo.length(); )
	{
		if ( basetwo[j++] == '0' )
		{
			if ( basetwo[j++] == '1' )
			{
				basefour += '1';
			}
			else
			{
				basefour += '0';
			}
		}
		else 
		{
			if ( basetwo[j++] == '0' )
			{
				basefour += '2';
			}
			else
			{
				basefour += '3';
			}
		}
	}

	return basefour;
}

// no extra space used
void baseConvert2( string& str )
{
	int basefour = 0;
	int basetwo = 0;
	if ( str.length() % 2 != 0 )
	{
		basefour = 1;
		basetwo = 1;
	}

	while ( basetwo < str.length() )
	{
		if ( str[basetwo++] == '0' )
		{
			if ( str[basetwo++] == '0' )
			{
				str[basefour++] = '0';
			}
			else
			{
				str[basefour++] = '1';
			}
		}
		else
		{
			if ( str[basetwo++] == '0' )
			{
				str[basefour++] = '2';
			}
			else
			{
				str[basefour++] = '3';
			}
		}
	}
	str.erase( basefour );
}

int main()
{
	string s;
	cout << "Please enter a binary string:\n";
	getline( cin, s );

	string b = baseConvert1( s );
	cout << "After converting two a base-four string:\n";
	cout << b << endl;

	cout << "In-place convert:\n";
	baseConvert2( s );
	cout << s << endl;

	double temp;
	cin >> temp;
	return 0;
}