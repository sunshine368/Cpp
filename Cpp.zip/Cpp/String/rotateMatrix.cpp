// Given a matrix represented as int[n][n], rotate it 90 degrees clockwise in-place.

#include <iostream>
#include <string>
using namespace std;

const int n=4;

// This solution uses only one variable for extra memory.
void rotateMatrix1( int matrix[n][n] )
{
	int temp;
	for ( int i=0; i<n/2; i++ )
	{
		for ( int j=i; j<n-1-i; j++ )
		{
			temp = matrix[i][j];
			matrix[i][j] = matrix[n-1-j][i]; // move up
			matrix[n-1-j][i] = matrix[n-1-i][n-1-j]; // move left
			matrix[n-1-i][n-1-j] = matrix[j][n-1-i]; // move down
			matrix[j][n-1-i] = temp; // move right
		}
	}
}

// This solution uses no extra memory.
void swapTwoIntegers( int &a, int &b )
{
	a += b;
	b = a - b;
	a = a - b;
}

void rotateMatrix2( int matrix[n][n] )
{
	for ( int i=0; i<n/2; i++ )
	{
		for ( int j=i; j<n-1-i; j++ )
		{
			swapTwoIntegers( matrix[i][j], matrix[n-1-j][i] );
			swapTwoIntegers( matrix[n-1-j][i], matrix[n-1-i][n-1-j] );
			swapTwoIntegers( matrix[n-1-i][n-1-j], matrix[j][n-1-i] );
		}
	}
}

void printMatrix( int matrix[n][n] )
{
	for ( int i=0; i<n; i++ )
	{
		for ( int j=0; j<n; j++ )
		{
			cout << matrix[i][j] << ", ";
		}
		cout << "\n";
	}
}

int main()
{
	int data[n][n]={{1,2,3,10},{4,5,6,11},{7,8,9,12},{13,14,15,16}};
	cout << "Before rotation:\n";
	printMatrix( data );

	rotateMatrix1( data );
	cout << "After rotateMatrix1:\n";
	printMatrix( data );

	rotateMatrix2( data );
	cout << "After rotateMatrix2:\n";
	printMatrix( data );

	double temp;
	cin >> temp;
	return 0;
}