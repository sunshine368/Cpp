// Given a string and a set of delimiters, replace any substring composed of 
// characters in the delimit set with the character '|'.
// For example, the string "How are you, Mr. X?" should modified as
// "How|are|you|Mr|X?"

#include <iostream>
#include <string>
using namespace std;

bool isOldDelimit( char c, char *delimit )
{
	for ( int i=0; i<strlen(delimit); i++ )
	{
		if ( c == delimit[i] )
			return true;
	}
	return false;
}

void replaceDelimit( char *text, char *delimit )
{
	int length = strlen(text);
	bool flag = false;
	int copy_to = 0;
	int copy_from = 0;

	for ( ; copy_from < length; copy_from++ )
	{
		if ( isOldDelimit(text[copy_from],delimit) )
		{
			if ( !flag )
			{
				flag = true;
				text[copy_to] = '|';
				copy_to++;
			}
		}
		else
		{
			flag = false;
			text[copy_to] = text[copy_from];
			copy_to++;
		}
	}
	text[copy_to] = '\0';
}

int main()
{
	char s[] = "How are you, Mr. X?"; // (1)
	char *delimit = " .,";
	cout << "The old string: " << s << endl;
	replaceDelimit( s, delimit );
	cout << "The new string: " << s << endl;

	double temp;
	cin >> temp;
	return 0;
}

char *s = "How are you, Mr. X?";