// Exercise 18.10 of How to Program C++ by Paul Deitel
// This program concatenates the first and last names.

#include <iostream>
#include <string>
using namespace std;

string concatenateFirstLastNames1( string firstName, string lastName )
{
	string name = firstName + ' ' + lastName;
	return name;
}

string concatenateFirstLastNames2( string firstName, string lastName )
{
	string name = firstName;
	name.append( " " );
	name.append( lastName );
	return name;
}

string concatenateFirstLastNames3( string firstName, string lastName )
{
	string name = firstName;
	name.insert( name.length(), " " );
	name.insert( name.length(), lastName );
	return name;
}

int main()
{
	string fName = "Jing";
	string lName = "Zhou";
	string name = concatenateFirstLastNames1( fName, lName );
	cout << "concatenateFirstLastNames1: " << name << endl;
	name = concatenateFirstLastNames2( fName, lName );
	cout << "concatenateFirstLastNames2: " << name << endl;
	name = concatenateFirstLastNames3( fName, lName );
	cout << "concatenateFirstLastNames3: " << name << endl;


	double temp;
	cin >> temp;
	return 0;
}