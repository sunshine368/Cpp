// Exercise 18.8 of How to Program by Paul Deitel
// This program demonstrates the use of string iterators.

#include <iostream>
#include <string>
#include <iterator>
using namespace std;

int main()
{
	string s = "How are you?";
	string::reverse_iterator itr_rbegin = s.rbegin();
	string::reverse_iterator itr_rend = s.rend();
	string::iterator itr_begin = s.begin();
	string::iterator itr_end = s.end();

	cout << "*(s.rbegin): " << *itr_rbegin << endl;
	cout << "*(s.rend - 1): " << *(itr_rend - 1) << endl;
	cout << "*(s.begin): " << *(itr_begin) << endl;
	cout << "*(s.end - 1): " << *(itr_end - 1) << endl;

	double temp;
	cin >> temp;
	return 0;
}