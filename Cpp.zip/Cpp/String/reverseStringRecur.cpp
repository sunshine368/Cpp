// Write a program to reverse a string using recursion.

#include <iostream>
#include <string>
using namespace std;

void reverseStringRecurHelper( char *s, int i )
{
	if ( s[i] == '\0' )
		return;
	reverseStringRecurHelper( s, i+1 );
	cout << s[i];
}

void reverseStringRecur( char *s )
{
	reverseStringRecurHelper( s, 0 );
	cout << endl;
}

int main()
{
	char s[] = "abcdefg";
	reverseStringRecur( s );

	double temp;
	cin >> temp;
	return 0;
}