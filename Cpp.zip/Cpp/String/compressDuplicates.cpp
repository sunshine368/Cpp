// Write a function which compresses a string in the following form:
// void compressDuplicates( char *source )
// Repeating characters in a row should be replaced by the character and the number of 
// occurrences. If a character has a different character directly following it, there
// is no need to add any integer after the character.
// For example, AAAABBBCXYZEEEEPPPPPKKABC should be replaced by A4B3CXYZE4P5K2ABC.
// Iterate the given string only once, and modify the same string. Do not create any new string.

#include <iostream>
#include <string>
using namespace std;

int intToString( int num, char * str ) // convert a given integer into a string pointed to by a given char pointer, with each digit of the integer as a character of the string, return the number of digits of the integer
{
	int digit = 1;
	int num2 = num;
	while ( num/10 != 0 )
	{
		digit++;
		num = num/10;
	}
	for ( int i=0; i<digit; i++ )
	{
		str[digit-1-i] = num2%10 + '0';
		num2 = num2/10;
	}
	return digit;
}

void compressDuplicates( char *src )
{
	int count = 1; // the occurrence frequency of a repeating character in a row	
	int start = 0; // the position of a character in the old string
	int end = 0; // the position after the last occurrence of a repeating character in a row in the old string
	int position = 0; // the position in the new/modified string
	int digit; // convert the occurrence frequency of a repeating character into a string; digit is the length of the string.
	int n = strlen(src); // the length of the original string
	if ( n == 0 )
		return;

	while ( end < n )
	{
		src[position++] = src[start]; // add a character to the new string

		// count the occurrence frequency of a repeating character
		end++;
		if ( end == n )
			break;
		count = 1;
		while ( src[end] == src[start] )
		{
			count++;
			end++;
			if ( end == n )
				break;
		}

		// add the occurrence frequency of a repeating character directly after the character
		if ( count > 1 )
		{
			digit = intToString( count, &src[position] );
			position += digit;
		}

		start = end;
	}
	src[position] = '\0';
}

int main()
{
	char s[] = "AAAABBBCXYZEEEEEEEEEEEEEEPPPPPKKABC";
	cout << "The original string:\n";
	cout << s << endl;
	compressDuplicates( s );
	cout << "After compressing duplicates:\n";
	cout << s << endl;

	double temp;
	cin >> temp;
	//return 0;
}
