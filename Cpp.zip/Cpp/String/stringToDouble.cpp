// Write a function to convert a string to its float equivalent.
// For example, "1234.56" to 1234.56, "-639.12" to -639.12

#include <iostream>
#include <string>
using namespace std;

double stringToDouble( string s )
{
	double result;
	int integer = 0;
	bool isNegative = false;
	bool isDecimal = false;
	int div = 1;
	int i = 0;

	int length = s.length();
	if ( s[0] == '-' )
	{
		isNegative = true;
		i = 1;
	}

	for ( ; i<length; i++ )
	{
		if ( s[i] != '.' )
		{
			if ( !isDecimal )
			{
				integer = (s[i]-'0') + integer*10;
			}
			else
			{
				integer = (s[i]-'0') + integer*10;
				div *= 10;
			}
		}
		else
			isDecimal = true;
	}

	result = double(integer) / div;
	if ( isNegative )
		result *= -1;

	return result;
}

int main()
{
	string s1("1234.56");
	double d1 = stringToDouble( s1 );
	cout << d1 << endl;

	string s2 = "-639.12";
	double d2 = stringToDouble( s2 );
	cout << d2 << endl;

	double temp;
	cin >> temp;
	return 0;
}