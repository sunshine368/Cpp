// Check if two strings are anagrams or not.
// An anagram of a string is obtained by rearrange the characters, including the white space, in the string.

#include <iostream>
#include <string>
using namespace std;

bool isAnagram( const string s1, const string s2 )
{
	int hashtable[26] = {0};
	for ( int i=0; i<s1.length(); i++ )
	{
		if ( !isspace(s1[i]) )
		{
			hashtable[tolower(s1[i])-'a']++;
		}
	}

	for ( int j=0; j<s2.length(); j++ )
	{
		if ( !isspace(s2[j]) )
		{
			hashtable[tolower(s2[j])-'a']--;
		}
	}

	for ( int k=0; k<26; k++ )
	{
		if ( hashtable[k] != 0 )
			return false;
	}

	return true;
}

int main()
{
	string s1 = "Tom Marvolo Riddle";
	string s2( "I am Lord Voldemort" );
	cout << isAnagram( s1, s2 ) << endl;

	string s3 = "Tom Marvolo Riddle";
	string s4( "I am Lord Voldemont" );
	cout << isAnagram( s3, s4 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}