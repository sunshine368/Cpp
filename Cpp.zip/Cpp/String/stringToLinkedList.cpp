// Given a string, write a function
// node* strtok( char *input, char *delims )
// to tokenize the string. Separate the words, put them into a linked list, and return the head of the linked list.

#include <iostream>
#include <string>
using namespace std;

struct Node {
	char * value;
	Node * next;
};

Node * stringToLinkedList( char * text, char * delimit )
{
	char *start = text;
	char *end;

	end = strstr( text, delimit );
	// Node *head = new Node;
	Node *head = (Node *)malloc( sizeof(Node) );
	char *word = (char *)malloc( end-start+1 ); // to allocate enough memory for a copy of a word
	strncpy( word, start, end-start ); // make a copy of a word to the memory allocated
	word[end-start] = '\0';
	head->value = word; // make the pointer point to the copy of the word
	//strncpy( head->value, start, end-start ); // This line and the following two do not work.
	//strncat( head->value, "", 1 );
	//(head->value)[end-start] = '\0';
	head->next = NULL;
	Node *cur_node = head;
	Node *prev_node = cur_node;

	while ( end != NULL ) // while the end of the original string is not reached
	{
		start = end + strlen(delimit);
		if ( (start-text) == strlen(text) ) // start = NULL when the last part of the string is the delimiter. When start=NULL, strstr( start, delimit ) is illegal.
			break;

		end = strstr( start, delimit );
		// cur_node = new Node;
		cur_node = (Node *)malloc( sizeof(Node) );
		if ( end != NULL ) // end=NULL when the end of the string is reached. When end=NULL, malloc( end - start ) and strncpy( word, start, end-start ) are both illegal.
		{
			word = (char *)malloc( end - start + 1 );
			strncpy( word, start, end-start );
			word[end-start] = '\0';
		}
		else
		{
			word = start;
		}
		cur_node->value = word;
		cur_node->next = NULL;
		//strncpy( cur_node->value, start, end-start ); // This line and following two lines do not work. By definition of the struct Node, only a pointer to char has been defined with no memory allocated. Here, we first allocate enough memory for a word which we want to make a copy of, then copy the word to the memory allocated, and finally make the pointer point to the copy of the word. 
		//strncat( head->value, "", 1 );
		//(cur_node->value)[end-start] = '\0';
		prev_node->next = cur_node;
		prev_node = cur_node;
	}

	return head;
}

void printLinkedList( Node *head )
{
	Node *word = head;
	while ( word != NULL )
	{
		cout << word->value << endl;
		word = word->next;
	}
}

int main()
{
	char s[] = "someabccodingabctoabcparseabc";
	char delims[] = "abc";
	Node *wordList = stringToLinkedList( s, delims );
	printLinkedList( wordList );

	double temp;
	cin >> temp;
	return 0;
}