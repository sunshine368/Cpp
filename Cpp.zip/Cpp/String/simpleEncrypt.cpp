// exercise 18.7 of How to Program C++ by Paul Deitel
// "rot13" encryption: rotates each character by 13 positions in the alphabet.
// For example, 'a'->'n', 'x'->'k'

#include <string>
#include <iostream>
using namespace std;

string rot13( const string text )
{
	string code = text;
	for ( int i=0; i<text.length(); i++ )
	{
		if ( text[i] >= 'n' )
		{
			code[i] = 'a' + text[i] - 'n';
		}
		else
		{
			code[i] = text[i] + 13;
		}
	}
	return code;
}

int main()
{
	string str = "abcdnxyz";
	cout << "Before encryption:\n";
	cout << str << endl;

	string codedStr = rot13(str);
	cout << "After encryption:\n";
	cout << codedStr << endl;

	double temp;
	cin >> temp;
	return 0;
}