// Given a string, find a substring of length 3 which is also present in the reverse order.

#include <iostream>
#include <string>
using namespace std;

int encode( char c1, char c2, char c3 ) // (1)
{
	return (c1-'a'+1)+(c2-'a'+1)*10+(c3-'a'+1)*100;
}

string findSubstrInReverseOrder( string s ) // (2)
{
	int hashtable[3000] = {0};
	for ( int i=0; i<s.length()-2; i++ )
	{
		hashtable[encode(s[i],s[i+1],s[i+2])]++;
	}
	for ( int j=s.length()-1; j>=2; j-- )
	{
		if ( hashtable[encode(s[j],s[j-1],s[j-2])] != 0 )
		{
			string result( 3, '0' );
			result[0] = s[j];
			result[1] = s[j-1];
			result[2] = s[j-2];
			return result;
		}
	}
	string result = "";
	return result;
}

int main()
{
	string s1( "abcdefa" );
	string s2 = findSubstrInReverseOrder( s1 );
	if ( s2 == "" )
		cout << "No substring of length 3 also present in the reverse order is found." << endl;
	else
		cout << "Found: " << s2 << endl;

	string s3( "abcdcba" );
	string s4 = findSubstrInReverseOrder( s3 );
	if ( s4 == "" )
		cout << "No substring of length 3 also present in the reverse order is found." << endl;
	else
		cout << "Found: " << s4 << endl;

	double temp;
	cin >> temp;
	return 0;
}