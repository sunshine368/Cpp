// Write a function
//     int compareString ( string s1, string s2 )
// such that the function returns 1, -1 or 0 based on whether s1 is lexicographically 
// greater than, smaller than, or equal to s2. The comparision should be case-insensitive.
// For example, "abc" is smaller than "mno"; "ABC" and "abc" are equal.

#include <iostream>
#include <string>
using namespace std;

int compareStringHelp( string s1, string s2, int index )
{
	if ( s1.length() == index && s2.length() == index )
		return 0;
	if ( s1.length() == index && s2.length() != index )
		return -1;
	if ( s2.length() == index && s1.length() != index ) 
		return 1;
	if ( s1[index] > s2[index] )
		return 1;
	if ( s1[index] < s2[index] )
		return -1;
	if ( s1[index] == s2[index] )
		return compareStringHelp( s1, s2, index+1 );
}

int compareString( string s1, string s2 )
{
	for ( int i=0; i<s1.length(); i++ )
	{
		if ( isupper(s1[i]) )
			s1[i] = tolower( s1[i] );
	}
	for ( int i=0; i<s2.length(); i++ )
	{
		if ( isupper(s2[i]) )
			s2[i] = tolower( s2[i] );
	}
	return compareStringHelp( s1, s2, 0 );
}

int main()
{
	string s1( "abcde" );
	string s2( "ABCDE" );
	cout << compareString( s1, s2 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}