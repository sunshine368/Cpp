#include <string>
#include <iostream>
using namespace std;

int main()
{
	// string definition, including both declaration and initialization
	string text("Hello");
	string name(8,'x');
	string month = "March";

	cout << "text: " << text << endl;
	cout << "name: " << name << endl;
	cout << "month: " << month << endl;

	// incorrect string definition
	//string error1 = 'c';
	//string error2('u');
	//string error3 = 22;
	//string error4(8);
	
	// separate declaration and initialization
	string test1;
	test1 = 'c';
	cout << "test1: " << test1 << endl;
	string test2;
	test2 = 22;
	cout << "test2: " << test2 << endl;

	// check the current version of C++
	cout << "__cplusplus: " << __cplusplus << endl;

	// individual character access
	char c;
	for ( int i=0; i<text.length(); i++ )
	{
		c = text[i];
		cout << "text[" << i << "]: " << c << endl;
	}

	for ( int i=0; i<month.length(); i++ )
	{
		c = month[i];
		cout << "March[" << i << "]: " << c << endl;
	}

	// difference between cin and getline
	string stringObj;
	cout << "Please enter a string: " << endl;
	cin >> stringObj;
	cout << "The string entered: " << stringObj << endl;

	string stringObj2;
	cout << "Please enter another string: " << endl;
	getline(cin, stringObj2);
	cout << "The second string entered: " << stringObj2 << endl;

	char temp;
	cin >> temp;
	return 0;
}
