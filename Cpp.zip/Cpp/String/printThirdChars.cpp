// Given a string, print only the multiple of 3rd letters in the string if the string
// length is a multiple of 3, otherwise print the whole string.

#include <iostream>
#include <string>
using namespace std;

void printThirdChars( const string str )
{
	if ( str.length() % 3 == 0 )
	{
		for ( int i=0; i<str.length(); i+=3 )
		{
			cout << str[i];
		}
		cout << endl;
	}
	else
	{
		cout << str << endl;
	}
}

int main()
{
	string s;
	cout << "Please enter a string: \n";
	getline(cin, s);
	cout << "String length: " << s.length() << endl;
	cout << "printThirdChars: \n";
	printThirdChars( s );

	double temp;
	cin >> temp;
	return 0;
}