// Replace any white space in a given string with "ABC". Do not use extra memmory except for the string.
// For example, "i am chandu" becomes "iABCamABCchandu".

#include <iostream>
#include <string>
using namespace std;

void replaceDelimit2( string &text )
{
	int old_length = text.length();
	int numOfSpace = 0;
	for ( int i=0; i<old_length; i++ )
	{
		if ( isspace(text[i]) )
			numOfSpace++;
	}

	int new_length = old_length + 2 * numOfSpace;
	text.resize( new_length );
	for ( int i=0; i<old_length; i++ )
		text[new_length-1-i] = text[old_length-1-i];

	int copy_to = 0;
	int copy_from = new_length - old_length;
	while ( copy_to < new_length )
	{
		if ( !isspace(text[copy_from]) )
		{
			text[copy_to] = text[copy_from];
			copy_to++;
			copy_from++;
		}
		else
		{
			text[copy_to++] = 'A';
			text[copy_to++] = 'B';
			text[copy_to++] = 'C';
			copy_from++;
		}
	}
}

int main()
{
	string s1 = "i am chandu";
	replaceDelimit2( s1 );
	cout << s1 << endl;

	string s2 = "i am chandu ";
	replaceDelimit2( s2 );
	cout << s2 << endl;

	string s3 = "i  am chandu";
	replaceDelimit2( s3 );
	cout << s3 << endl;

	double temp;
	cin >> temp;
	return 0;
}