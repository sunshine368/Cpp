#include <iostream>
#include <string>
using namespace std;

string intToString( int integer )
{
	int length = 1;
	int isNegative = 0;

	int temp = integer;
	while ( (temp/10) != 0 )
	{
		length++;
		temp = temp/10;
	}

	if ( integer < 0 )
	{
		length++;
		integer *= -1;
		isNegative = 1;
	}
	string str( length, '0' );

	for ( int i=0; i<length; i++ )
	{
		str[length-1-i] = (integer%10) + '0';
		integer = integer / 10;
	}
	
	if ( isNegative == 1 )
		str[0] = '-';
	
	return str;
}


int main()
{
	int a = 123;
	string s1 = intToString( a );
	cout << s1 << endl;

	int b = -145;
	string s2 = intToString( b );
	cout << s2 << endl;

	double temp;
	cin >> temp;
	return 0;
}