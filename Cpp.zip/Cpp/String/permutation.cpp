// Given a word, print all permutations of the letters composing the word.

#include <iostream>
#include <string>
using namespace std;

void swap( char *a, char *b )
{
	char temp = *a;
	*a = *b;
	*b = temp;
}

void permute( string &src, int start, int end )
{
	if ( (end-start) == 1 )
	{
		cout << src << endl;
		return;
	}
	for ( int i=start; i<end; i++ )
	{
		if ( src[i] != src[start] || i==start )
		{
			swap( &src[start], &src[i] );
			permute( src, start+1, end );
			swap( &src[start], &src[i] );
		}
	}
}

void isValidAnagram( string word )
{
	permute( word, 0, word.length() );
}

int main()
{
	string s1 = "abc";
	cout << "All the permutations of s1:\n";
	isValidAnagram( s1 );

	double temp;
	cin >> temp;
	return 0;
}