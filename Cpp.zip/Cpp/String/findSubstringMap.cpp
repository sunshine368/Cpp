// Given a string and a hashmap which contains lower-case alphabets as the key 
// and the occurrence frequency of each alphabet as the value, find a substring
// which contains exactly the same characters (both value and frequency) as the 
// hashmap.
// For example, given the string "abcrefbda" and the map {{"b"=1},{"d"=1},{"a"=1}},
// the output is "bda".

#include <iostream>
#include <string>
#include <vector>
#include <cmath>
using namespace std;

// Approach 1: check one-by-one
// Reference: http://basicalgos.blogspot.com/2012/04/38-find-substr-based-on-map.html
string findSubstringMap1( string s, vector<int> mymap )
{
	int n = s.length();  
	int m = 0;
	for ( int i=0; i<26; i++ )
		m += mymap[i];

	int index = 0; // the position of the first character of the substring of length "m" in the string
	int count;
	int start;
	vector<int> vmap;
	while ( index < n )
	{
		start = index;
		count = m;
		vmap = mymap;
		while ( start < n ) // check a substring starting at the position "index"
		{
			if ( vmap[s[start]-'a'] <= 0 )
				break;

			count--;		
			vmap[s[start]-'a']--;
			start++;
			if ( count == 0 )
				return s.substr( index, m );
		}
		index++;
	}

	return "";
}

// Approach 2: my own method
string findSubstringMap2( string s, vector<int> mymap )
{
	int n = s.length();
	int hashtable[26] = {2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,87,89,91};

	int m = 0; // length of the desired substring
	int product = 1; // the product of the numbers corresponding to the alphabets in the desired substring based on the hashtable
	for ( int i=0; i<26; i++ )
	{
		product *= pow( (double)hashtable[i], (double)mymap[i] );
		m += mymap[i];
	}

	int index = 0;
	int product2;
	while( index < n+1-m )
	{
		product2 = 1;
		for ( int i=index; i<index+m; i++ )
			product2 *= hashtable[s[i]-'a'];
		if ( product2 == product )
			return s.substr( index, m );
		else
			index++;
	}

	return "";
}

int main()
{
	vector<int> myMap(26, 0); // map={{"b"=1},{"d"=1},{"a"=1}}
	myMap['b'-'a'] = 1;
	myMap['d'-'a'] = 1;
	myMap['a'-'a'] = 1;
	string s1 = findSubstringMap1( "abcrefbda", myMap );
	cout << s1 << endl;
	string s2 = findSubstringMap2( "abcrefbda", myMap );
	cout << s2 << endl;

	double temp;
	cin >> temp;
	return 0;
}