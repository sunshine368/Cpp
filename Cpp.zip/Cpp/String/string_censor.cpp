// Programming Abstraction by Stanford University
// Assignment 1 - Problem 1: remove all occurrences of characters
// Write a function that takes two strings as input and returns the first string
// with all of the characters that are present in the second string removed.
// For example,
// "Stanford University" with "nt" removed becomes "Saford Uiversiy".

#include <iostream>
#include <string>
using namespace std;

// This function uses the find and erase member functions of the string class. 
// The first string is modified with all occurrences of letters in the second
// string removed.
void censorString1( string & text, string remove )
{
	int position;
	for ( int i=0; i<remove.length(); i++ )
	{
		position = text.find( remove[i] );
		while ( position != string::npos )
		{
			text.erase( position, 1 );
			position = text.find( remove[i], position );
		}
	}
}

// This function uses the find and replace member functions of the string class. 
// The first string is modified with all occurrences of letters in the second
// string removed.
void censorString2( string & text, string remove )
{
	for ( int i=0; i<remove.length(); i++ )
	{
		int position = 0;
		while ( position = text.find( remove[i], position ) != string::npos )
		{
			text.replace( position, 1, "" );
		}
	}
}

// This function takes two strings returns the first string with all the occurrences
// of letters in the second string removed. It uses a double for loop to iterate through
// the string testing each character to see if it matches any of the letters to remove,
// and building the resultant string character by character.
string censorString3( string text, string remove )
{
	string result = "";

	for ( int i=0; i<text.length(); i++ )
	{
		bool found = false;
		for (int j=0; j<remove.length(); j++) 
		{
			if ( remove[j] == text[i] )
			{
				found = true;
				break;
			}
		}

		if ( !found )
		{
			result += text[i];
		}
	}

	return result;
}

// This function uses the find and substr member functions of the string class.
// A new string is returned.
string censorString4( string text, string remove )
{
	string result = text;
	int position;
	for ( int i=0; i<remove.length(); i++ )
	{
		while ( true )
		{
			position = result.find( remove[i] );
			if ( position == string::npos )
			{
				break;
			}
			else
			{
				result = result.substr(0,position) + result.substr(position+1);
			}
		}
	}
	return result;
}

// This function uses hash table. No embedded loop is used. C-style string library function used.
void censorString5( char *text, char *remove )
{
	char hashtable[256] = {false};
	for ( int i=0; i<strlen(remove); i++ )
	{
		hashtable[remove[i]] = true;
	}
	int position = 0; // position in the modified string
	for ( int j=0; j<strlen(text); j++ )
	{
		if ( hashtable[text[j]] != true )
		{
			text[position] = text[j];
			position++;
		}
	}
	text[position] = '\0';
}

// This function uses hash table. No embedded loop is used. C++ string library function used.
void censorString6( string &text, string remove )
{
	bool hashtable[256] = {false};
	for ( int i=0; i<remove.length(); i++ )
	{
		hashtable[remove[i]] = true;
	}
	int position = 0; // position in the modified string
	for ( int j=0; j<text.length(); j++ )
	{
		if ( hashtable[text[j]] != true )
		{
			text[position] = text[j];
			position++;
		}
	}
	//text.erase( position );
	text.resize( position );
}

int main ()
{
	char s1[] = "Stanford University";
	char s2[] = "nt";
	censorString5(s1, s2);
	cout << "After modification: " << s1 << endl;

	//string s1 = "Stanford University";
	//string s2 = "nt";
	//censorString6(s1, s2);
	//cout << "After modification: " << s1 << endl;

	//string s1 = "Stanford University";
	//string s2 = "nt";
	//string s3 = censorString4(s1, s2);
	//cout << "After modification: " << s3 << endl;

	double temp;
	cin >> temp;
	return 0;
}
