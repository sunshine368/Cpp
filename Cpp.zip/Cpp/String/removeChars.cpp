// Given two strings, remove the second string from the first one. 
// For example, "This is a boy" becomes "Th a boy".

#include <iostream>
#include <string>
using namespace std;

bool isPrime( int integer )
{
	if ( integer == 2 || integer ==3 )
		return true;

	int i=2;
	while ( i<=sqrt(double(integer)) )
	{
		if ( integer/i == 0 )
			return false;
		i++;
	}
	return true;
}

void removeExtraSpace( char *text )
{
	int n = strlen(text);
	int copy_from = 0;
	int copy_to = 0;
	bool isFirstSpace = true;

	while ( copy_from < n )
	{
		while ( text[copy_from] == ' ' )
		{
			if ( isFirstSpace )
			{
				isFirstSpace = false;
				text[copy_to] = ' ';
				copy_from++;
				copy_to++;
			}
			else
				copy_from++;
		}
		isFirstSpace = true;
		
		if ( copy_from == n )
			break;

		text[copy_to] = text[copy_from];
		copy_to++;
		copy_from++;
	}
	text[copy_to] = '\0';
}

void removeChars( char *text, char *remove )
{
	int hashtable[26] = {2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,87,89,91};

	int len = strlen(remove);
	int product = 1;
	for ( int i=0; i<len; i++ )
	{
		if ( isupper(remove[i]) )
		{
			remove[i] = tolower( remove[i] );
		}
		product *= hashtable[remove[i]-'a'];
	}

	int copy_to = 0;
	int copy_from = 0;
	int product2;
	while ( copy_from<strlen(text)+1-len )
	{
		product2 = 1;
		for ( int i=copy_from; i<copy_from+len; i++ )
		{
			if ( isupper(text[i]) )
			{
				text[i] = tolower( text[i] );
			}
			product2 *= hashtable[text[i]-'a'];
		}
		if ( product2 == product )
		{
			copy_from += len;
		}
		else
		{
			text[copy_to] = text[copy_from];
			copy_to++;
			copy_from++;
		}
	}

	// append remaining letters
	for ( int i=strlen(text)+1-len; i<strlen(text); i++ )
	{
		text[copy_to] = text[copy_from];
		copy_to++;
		copy_from++;
	}
	text[copy_to] = '\0';

	removeExtraSpace( text );
}

int main()
{
	// check if all elements of the hashtable are prime number
	int hashtable[26] = {2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,87,89,91};
	int n = sizeof(hashtable)/sizeof(int);
	cout << n << endl;
	for ( int i=0; i<n; i++ )
	{
		if ( !isPrime(hashtable[i]) )
			cout << hashtable[i] << " is not a prime.\n";
	}

	char s[] = "This is a boy   ";
	char r[] = "is";
	removeChars( s, r );
	cout << s;

	double temp;
	cin >> temp;
	return 0;
}