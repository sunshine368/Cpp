// exercise 18.17 of How to Program C++ by Paul Deitel
// Given a string, this program counts the frequency of each vowel in the string.

#include <iostream>
#include <string>
using namespace std;

const int n = 5;

void countVowels( string str, int *count )
{
	for ( int i=0; i<n; i++ )
	{
		*(count+i) = 0;
	}
	char vowels[n] = {'a','e','i','o','u'};
	for ( int i=0; i<str.length(); i++ )
	{
		for ( int j=0; j<n; j++ )
		{
			if ( str[i] == vowels[j] )
			{
				(*(count+j))++;
				break;
			}
		}
	}

	//cout << "The string has\n";
	//for ( int k=0; k<n; k++ )
	//	cout << count[k] << " " << vowels[k] << "'s\n";
	//cout << endl;
}

int main()
{
	string s;
	cout << "Please enter a string:\n";
	getline( cin, s );

	int freq[n];
	countVowels( s, freq );

	char vowels[n] = {'a','e','i','o','u'};
	for ( int i=0; i<n; i++ )
	{
		cout << "The string has " << freq[i] << " " << vowels[i] << "'s.\n";
	}

	double temp;
	cin >> temp;
	return 0;
}