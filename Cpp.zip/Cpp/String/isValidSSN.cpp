// Exercise 18.27 of How to Programm C++ by Paul Deitel
// This program validates the format of a social security number (e.g. ###-##-####, where # is a digit). 
// If the format is valid, return true; otherwise, return false.

#include <iostream>
#include <string>
using namespace std;

bool isValidSSN( const string ssn )
{
	int n = ssn.length();
	
	if ( n != 11 )
	{
		return false;
	}

	if ( ssn[3] != '-' || ssn[6] != '-' )
	{
		return false;
	}

	for ( int i=0; i<11; i++ )
	{
		if ( i != 3 && i != 6 && (ssn[i] > '9' || ssn[i] < '0') )
		{
			return false;
		}
	}

	return true;
}

int main()
{
	string str;
	cout << "Please enter a social security number, enter q to exit:\n";

	while ( true )
	{
		getline(cin, str);
		if ( str == "q" )
		{
			break;
		}
		else
		{
			if ( isValidSSN( str ) )
			{
				cout << "Valid SSN.\n";
			}
			else
			{
				cout << "Invalid SSN.\n";
			}
		}
	}

	double temp;
	cin >> temp;
	return 0;
}