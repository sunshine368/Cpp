// Pattern matching:
// '.' means any single character. For example, given the pattern "..", any string that contains at least
// two characters matches , "a" and "I" do not match.
// '*' means zero or more of the preceding character. For example, given the pattern "a*", "ab" do not match,
// "aa" and "a" match.

#include <iostream>
#include <string>
using namespace std;

// only '*' considered; recursion used
bool isMatch1( const char *p, const char *s )
{
	if ( *p == '\0' && *s == '\0' )
		return true;
	if ( *p == '\0' || *s == '\0' )
		return false;
	if ( *p != *s )
		return false;
	if ( *(p+1) != '*' )
		return isMatch1( p+1, s+1 );
	else
		return (isMatch1( p, s+1 ) || isMatch1( p+2, s+1 ));
}

// only '.' considered; no recursion
bool isMatch2( const char *p, const char *s )
{
	if ( strlen(p) == strlen(s) )
		return true;
	else
		return false;
}

// both "*" and "." considered; recursion used
bool isMatch3( const char *p, const char *s )
{
	if ( *p == '\0' && *s == '\0' ) // (1)
		return true;
	if ( *p == '\0' || *s == '\0' ) // (2)
		return false;
	if ( *p != *s ) // (3)
	{
		if ( *p == '.' ) // (3-1)
		{
			if ( *(p+1) != '*' ) // (3-1-1)
				return isMatch3( p+1, s+1 );
			else // (3-1-2)
			{
				if ( *(s+1) == *s ) // (3-1-2-1)
					return (isMatch3( p, s+1 ) || isMatch3( p+2, s+1 ));
				else // (3-1-2-2)
					return isMatch3( p+2, s+1 );
			}
		}
		else // (3-2)
			return false;
	}
	else // (4)
	{
		if ( *(p+1) != '*' ) // (4-1)
			return isMatch3( p+1, s+1 );
		else // (4-2)
			return (isMatch3( p, s+1 ) || isMatch3( p+2, s+1 ));
	}
}	

// In the following, the left of <-> is the pattern, and the right is the string to be checked. 
// Note that "*" must following a letter or ".". In this approach, "*" is associated with the character right before it, rather than being dealt with individually. 
// (1). Case 1: Both the ends of the two strings are reached. Match!
// (2). Case 2: The end of one string is reached while that of the other is not. Not match!
// (3). Case 3: "a" <-> "b" (two different letters), or "." <-> "a" ("." and a letter)
// (3-1). Case 3-1: "." <-> "a" ("." and a letter)
// (3-2). Case 3-2: "a" <-> "b" (two different letters). Not match!
// (3-1-1). Case 3-1-1: ".b" <-> "a" ("." followed by a letter which is then compared with the character after letter "a")
// (3-1-2). Case 3-1-2: ".*" <-> "a". In this case, we need to consider whether the character after "a" is the same or not, and deal with the two situations differently.
// (3-1-2-1). Case 3-1-2-1: ".*" <-> "aa"
// (3-1-2-2). Case 3-1-2-2: ".*" <-> "ab"
// (4). Case 4: "a" <-> "a" (the same letters)
// (4-1). Case 4-1: "ab" <-> "ac", "b" and "c" are letters which may or may not be different from "a"
// (4-2). Case 4-2: "a*" <-> "a", including both of the two cases: "a*" <-> "ab" ("b" is different from "a"); "a*" <-> "aa"

int main()
{
	char *s1 = "aabbbc";
	char *p1 = "a*b*c*";
	cout << isMatch1( p1, s1 ) << endl;

	char *s2 = "ab";
	char *p2 = "..";
	cout << isMatch2( p2, s2 ) << endl;

	char *s3 = "aafbabc";
	char *p3 = "aa.b*.*c";
	cout << isMatch3( p3, s3 ) << endl;

	char *s4 = "aafbabc";
	char *p4 = "aa.b*..c";
	cout << isMatch3( p4, s4 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}