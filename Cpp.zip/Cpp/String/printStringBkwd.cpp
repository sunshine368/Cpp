// Exercise 18.12 of How to Program C++ by Paul Deitel
// Given a string, print it backward. Convert all lowercase characters to 
// uppercase and all uppercase characters to lowercase.

#include <iostream>
#include <string>
using namespace std;

void printStringBkwd( string str )
{	
	for ( string::reverse_iterator itr = str.rbegin(); itr != str.rend(); itr++ )
	{
		cout << *itr;
	}
	cout << endl;
}

void lowerToUpper( string &str )
{
	int diff = 'A' - 'a';
	for ( int i=0; i<str.length(); i++ )
	{
		if ( str[i] >= 'a' && str[i] <= 'z' )
		{
			str[i] = str[i] + diff;
		}
	}
	cout<< str << endl;
}

void upperToLower( string &str )
{
	int diff = 'a' - 'A';
	for ( int i=0; i<str.length(); i++ )
	{
		if ( str[i] >= 'A' && str[i] <= 'Z' )
		{
			str[i] = str[i] + diff;
		}
	}
	cout<< str << endl;
}

void convertUpperLower( string &str )
{
	int ltu = 'A' - 'a';
	int utl = 'a' - 'A';
	for ( int i=0; i<str.length(); i++ )
	{
		if ( str[i] >= 'a' && str[i] <= 'z' )
		{
			str[i] = str[i] + ltu;
		}
		else if ( str[i] >= 'A' && str[i] <= 'Z' )
		{
			str[i] = str[i] + utl;
		}
	}
	cout << str << endl;
}

int main()
{
	string s = "Today is Wednesday";
	cout << "printStringBkwd: \n";
	printStringBkwd( s );
	cout << "convertUpperLower: \n";
	convertUpperLower( s );
	cout << "lowerToUpper: \n";
	lowerToUpper( s );
	string s1 = "Today is Wednesday";
	upperToLower( s1 );

	double temp;
	cin >> temp;
	return 0;
}