// Given a number of ordered strings, print all possible combinations of the letters
// with the same order as in the original string.
// For example, "AB" and "CD" prints out
// "A", "AB", "ABC", "ABCD", "AC", "ACB", "ACBD", "ACD", "ACDB", 
// "C", "CD", "CDA", "CDAB", "CA", "CAB", "CABD", "CAD", "CADB"

#include <iostream>
#include <string>
using namespace std;

// This function prints ordered combinations for two strings.
void printOrderedCombinationHelper( string s1, string s2, string soFar )
{
	if ( s1.length() == 0 && s2.length() == 0 )
		return;
	if ( s1.length() == 0 && s2.length() != 0)
	{
		printOrderedCombinationHelper( "", s2.substr(1), soFar + s2.at(0) );
		cout << soFar + s2.at(0) << endl;
	}
	else if ( s2.length() == 0 && s1.length() != 0 )
	{
		printOrderedCombinationHelper( s1.substr(1), "", soFar + s1.at(0) );
		cout << soFar + s1.at(0) << endl;
	}
	else
	{
		
		printOrderedCombinationHelper( s1.substr(1), s2, soFar + s1.at(0) );
		cout << soFar + s1.at(0) << endl;
		printOrderedCombinationHelper( s1, s2.substr(1), soFar + s2.at(0) );
		cout << soFar + s2.at(0) << endl;
	}
}

void printOrderedCombination( string s1, string s2 )
{
	printOrderedCombinationHelper( s1, s2, "" );
}

// This function prints ordered combinations for three strings.
void printOrderedCombinationHelper2( string s1, string s2, string s3, string soFar )
{
	if ( s1.length() == 0 && s2.length() == 0 && s3.length() == 0 )
		return;
	if ( s1.length() == 0 )
	{
		if ( s2.length() == 0 )
		{
			printOrderedCombinationHelper2( "", "", s3.substr(1), soFar + s3.at(0) );
			cout << soFar + s3.at(0) << endl;
		}
		else
		{
			if ( s3.length() == 0 )
			{
				printOrderedCombinationHelper2( "", s2.substr(1), "", soFar + s2.at(0) );
				cout << soFar + s2.at(0) << endl;
			}
			else
			{
				printOrderedCombinationHelper2( "", s2.substr(1), s3, soFar + s2.at(0) );
				cout << soFar + s2.at(0) << endl;
				printOrderedCombinationHelper2( "", s2, s3.substr(1), soFar + s3.at(0) );
				cout << soFar + s3.at(0) << endl;
			}
		}
	}
	else 
	{
		if ( s2.length() == 0 )
		{
			if ( s3.length() == 0 )
			{
				printOrderedCombinationHelper2( s1.substr(1), "", "", soFar + s1.at(0) );
				cout << soFar + s1.at(0) << endl;
			}
			else
			{
				printOrderedCombinationHelper2( s1.substr(1), "", s3, soFar + s1.at(0) );
				cout << soFar + s1.at(0) << endl;
				printOrderedCombinationHelper2( s1, "", s3.substr(1), soFar + s3.at(0) );
				cout << soFar + s3.at(0) << endl;
			}
		}
		else
		{
			if ( s3.length() == 0 )
			{
				printOrderedCombinationHelper2( s1.substr(1), s2, "", soFar + s1.at(0) );
				cout << soFar + s1.at(0) << endl;
				printOrderedCombinationHelper2( s1, s2.substr(1), "", soFar + s2.at(0) );
				cout << soFar + s2.at(0) << endl;
			}
			else
			{
				printOrderedCombinationHelper2( s1.substr(1), s2, s3, soFar + s1.at(0) );
				cout << soFar + s1.at(0) << endl;
				printOrderedCombinationHelper2( s1, s2.substr(1), s3, soFar + s2.at(0) );
				cout << soFar + s2.at(0) << endl;
				printOrderedCombinationHelper2( s1, s2, s3.substr(1), soFar + s3.at(0) );
				cout << soFar + s3.at(0) << endl;
			}
		}
	}
}

void printOrderedCombination2( string s1, string s2, string s3 )
{
	printOrderedCombinationHelper2( s1, s2, s3, "" );
}


int main()
{
	string s1( "AB" );
	string s2( "CD" );
	printOrderedCombination( s1, s2 );
	cout << endl << endl;

	string s3 = "ABC";
	string s4("DEF");
	printOrderedCombination( s3, s4 );
	cout << endl << endl;

	string s5( "EF" );
	printOrderedCombination2( s1, s2, s5 );

	double temp;
	cin >> temp;
	return 0;
}