// Convert an ASCII representation of a position integer to its numeric value.

#include <iostream>
#include <string>
using namespace std;

int stringToInt( string s )
{
	int n = s.length();
	int mul = 1;
	int result = 0;
	for ( int i=0; i<n; i++ )
	{
		result += (s[n-1-i] - '0')*mul;
		mul *= 10;
	}
	return result;
}

int main()
{
	string s1( "123" );
	cout << stringToInt( s1 ) << endl;

	string s2 = "639";
	cout << stringToInt( s2 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}