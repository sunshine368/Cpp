// exercise 18.16 of How to Program C++ by Paul Deitel
// This program counts the number of palindromes in a string.
// A palindrome is a word that reads the same backward and forward.
// For example, "noon" and "mom".

#include <iostream>
#include <string>
using namespace std;

bool isPalindrome( string s )
{
	int n = s.length();

	for ( int i=0; i<n/2; i++ )  
	{
		if ( s[i] != s[n-1-i] )
			return false;
	}

	return true;
}

bool isAlphabet( char c )
{
	if ( (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') )
		return true;
	else
		return false;
}

int countPalindromes( string str )
{
	int count = 0;
	int start = 0;
	int end = 0;
	int n = str.length();

	while ( true )
	{
		while ( start != n && !isAlphabet( str[start] ) )
		{
			start++;
		}
		end = start;

		while ( end != n && isAlphabet( str[end] ) )
			end++;

		if ( start == n && end == n )
			break;

		if ( isPalindrome( str.substr( start, end-start ) ) )
		{
			count++;
		}
		start = end;
	}

	return count;
}

int main()
{
	string s;
	cout << "Please enter a string:\n";
	getline( cin, s );
	cout << "There are " << countPalindromes( s ) << " Palindrome(s).\n";

	double temp;
	cin >> temp;
	return 0;
}