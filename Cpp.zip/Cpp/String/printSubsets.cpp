// Given a character array, print all the subsets of those characters.

#include <iostream>
using namespace std;

void printSubsets( const char* s )
{
	int n = strlen(s);
	int num = pow((double)2, n);
	for ( int i=0; i<num; ++i )
	{
		int temp = i;
		for ( int j=0; j<n; ++j )
		{
			if ( temp&1 )
				cout << s[j];
			temp >>= 1;
		}
		cout << endl;
	}
}

int main()
{
	char s[6] = "abcde";
	printSubsets( s );

	system("pause");
	return 0;
}