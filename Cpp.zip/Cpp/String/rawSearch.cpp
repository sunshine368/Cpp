// This program searches for the existence of a string st2 in another string str1. 
// It returns the index where str2 is found and returns -1 otherwise.

#include <iostream>
#include <string>
using namespace std;

int rawSearch( char *text, const char *target  )
{
	int i = 0;
	int j, k;
	while ( text[i] != '\0' )
	{
		j = 0;
		if ( text[i] != target[j] )
		{
			i++;
		}
		else
		{
			k = i;
			while ( target[j] != '\0' )
			{
				k++;
				j++;
				if ( target[j] == '\0' )
				{
					return i;
				}
				if ( text[k] != target[j] )
				{
					break;
				}

			}
		}
	}

	return -1;
}

int main()
{
	char *s1 = "This is a dog.";
	char *s2 = "dog";

	// search for the whole string s2 in s1 using the function rawSearch
	int i = rawSearch( s1, s2 );
	if ( i == -1 )
		cout << "Not found.\n";
	else
		cout << "Found at: " << i << endl;

	// search for the whole string s2 in s1 using C string library function strstr
	char * ptr = strstr( s1, s2 );
	if ( ptr == NULL )
		cout << "Not found." << endl;
	else
		cout << "Found at: " << ptr - s1 << endl;

	double temp;
	cin >> temp;
	return 0;
}