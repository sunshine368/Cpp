// Take a number and a bit position, return true if that bit is set to 1 and false otherwise.

#include <iostream>
#include <string>
using namespace std;

bool checkBit( int x, int pos )
{
	int a = pos - 1;
	return (x&(1<<a))>>a;
}

int main()
{
	int a = 918, p = 3;
	cout << checkBit( a, p ) << endl;

	int b = 4;
	cout << checkBit( b, 3 ) << endl;
	cout << checkBit( b, 1 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}