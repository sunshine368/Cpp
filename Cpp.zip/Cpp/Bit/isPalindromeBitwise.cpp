// Given an integer, return true if the bit pattern of the integer is 
// the same as it is reversed bitwise; otherwise, return false.

#include <iostream>
#include <string>
using namespace std;

bool isPalindromeBitwise1( int x )
{
	int y = 0, z = x;
	for ( int i=0; i<sizeof(int)*CHAR_BIT; i++ ) // the leading 0's considered
	{
		y = (y<<1) | (z&1);
		z = z >> 1;
	}
	return y==x;
}

bool isPalindromeBitwise2( int x )
{
	int y = 0, z = x;
	while (z) // the leading 0's NOT considered
	{
		y = (y<<1) | (z&1);
		z = z >> 1;
	}
	return y==x;
}

int main()
{
	int x1 = 11;
	cout << isPalindromeBitwise1( x1 ) << endl;

	int x2 = pow((double)2,15)+pow((double)2,16);
	cout << isPalindromeBitwise1( x2 ) << endl;

	int x3 = 9;
	cout << isPalindromeBitwise2( x3 ) << endl;

	int x4 = 10;
	cout << isPalindromeBitwise2( x4 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}