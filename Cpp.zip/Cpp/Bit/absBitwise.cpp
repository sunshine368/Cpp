// Determine the absolute value of an integer.

#include <iostream>
using namespace std;

int absBitwise( int x )
{
	int mask = x >> sizeof(int)*CHAR_BIT - 1; // sizeof(int)*CHAR_BIT-1=31; if x<0, x>>31=-1, all 1's in binary representation; if x>0, x>>31=0, all 0's in binary representation.
	return (x + mask)^mask;
}

int main()
{
	int d1 = -1;
	cout << d1 << endl;
	cout << absBitwise( d1 ) << endl;

	int d2 = -365;
	cout << d2 << endl;
	cout << absBitwise( d2 ) << endl;

	int mask = d2 >> sizeof(int)*CHAR_BIT - 1;
	cout << "sizeof(int)*CHAR_BIT-1 = " << sizeof(int)*CHAR_BIT - 1 << endl;
	cout << "mask: " << mask << endl;
	cout << "d2 + mask = " << d2 + mask << endl;

	int d3 = 365;
	cout << d3 << endl;
	cout << absBitwise( d3 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}