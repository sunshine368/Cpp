// Convert a binary string to a decimal/hexadecimal string. 

#include <iostream>
#include <string>
using namespace std;

string binaryToHex( string b )
{
	string h = "";
	string bb = b;
	char hashtable[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

	bb.insert( 0, 4-b.length()%4, '0' );
	int n = bb.length();

	int digit;
	for ( int i=0; i<n/4; i++ )
	{
		digit = 0;
		for ( int j=0; j<4; j++ )
		{
			digit = digit*2 + (bb[4*i+j]-'0');
		}
		h.append( 1, hashtable[digit] );
	}
	
	return h;
}

void reverseString( string& s )
{
	int n = s.length();
	for ( int i=0; i<n/2; i++ )
	{
		s[i] ^= s[n-1-i];
		s[n-1-i] ^= s[i];
		s[i] ^= s[n-1-i];
	}
}

string intToString( int integer )
{
	string s = "";
	while ( integer != 0 )
	{
		s.append( 1, integer%10+'0' );
		integer = integer/10;
	}
	reverseString( s );
	return s;
}

string binaryToDec( string b )
{
	int n = b.length();
	int dd = 0;
	for ( int i=0; i<n; i++ )
	{
		dd = dd*2 + b[i]-'0';
	}

	return intToString( dd );
}

int main()
{
	string x = "110101110";
	string h = binaryToHex( x );
	cout << h << endl;

	string d = binaryToDec( x );
	cout << d << endl;

	double temp;
	cin >> temp;
	return 0;
}