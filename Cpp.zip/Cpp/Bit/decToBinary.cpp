// Display the bit pattern of a decimal integer.

#include <iostream>
#include <string>
using namespace std;

// output the binary representation of a signed/unsigned integer; leading zeros included; reverse string required
void reverseString( string &s )
{
	int n = s.length();
	for ( int i=0; i<n/2; i++ )
	{
		s[i] ^= s[n-1-i];
		s[n-1-i] ^= s[i];
		s[i] ^= s[n-1-i];
	}
}

string intToBinary1( int x )
{
	string s = "";
	for ( int i=0; i<sizeof(int)*CHAR_BIT; i++ )
	{
		s += (x&1)+'0';
		x = x >> 1;

		if ( (i+1)%8 == 0 && i!=(sizeof(int)*CHAR_BIT-1) )
			s += " ";
	}
	reverseString( s );
	return s;
}

// output the binary representation of an unsigned integer; leading zeros disgarded; no need to reverse a string
string intToBinary2( int x )
{
	if ( x==0 )
		return "0";
	
	string s = "";
	for ( int i=floor(log((double)x)/log(2.0)); i>=0; i-- ) // floor(log((double)x)/log(2.0)) returns the index (starting from 0 from the right) of the most significant bit "1".
	{
		s.append( 1, ((x>>i)&1)+'0' );
	}
	return s;
}

// output the binary representation of a signed/unsigned integer; leading zeros disgarded for nonnegative integers but kept for negative integers; no need to reverse a string
// the best approach so far
string intToBinary3( int x )
{
	if ( x==0 )
		return "0";

	string s = "";
	if ( x>0 )
	{
		int numOfBit = floor(log((double)x)/log(2.0));
		s.append( sizeof(int)*CHAR_BIT-1-numOfBit, '0' );
		for ( int i=numOfBit; i>=0; i-- ) // floor(log((double)x)/log(2.0)) returns the index (starting from 0 from the right) of the most significant bit "1".
		{
			s.append( 1, ((x>>i)&1)+'0' );
		}
	}

	if ( x<0 )
	{
		s += "1";
		int n = sizeof(int)*CHAR_BIT;
		int mark = 1<<(n-2);
		while ( mark )
		{
			if ( (mark&x) != 0 )
			{
				s.append( 1, '1' );
			}
			else
			{
				s.append( 1, '0' );
			}
			mark = mark>>1;
		}
	}

	for ( int i=1; i<sizeof(int); i++ ) // insert a white space every eight bits
	{
		s.insert( CHAR_BIT*i+i-1, 1, ' ' );
	}
	return s;
}


int main()
{
	int a1 = 11;
	cout << "intToBinary1(" << a1 << "): " << intToBinary1( a1 ) << endl;
	cout << "intToBinary2(" << a1 << "): " << intToBinary2( a1 ) << endl;

	int a2 = -4;
	cout << "intToBinary1(" << a2 << "): " << intToBinary1( a2 ) << endl;
	cout << "intToBinary3(" << a2 << "): " << intToBinary3( a2 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}