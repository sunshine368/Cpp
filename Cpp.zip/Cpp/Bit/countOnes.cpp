// Count the number of 1's in the binary representation of an integer.

#include <iostream>
#include <string>
using namespace std;

// for negative integers, the sign bit is also counted.
int countOnes( int x )
{
	int count = 0;
	while ( x )
	{
		count++;
		x = x & (x-1);
	}
	return count;
}

int main()
{
	int x1 = 11;
	cout << countOnes( x1 ) << endl;

	int x2 = -4;
	cout << countOnes( x2 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}