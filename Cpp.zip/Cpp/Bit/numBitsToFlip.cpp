// Given two unsigned integers, return the number of bits needed to be flipped for one
// integer to obtain the other.

#include <iostream>
#include <string>
using namespace std;

int numBitsToFlip( unsigned int x, unsigned int y )
{
	unsigned int count = 0;
	for ( unsigned int z = x^y; z!=0; z=z&(z-1) ) // pay attention to z=z&(z-1)
	{
		count++;
	}
	return count;
}

int main()
{
	unsigned int x = 5;
	unsigned int y = 9;
	int z = numBitsToFlip( x, y );
	cout << z << endl;

	double temp;
	cin >> temp;
	return 0;
}