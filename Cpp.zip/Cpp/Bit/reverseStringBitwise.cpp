// Reverse a string using only bitwise operations and without any temporary storage.

#include <iostream>
#include <string>
using namespace std;

void reverseStringBitwise( string &s )
{
	int n = s.length();
	for ( int i=0; i<n/2; i++ )
	{
		s[i] ^= s[n-1-i];
		s[n-1-i] ^= s[i];
		s[i] ^= s[n-1-i];
	}
}

int main()
{
	string s = "abcdefg";
	cout << "The original string: " << s << endl;
	reverseStringBitwise( s );
	cout << "The reverse string: " << s << endl;

	double temp;
	cin >> temp;
	return 0;
}