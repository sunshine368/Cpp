// Swap odd and even bits of a 32-bit unsigned integer.
// For example, 170=0x000000AA becomes 85=0x00000055

#include <iostream>
using namespace std;

void swapOddEvenBits( unsigned int &x )
{
	x = (0xAAAAAAAA & x)>>1 | (0x55555555 & x)<<1;
}


int main()
{
	unsigned int integer = 170;
	cout << sizeof(integer) << endl;
	cout << "The original integer: " << integer << endl;
	swapOddEvenBits( integer );
	cout << "After swapping: " << integer << endl;

	double temp;
	cin >> temp;
	return 0;
}