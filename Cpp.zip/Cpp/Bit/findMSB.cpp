// Find the most significant 1 bit of an integer. The indexes start from the right, numbered 0, 1, 2,...

#include <iostream>
#include <string>
using namespace std;

// unsigned integer considered
int findMSB1( unsigned int x )
{
	if ( x ==0 )
		return -1;
	else
		return floor(log((double)x)/log(2.0));
}

// signed/unsigned integer considered. For signed integer, the sign bit is NOT considered as the MSB.
int findMSB2( int x )
{
	if ( x > 0 )
		return floor(log((double)x)/log(2.0));
	else if ( x == 0 )
		return -1;
	else
	{
		int n = sizeof(int)*CHAR_BIT;
		int pos = 0;
		for ( int i = 0; i<n-1; i++ )
		{
			if ( x&1 )
				pos = i;
			x = x >> 1;
		}
		return pos;
	}
}

int main()
{
	unsigned int x1 = 11;
	cout << findMSB1( x1 ) << endl;
	cout << findMSB1( 0 ) << endl;

	int x2 = -11;
	cout << findMSB2( x2 ) << endl;
	int x3 = -( pow((double)2,30) + pow((double)2,29) + 1 ); // -x3 = 01100000 00000000 00000000 00000001
	cout << findMSB2( x3 ) << endl; // should be 28
	int x4 = 4;
	cout << findMSB2( x4 ) << endl;
	cout << findMSB2( 0 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}