// Check if a given number is a power of 2.

#include <iostream>
using namespace std;

bool isPowerOfTwo( int number )
{
	if ( (number&(number-1))==0 && number!=0 )
		return true;
	else
		return false;
}

int main()
{
	int n1 = 8;
	int n2 = 7;
	cout << isPowerOfTwo( n1 ) << endl;
	cout << isPowerOfTwo( n2 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}