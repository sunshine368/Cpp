// Given two binary strings, write a function to add them and returns the sum 
// as a binary string. For example,
// "1001" + "101" = "1110".

#include <iostream>
#include <string>
using namespace std;

void reverseString( char *s )
{
	int n = strlen(s);
	for ( int i=0; i<n/2; i++ )
	{
		s[i] ^= s[n-1-i];
		s[n-1-i] ^= s[i];
		s[i] ^= s[n-1-i];
	}
}

char* sumBinaryString1( char *s1, char *s2 )
{
	int n1 = strlen(s1);
	int n2 = strlen(s2);
	reverseString(s1);
	reverseString(s2);
	int max = n1;
	if ( n2 > max )
		max = n2;
	char *sum = (char*)malloc(max+2);
	int carry = 0;

	for ( int i=0; i<=max; i++ )
	{
		if ( i>n1-1 && i>n2-1 )
		{
			if ( carry == 1 )
			{
				sum[i] = '1';
				sum[i+1] = '\0';
			}
			else
			{
				sum[i] = '\0';
			}
		}
		else if ( i>n2-1 )
		{
			sum[i] = (s1[i]-'0')^carry + '0';
			carry = (s1[i]-'0')&carry;
		}
		else if ( i>n1-1 )
		{
			sum[i] = (s2[i]-'0')^carry + '0';
			carry = (s2[i]-'0')&carry;
		}
		else
		{
			sum[i] = (s1[i]-'0')^(s2[i]-'0')^carry + '0';
			carry = ((s1[i]-'0')&(s2[i]-'0'))||((s1[i]-'0')&carry)||((s2[i]-'0')&carry); // (1)
		}
	}
	
	reverseString( sum );
	return sum;
}

int main()
{
	char s1[] = "1001";
	char s2[] = "101";
	char *s = sumBinaryString1( s1, s2 );
	cout << s << endl;

	double temp;
	cin >> temp;
	return 0;
}