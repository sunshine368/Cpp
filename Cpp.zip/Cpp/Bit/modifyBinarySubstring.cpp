// Given two integers x, y and two bit positions m < n, set the bits of x 
// between position m and n to be the bits of y between position m and n.
// For example, x = 174 = 00000000 00000000 00000000 10101110,
// y = 18 = 00000000 00000000 00000000 00010010, m = 2, n = 5,
// y -> 00000000 00000000 00000000 10110010 = 178

#include <iostream>
#include <string>
using namespace std;

void reverseString( string &s )
{
	int n = s.length();
	for ( int i=0; i<n/2; i++ )
	{
		s[i] ^= s[n-1-i];
		s[n-1-i] ^= s[i];
		s[i] ^= s[n-1-i];
	}
}

string intToBinary( int x )
{
	string s = "";
	for ( int i=0; i<sizeof(int)*CHAR_BIT; i++ )
	{
		s += (x&1)+'0';
		x = x >> 1;

		if ( (i+1)%8 == 0 && i!=(sizeof(int)*CHAR_BIT-1) )
			s += " ";
	}
	reverseString( s );
	return s;
}

void modifyBinarySubstring( int &x, int y, int n, int m ) // set the bits of x between position m and n (inclusive, n>m) to be those of y.
{
	int a = -1;
	int b = (1<<n) - (1<<(m-1));
	x = ( y&b ) | ( b^a & x ); // y&((1<<n) - (1<<(m-1))): extract the bits of y between position m and n; ( (1<<n) - (1<<(m-1)) )^a & x: clear the bits of x between position m and n.
}

int main()
{
	int a = 174, b = 18, n = 5, m = 2;
	cout << "a: " << a << ", " << intToBinary( a ) << endl;
	cout << "b: " << b << ", " << intToBinary( b ) << endl;
	modifyBinarySubstring( a, b, n, m );
	cout << "a: " << a << ", " << intToBinary( a ) << endl;
	
	int f = -1;
	cout << intToBinary(f) << endl;
	cout << "(1<<n)-(1<<(m-1)): " << intToBinary((1<<n)-(1<<(m-1))) << endl;
	int c = ( (1<<n) - (1<<(m-1)) )^f;
	cout << "( (1<<n) - (1<<(m-1)) )^(-1): " << intToBinary(c) << endl;
	int d = c&a;
	cout << "( (1<<n) - (1<<(m-1)) )^(-1) & a: " << intToBinary(d) << endl;
	int e = b<<(m-1);
	cout << "b<<(m-1): " << intToBinary(e) << endl;

	double temp;
	cin >> temp;
	return 0;
}