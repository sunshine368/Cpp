// Calculate the number of zeros in a given integer.

#include <iostream>
#include <string>
using namespace std;

int countZerosDec( int x )
{
	int count = 0;
	while ( x != 0 )
	{
		if ( x%10 == 0 )
			count++;
		x = x/10;
	}
	return count;
}

int countZerosBin( int x )
{
	int count = 0;
	int digit = sizeof(int)*CHAR_BIT;
	int i = 0;
	while ( i<digit )
	{
		if ( !(x&1) )
			count++;
		x = x>>1;
		i++;
	}
	return count;
}

int main()
{
	int a = 10010;
	int b = countZerosDec( a );
	cout << b << endl;

	int c = 11;
	int d = countZerosBin( c );
	cout << d << endl;

	int c2 = -1;
	int d2 = countZerosBin( c2 );
	cout << d2 << endl;

	int c3 = -3;
	int d3 = countZerosBin( c3 );
	cout << d3 << endl;

	double temp;
	cin >> temp;
	return 0;
}