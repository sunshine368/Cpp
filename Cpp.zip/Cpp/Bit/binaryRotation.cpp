// Rotate the binary representation of an integer.

#include <iostream>
#include <string>
using namespace std;

string intToBinary3( int x )
{
	if ( x==0 )
		return "0";

	string s = "";
	if ( x>0 )
	{
		int numOfBit = floor(log((double)x)/log(2.0));
		s.append( sizeof(int)*CHAR_BIT-1-numOfBit, '0' );
		for ( int i=numOfBit; i>=0; i-- ) // floor(log((double)x)/log(2.0)) returns the index (starting from 0 from the right) of the most significant bit "1".
		{
			s.append( 1, ((x>>i)&1)+'0' );
		}
	}

	if ( x<0 )
	{
		s += "1";
		int n = sizeof(int)*CHAR_BIT;
		int mark = 1<<(n-2);
		while ( mark )
		{
			if ( (mark&x) != 0 )
			{
				s.append( 1, '1' );
			}
			else
			{
				s.append( 1, '0' );
			}
			mark = mark>>1;
		}
	}

	for ( int i=1; i<sizeof(int); i++ ) // insert a white space every eight bits
	{
		s.insert( CHAR_BIT*i+i-1, 1, ' ' );
	}
	return s;
}

// leftRotate1 and leftRotate2 are exactly the same.
void leftRotate1( int &x, int m )
{
	int a = x << m;
	int b = (unsigned int) x >> sizeof(int)*CHAR_BIT-m;
	x = a | b;
}

void leftRotate2( int &x, int m )
{
	x = x << m | (unsigned int) x >> sizeof(int)*CHAR_BIT-m;
}

void rightRotate( int &x, int m )
{
	x = (unsigned int) x >> m | x << sizeof(int)*CHAR_BIT-m;
}

int main()
{
	int x1 = 1, m1 = 30;
	cout << "Original x = " << x1 << " = " << intToBinary3( x1 ) << endl;
	leftRotate1( x1, m1 );
	cout << "After left rotating " << m1 << " bits, x = " << x1 << " = " << intToBinary3( x1 ) << endl;
	leftRotate2( x1, m1 );
	cout << "After left rotating another " << m1 << " bits, x = " << x1 << " = " << intToBinary3( x1 ) << endl;
	rightRotate( x1, m1 );
	cout << "After right rotating " << m1 << " bits, x = " << x1 << " = " << intToBinary3( x1 ) << endl;

	int x2 = -4, m2 = 30;
	cout << "Original x = " << x2 << " = " << intToBinary3( x2 ) << endl;
	leftRotate1( x2, m2 );
	cout << "After left rotating " << m2 << " bits, x = " << x2 << " = " << intToBinary3( x2 ) << endl;
	leftRotate2( x2, m2 );
	cout << "After left rotating another " << m2 << " bits, x = " << x2 << " = " << intToBinary3( x2 ) << endl;
	rightRotate( x2, m2 );
	cout << "After right rotating another " << m2 << " bits, x = " << x2 << " = " << intToBinary3( x2 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}