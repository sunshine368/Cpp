// Reverse the bits of the binary representation of an integer.
// http://www.careercup.com/question?id=250669

#include <iostream>
#include <string>
using namespace std;

// display the binary representation of an integer
string intToBinary3( int x )
{
	if ( x==0 )
		return "0";

	string s = "";
	if ( x>0 )
	{
		int numOfBit = floor(log((double)x)/log(2.0));
		s.append( sizeof(int)*CHAR_BIT-1-numOfBit, '0' );
		for ( int i=numOfBit; i>=0; i-- ) // floor(log((double)x)/log(2.0)) returns the index (starting from 0 from the right) of the most significant bit "1".
		{
			s.append( 1, ((x>>i)&1)+'0' );
		}
	}

	if ( x<0 )
	{
		s += "1";
		int n = sizeof(int)*CHAR_BIT;
		int mark = 1<<(n-2);
		while ( mark )
		{
			if ( (mark&x) != 0 )
			{
				s.append( 1, '1' );
			}
			else
			{
				s.append( 1, '0' );
			}
			mark = mark>>1;
		}
	}

	for ( int i=1; i<sizeof(int); i++ ) // insert a white space every eight bits
	{
		s.insert( CHAR_BIT*i+i-1, 1, ' ' );
	}
	return s;
}

// Reverse bits the obvious way; redundant loops when left-most bits are zeros
int reverseBits1( unsigned int x )
{
	unsigned int r = x;
	int count = sizeof(int)*CHAR_BIT;
	while ( count > 1 )
	{
		x >>= 1;
		r = r<<1 | (x&1);
		count--;
	}
	return r;
}

// optimized
int reverseBits2( unsigned int x )
{
	unsigned int r = x;
	int count = sizeof(int)*CHAR_BIT - 1;
	for ( x>>=1; x; x>>=1 )
	{
		r <<= 1;
		r |= x&1;
		count--;
	}
	r<<=count;
	return r;
}

// optimized 
int reverseBits( unsigned int x )
{
	unsigned int r = x;
	int count = sizeof(int)*CHAR_BIT - 1;
	for ( x>>=1; x; x>>=1 )
	{
		r = r<<1 | (x&1);
		count--;
	}
	r<<=count;
	return r;
}

int main()
{
	int x1 = 34;
	int x2 = reverseBits1( x1 );
	cout << "x1 = " << x1 << " = " << intToBinary3( x1 ) << endl;
	cout << "After reversing bits, x2 = " << x2 << " = " << intToBinary3( x2 ) << endl;
	x2 = reverseBits( x1 );
	cout << "x1 = " << x1 << " = " << intToBinary3( x1 ) << endl;
	cout << "After reversing bits, x2 = " << x2 << " = " << intToBinary3( x2 ) << endl;
	x2 = reverseBits2( x1 );
	cout << "x1 = " << x1 << " = " << intToBinary3( x1 ) << endl;
	cout << "After reversing bits, x2 = " << x2 << " = " << intToBinary3( x2 ) << endl;

	int x3 = -4;
	int x4 = reverseBits1( x3 );
	cout << "x3 = " << x3 << " = " << intToBinary3( x3 ) << endl;
	cout << "After reversing bits, x4 = " << x4 << " = " << intToBinary3( x4 ) << endl;
	x4 = reverseBits( x3 );
	cout << "x3 = " << x3 << " = " << intToBinary3( x3 ) << endl;
	cout << "After reversing bits, x4 = " << x4 << " = " << intToBinary3( x4 ) << endl;
	x4 = reverseBits2( x3 );
	cout << "x3 = " << x3 << " = " << intToBinary3( x3 ) << endl;
	cout << "After reversing bits, x4 = " << x4 << " = " << intToBinary3( x4 ) << endl;

	double temp;
	cin >> temp;
	return 0;
}

