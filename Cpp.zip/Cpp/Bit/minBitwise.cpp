// Compute the minimum or maximum of two integers without branching.
// Note that on some machines, evaluating (x<y) requires a branch instruction.

#include <iostream>
#include <string>
using namespace std;

int findMinBitwise( int x, int y )
{
	return y^( (x^y) & -(x<y) ); // (x<y)=0 if x>y; (x<y)=1 if x<y. => -(x<y)=0 if x>y, all 0's in binary representation; -(x<y)=-1 if x<y, all 1's in binary representation => (x^y)&0=0; (x^y)&-1=x^y. => y^0=y; y^(x^y)=y^(y^x)=y^y^x=0^x=x.
}

int findMaxBitwise( int x, int y )
{
	return x^( (x^y) & -(x<y) );
}


int main()
{
	int a = 66;
	int b = 88;
	cout << findMinBitwise( a, b ) << endl;
	cout << findMaxBitwise( a, b ) << endl;

	double temp;
	cin >> temp;
	return 0;
}