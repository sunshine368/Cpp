// Given an integer, swap bit m and bit n in its binary representation.

#include <iostream>
#include <string>
using namespace std;

string intToBinary3( int x )
{
	if ( x==0 )
		return "0";

	if ( x>0 )
	{
		string s = "";
		for ( int i=floor(log((double)x)/log(2.0)); i>=0; i-- ) // floor(log((double)x)/log(2.0)) returns the index (starting from 0 from the right) of the most significant bit "1".
		{
			s.append( 1, ((x>>i)&1)+'0' );
		}
		return s;
	}

	if ( x<0 )
	{
		string s = "1";
		int n = sizeof(int)*CHAR_BIT;
		int mark = 1<<(n-2);
		while ( mark )
		{
			if ( (mark&x) != 0 )
			{
				s.append( 1, '1' );
			}
			else
			{
				s.append( 1, '0' );
			}
			mark = mark>>1;
		}
		for ( int i=1; i<sizeof(int); i++ ) // insert a white space every eight bits
		{
			s.insert( CHAR_BIT*i+i-1, 1, ' ' );
		}
		return s;
	}
}

void swapBits( int &x, int n, int m ) // assume n>m
{
	if ( ( ( x & 1 << n ) >> n )^( ( x & 1 << m ) >> m ) )
	{
		x ^= 1 << n;
		x ^= 1 << m;
	}
}

int main()
{
	int x = 918;
	cout << "The original x = " << x << " = " << intToBinary3( x ) << endl;
	swapBits( x, 0, 4 );
	cout << "After swapping, x = " << x << " = " << intToBinary3( x ) << endl;

	double temp;
	cin >> temp;
	return 0;
}